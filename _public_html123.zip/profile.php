<?php
/**
 * ============================================
 * SHIKSHARTHI - Profile Page (Redesigned)
 * ============================================
 * 🔒 Protected Page - Login Required
 * 📱 Responsive - Desktop & Mobile
 * 🎨 LeetCode Style Profile Layout
 * ============================================
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';

// ── 🔒 Login check ──
requireLogin();

// ═══════════════════════════════════════
//  EDIT PROFILE HANDLER (POST Request)
// ═══════════════════════════════════════
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_profile'])) {

    $errors = [];

    // ── Sanitize inputs ──
    $newName  = trim(htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8'));
    $newClass = trim(htmlspecialchars($_POST['class'] ?? '', ENT_QUOTES, 'UTF-8'));
    $newBoard = trim(htmlspecialchars($_POST['board'] ?? '', ENT_QUOTES, 'UTF-8'));
    $newCity  = trim(htmlspecialchars($_POST['city'] ?? '', ENT_QUOTES, 'UTF-8'));
    $newState = trim(htmlspecialchars($_POST['state'] ?? '', ENT_QUOTES, 'UTF-8'));

    // ── Validate Name ──
    if (empty($newName) || strlen($newName) < 2) {
        $errors[] = 'Name must be at least 2 characters.';
    }
    if (strlen($newName) > 50) {
        $errors[] = 'Name cannot exceed 50 characters.';
    }

    // ── Validate Class ──
    $validClasses = ['6','7','8','9','10','11','12'];
    if (!in_array($newClass, $validClasses)) {
        $errors[] = 'Please select a valid class.';
    }

    // ── Validate Board ──
    $validBoards = ['CBSE','ICSE','UP Board','MP Board','Bihar Board','Rajasthan Board','Maharashtra Board','Other'];
    if (!in_array($newBoard, $validBoards)) {
        $errors[] = 'Please select a valid board.';
    }

    // ── Validate City & State ──
    if (empty($newCity) || strlen($newCity) < 2) {
        $errors[] = 'Please enter a valid city.';
    }
    if (empty($newState) || strlen($newState) < 2) {
        $errors[] = 'Please enter a valid state.';
    }

    // ── Handle Profile Photo Upload ──
    $newPhotoName = null;
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {

        $file = $_FILES['profile_photo'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 2 * 1024 * 1024; // 2MB

        // Check file type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mimeType, $allowedTypes)) {
            $errors[] = 'Only JPG, PNG, GIF, WEBP images allowed.';
        }

        // Check file size
        if ($file['size'] > $maxSize) {
            $errors[] = 'Image size must be less than 2MB.';
        }

        if (empty($errors)) {
            // Generate unique filename
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $newPhotoName = 'user_' . $_SESSION['user_id'] . '_' . time() . '.' . strtolower($ext);
            $destination = UPLOAD_DIR . $newPhotoName;

            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                $errors[] = 'Failed to upload image. Please try again.';
                $newPhotoName = null;
            } else {
                // Delete old photo (agar default nahi hai)
                $oldUser = getCurrentUser();
                if ($oldUser['profile_photo'] !== 'default.png') {
                    $oldPath = UPLOAD_DIR . $oldUser['profile_photo'];
                    if (file_exists($oldPath)) {
                        unlink($oldPath);
                    }
                }
            }
        }
    }

    // ── Update Database ──
    if (empty($errors)) {
        try {
            $sql = "UPDATE users SET name = ?, class = ?, board = ?, city = ?, state = ?";
            $params = [$newName, $newClass, $newBoard, $newCity, $newState];

            if ($newPhotoName) {
                $sql .= ", profile_photo = ?";
                $params[] = $newPhotoName;
            }

            $sql .= " WHERE id = ?";
            $params[] = $_SESSION['user_id'];

            $stmt = getDB()->prepare($sql);
            $stmt->execute($params);

            setFlash('success', 'Profile updated successfully! ✅');
        } catch (PDOException $e) {
            error_log("Profile Update Error: " . $e->getMessage());
            setFlash('error', 'Something went wrong. Please try again.');
        }
    } else {
        setFlash('error', implode(' ', $errors));
    }

    redirect('profile.php');
    exit;
}

// ═══════════════════════════════════════
//  FETCH USER DATA
// ═══════════════════════════════════════

$user = getCurrentUser();

// Agar user nahi mila → logout
if (!$user) {
    destroySession();
    setFlash('error', 'Account not found. Please contact support.');
    redirect('login.php');
    exit;
}

// ═══════════════════════════════════════
//  STREAK UPDATE LOGIC
// ═══════════════════════════════════════

$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));

$currentStreak = (int)($user['current_streak'] ?? 0);
$longestStreak = (int)($user['longest_streak'] ?? 0);
$lastActive = $user['last_active_date'] ?? null;
$totalDays = (int)($user['total_active_days'] ?? 0);

// Update streak agar aaj ka update nahi hua
if ($lastActive !== $today) {
    if ($lastActive === $yesterday) {
        // Streak continue
        $currentStreak++;
    } elseif ($lastActive === null) {
        // First login
        $currentStreak = 1;
    } else {
        // Streak broken — reset
        $currentStreak = 1;
    }

    $totalDays++;
    $longestStreak = max($longestStreak, $currentStreak);

    try {
        $stmt = getDB()->prepare("UPDATE users SET current_streak = ?, longest_streak = ?, last_active_date = ?, total_active_days = ? WHERE id = ?");
        $stmt->execute([$currentStreak, $longestStreak, $today, $totalDays, $user['id']]);

        // Update local variables
        $user['current_streak'] = $currentStreak;
        $user['longest_streak'] = $longestStreak;
        $user['last_active_date'] = $today;
        $user['total_active_days'] = $totalDays;
    } catch (PDOException $e) {
        error_log("Streak Update Error: " . $e->getMessage());
    }
}

// ═══════════════════════════════════════
//  STUDENT ID GENERATION
// ═══════════════════════════════════════

$regYear = date('y', strtotime($user['created_at'])); // "26" for 2026
$studentId = 'Shiksha' . $regYear . str_pad($user['id'], 2, '0', STR_PAD_LEFT);

// ═══════════════════════════════════════
//  PROFILE PHOTO URL
// ═══════════════════════════════════════

$photoURL = 'uploads/profiles/default.png';
if (!empty($user['profile_photo']) && $user['profile_photo'] !== 'default.png') {
    $photoPath = UPLOAD_DIR . $user['profile_photo'];
    if (file_exists($photoPath)) {
        $photoURL = UPLOAD_URL . $user['profile_photo'];
    }
}

// ═══════════════════════════════════════
//  BADGE SYSTEM (LeetCode Style)
// ═══════════════════════════════════════

$allBadges = [
    [
        'id'          => 'first_step',
        'name'        => 'Pehla Kadam',
        'description' => 'SHIKSHARTHI pe pehli baar login kiya!',
        'icon'        => '🚀',
        'requirement' => 1,
        'color'       => '#4E89C7',
        'tier'        => 'starter'
    ],
    [
        'id'          => 'streak_7',
        'name'        => 'Weekly Warrior',
        'description' => '7 din lagatar padhai ki!',
        'icon'        => '🔥',
        'requirement' => 7,
        'color'       => '#FF6B35',
        'tier'        => 'bronze'
    ],
    [
        'id'          => 'streak_30',
        'name'        => 'Monthly Master',
        'description' => '30 din ka streak — dedication!',
        'icon'        => '📚',
        'requirement' => 30,
        'color'       => '#A6AD48',
        'tier'        => 'silver'
    ],
    [
        'id'          => 'streak_50',
        'name'        => 'Consistency King',
        'description' => '50 din bina ruke — solid!',
        'icon'        => '🌟',
        'requirement' => 50,
        'color'       => '#FFD700',
        'tier'        => 'gold'
    ],
    [
        'id'          => 'streak_100',
        'name'        => 'Century Star',
        'description' => '100 din — you are a legend!',
        'icon'        => '🏆',
        'requirement' => 100,
        'color'       => '#FF4500',
        'tier'        => 'gold'
    ],
    [
        'id'          => 'streak_200',
        'name'        => 'Unstoppable Force',
        'description' => '200 din — koi rok nahi sakta!',
        'icon'        => '👑',
        'requirement' => 200,
        'color'       => '#9B59B6',
        'tier'        => 'platinum'
    ],
    [
        'id'          => 'streak_365',
        'name'        => 'Annual Legend',
        'description' => 'Poora saal — unbelievable!',
        'icon'        => '💎',
        'requirement' => 365,
        'color'       => '#00CED1',
        'tier'        => 'diamond'
    ],
    [
        'id'          => 'total_50',
        'name'        => 'Half Century',
        'description' => 'Total 50 din active rahe!',
        'icon'        => '⭐',
        'requirement' => 50,
        'color'       => '#E67E22',
        'tier'        => 'silver',
        'type'        => 'total'
    ],
    [
        'id'          => 'total_100',
        'name'        => 'Centurion',
        'description' => 'Total 100 din active!',
        'icon'        => '🎖️',
        'requirement' => 100,
        'color'       => '#C0392B',
        'tier'        => 'gold',
        'type'        => 'total'
    ],
];

// Badge earned check
$earnedCount = 0;
foreach ($allBadges as &$badge) {
    if (isset($badge['type']) && $badge['type'] === 'total') {
        $badge['earned'] = $totalDays >= $badge['requirement'];
    } else {
        $badge['earned'] = $longestStreak >= $badge['requirement'];
    }
    if ($badge['earned']) $earnedCount++;
}
unset($badge);

// ═══════════════════════════════════════
//  DAILY QUOTES (Indian Personalities)
// ═══════════════════════════════════════

$quotes = [
    ['text' => 'Dream is not that which you see while sleeping, it is something that does not let you sleep.', 'author' => 'Dr. APJ Abdul Kalam', 'role' => 'Missile Man of India'],
    ['text' => 'Arise, awake and stop not till the goal is reached.', 'author' => 'Swami Vivekananda', 'role' => 'Spiritual Leader'],
    ['text' => 'Live as if you were to die tomorrow. Learn as if you were to live forever.', 'author' => 'Mahatma Gandhi', 'role' => 'Father of the Nation'],
    ['text' => 'Education is the most powerful weapon which you can use to change the world.', 'author' => 'Dr. B.R. Ambedkar', 'role' => 'Architect of Indian Constitution'],
    ['text' => 'You have to dream before your dreams can come true.', 'author' => 'Dr. APJ Abdul Kalam', 'role' => 'Missile Man of India'],
    ['text' => 'The best way to find yourself is to lose yourself in the service of others.', 'author' => 'Mahatma Gandhi', 'role' => 'Father of the Nation'],
    ['text' => 'Take risks in your life. If you win, you can lead. If you lose, you can guide.', 'author' => 'Swami Vivekananda', 'role' => 'Spiritual Leader'],
    ['text' => 'A man is but a product of his thoughts. What he thinks, he becomes.', 'author' => 'Mahatma Gandhi', 'role' => 'Father of the Nation'],
    ['text' => 'Cultivation of mind should be the ultimate aim of human existence.', 'author' => 'Dr. B.R. Ambedkar', 'role' => 'Architect of Indian Constitution'],
    ['text' => 'All power is within you; you can do anything and everything.', 'author' => 'Swami Vivekananda', 'role' => 'Spiritual Leader'],
    ['text' => 'Don\'t take rest after your first victory because if you fail in second, more lips are waiting to say that your first victory was just luck.', 'author' => 'Dr. APJ Abdul Kalam', 'role' => 'Missile Man of India'],
    ['text' => 'The roots of education are bitter, but the fruit is sweet.', 'author' => 'Chanakya', 'role' => 'Ancient Indian Teacher'],
    ['text' => 'A person can achieve everything by being simple and humble.', 'author' => 'Rig Veda', 'role' => 'Ancient Indian Scripture'],
    ['text' => 'Success is not the key to happiness. Happiness is the key to success.', 'author' => 'Rabindranath Tagore', 'role' => 'Nobel Laureate'],
    ['text' => 'Faith is the bird that feels the light when the dawn is still dark.', 'author' => 'Rabindranath Tagore', 'role' => 'Nobel Laureate'],
    ['text' => 'The greatest religion is to be true to your own nature. Have faith in yourselves.', 'author' => 'Swami Vivekananda', 'role' => 'Spiritual Leader'],
    ['text' => 'In a day, when you don\'t come across any problems — you can be sure that you are travelling on a wrong path.', 'author' => 'Swami Vivekananda', 'role' => 'Spiritual Leader'],
    ['text' => 'I am not a product of my circumstances. I am a product of my decisions.', 'author' => 'Sardar Vallabhbhai Patel', 'role' => 'Iron Man of India'],
    ['text' => 'Education is not the learning of facts, but the training of the mind to think.', 'author' => 'Chanakya', 'role' => 'Ancient Indian Teacher'],
    ['text' => 'Once you start working on something, don\'t be afraid of failure and don\'t abandon it.', 'author' => 'Chanakya', 'role' => 'Ancient Indian Teacher'],
    ['text' => 'Strength does not come from physical capacity. It comes from an indomitable will.', 'author' => 'Mahatma Gandhi', 'role' => 'Father of the Nation'],
    ['text' => 'If you want to shine like a sun, first burn like a sun.', 'author' => 'Dr. APJ Abdul Kalam', 'role' => 'Missile Man of India'],
    ['text' => 'Every student should know that knowledge is the greatest treasure.', 'author' => 'Chanakya', 'role' => 'Ancient Indian Teacher'],
    ['text' => 'The mind is everything. What you think, you become.', 'author' => 'Buddha', 'role' => 'Founder of Buddhism'],
    ['text' => 'Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.', 'author' => 'Buddha', 'role' => 'Founder of Buddhism'],
    ['text' => 'Where there is righteousness in the heart, there is beauty in the character.', 'author' => 'Dr. APJ Abdul Kalam', 'role' => 'Missile Man of India'],
    ['text' => 'The only way to do great work is to love what you do.', 'author' => 'Ratan Tata', 'role' => 'Indian Industrialist'],
    ['text' => 'I am not handsome but I can give my hand to someone who needs help.', 'author' => 'Dr. APJ Abdul Kalam', 'role' => 'Missile Man of India'],
    ['text' => 'The power of youth is immense. Channelize it for nation building.', 'author' => 'Narendra Modi', 'role' => 'Prime Minister of India'],
    ['text' => 'Books are the quietest and most constant of friends; they are the most accessible and wisest of counsellors.', 'author' => 'Dr. Sarvepalli Radhakrishnan', 'role' => 'Philosopher President'],
];

// Daily quote — roj change hota hai
$dayOfYear = date('z'); // 0-365
$dailyQuote = $quotes[$dayOfYear % count($quotes)];

// ═══════════════════════════════════════
//  MISC DATA
// ═══════════════════════════════════════

$joinDate = date('d M Y', strtotime($user['created_at']));
$flash = getFlash();

// Valid options for edit form
$classOptions = ['6','7','8','9','10','11','12'];
$boardOptions = ['CBSE','ICSE','UP Board','MP Board','Bihar Board','Rajasthan Board','Maharashtra Board','Other'];
$stateOptions = ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Delhi','Jammu & Kashmir','Ladakh'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="SHIKSHARTHI - Your AI Learning Profile">
    <title>My Profile — SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="app-body">

    <!-- ═══ NAVBAR ═══ -->
    <?php include __DIR__ . '/navbar.php'; ?>

    <!-- ═══ MAIN CONTENT ═══ -->
    <main class="main-content">

        <!-- Flash Message -->
        <?php if ($flash): ?>
            <div class="alert alert-<?= $flash['type'] ?>" id="flashAlert">
                <div class="alert-content">
                    <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-triangle' ?>"></i>
                    <span><?= htmlspecialchars($flash['message']) ?></span>
                </div>
                <button class="alert-close" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        <?php endif; ?>

        <!-- ═══ PROFILE LAYOUT (2 Columns) ═══ -->
        <div class="profile-layout">

            <!-- ════════════════════════════════ -->
            <!--       LEFT COLUMN — PROFILE     -->
            <!-- ════════════════════════════════ -->
            <div class="profile-left">

                <!-- ── Profile Card ── -->
                <div class="card profile-card">

                    <!-- Avatar Section -->
                    <div class="profile-avatar-section">
                        <div class="profile-avatar-container">
                            <img class="profile-avatar-img"
                                 src="<?= htmlspecialchars($photoURL) ?>"
                                 alt="<?= htmlspecialchars($user['name']) ?>"
                                 id="profileAvatar"
                                 onerror="this.src='uploads/profiles/default.png'">
                            <div class="avatar-edit-overlay" onclick="openEditModal()">
                                <i class="fas fa-camera"></i>
                            </div>
                        </div>

                        <!-- Verified Badge -->
                        <?php if (!empty($user['email_verified_at'])): ?>
                            <span class="verified-badge" title="Email Verified">
                                <i class="fas fa-check-circle"></i>
                            </span>
                        <?php endif; ?>
                    </div>

                    <!-- Name & Subtitle -->
                    <h1 class="profile-name"><?= htmlspecialchars($user['name']) ?></h1>
                    <p class="profile-student-id">
                        <i class="fas fa-id-badge"></i> <?= $studentId ?>
                    </p>
                    <p class="profile-subtitle">
                        Class <?= htmlspecialchars($user['class']) ?> • <?= htmlspecialchars($user['board']) ?> Board
                    </p>

                    <!-- Stats Bar -->
                    <div class="profile-stats-bar">
                        <div class="stat-item">
                            <span class="stat-number"><?= $currentStreak ?></span>
                            <span class="stat-label">Streak</span>
                        </div>
                        <div class="stat-divider"></div>
                        <div class="stat-item">
                            <span class="stat-number"><?= $totalDays ?></span>
                            <span class="stat-label">Active Days</span>
                        </div>
                        <div class="stat-divider"></div>
                        <div class="stat-item">
                            <span class="stat-number"><?= $earnedCount ?></span>
                            <span class="stat-label">Badges</span>
                        </div>
                    </div>

                    <!-- Info Items -->
                    <div class="profile-info-list">

                        <div class="info-row">
                            <div class="info-icon-box">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="info-data">
                                <span class="info-label">Email</span>
                                <span class="info-value"><?= htmlspecialchars($user['email']) ?></span>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-icon-box">
                                <i class="fas fa-id-card"></i>
                            </div>
                            <div class="info-data">
                                <span class="info-label">Student ID</span>
                                <span class="info-value"><?= $studentId ?></span>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-icon-box">
                                <i class="fas fa-school"></i>
                            </div>
                            <div class="info-data">
                                <span class="info-label">Class & Board</span>
                                <span class="info-value">Class <?= htmlspecialchars($user['class']) ?> — <?= htmlspecialchars($user['board']) ?></span>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-icon-box">
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div class="info-data">
                                <span class="info-label">Joined</span>
                                <span class="info-value"><?= $joinDate ?></span>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-icon-box">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="info-data">
                                <span class="info-label">Location</span>
                                <span class="info-value"><?= htmlspecialchars($user['city']) ?>, <?= htmlspecialchars($user['state']) ?></span>
                            </div>
                        </div>

                    </div>

                    <!-- Edit Profile Button -->
                    <button class="btn btn-outline-gradient btn-full" onclick="openEditModal()">
                        <i class="fas fa-pen-to-square"></i> Edit Profile
                    </button>

                </div>

            </div>

            <!-- ════════════════════════════════ -->
            <!--     RIGHT COLUMN — ACTIVITY     -->
            <!-- ════════════════════════════════ -->
            <div class="profile-right">

                <!-- ═══ BADGES SECTION ═══ -->
                <div class="card badges-card">
                    <div class="card-header">
                        <h3><i class="fas fa-trophy"></i> Badges</h3>
                        <span class="badge-count"><?= $earnedCount ?>/<?= count($allBadges) ?></span>
                    </div>
                    <div class="badges-grid">
                        <?php foreach ($allBadges as $badge): ?>
                            <div class="badge-item <?= $badge['earned'] ? 'earned' : 'locked' ?>"
                                 title="<?= $badge['earned'] ? $badge['name'] . ' — ' . $badge['description'] : '🔒 ' . $badge['description'] ?>"
                                 style="<?= $badge['earned'] ? '--badge-color: ' . $badge['color'] : '' ?>">
                                <div class="badge-icon-wrap">
                                    <span class="badge-icon"><?= $badge['icon'] ?></span>
                                    <?php if (!$badge['earned']): ?>
                                        <i class="fas fa-lock badge-lock-icon"></i>
                                    <?php endif; ?>
                                </div>
                                <span class="badge-name"><?= $badge['name'] ?></span>
                                <span class="badge-req">
                                    <?php if ($badge['earned']): ?>
                                        <i class="fas fa-check"></i> Earned
                                    <?php else: ?>
                                        <?= $badge['requirement'] ?> days
                                    <?php endif; ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- ═══ STREAK SECTION ═══ -->
                <div class="card streak-card">
                    <div class="card-header">
                        <h3><i class="fas fa-fire-flame-curved"></i> Current Streak</h3>
                    </div>
                    <div class="streak-content">
                        <div class="streak-main">
                            <div class="streak-fire">
                                <span class="fire-emoji"><?= $currentStreak > 0 ? '🔥' : '❄️' ?></span>
                            </div>
                            <div class="streak-number"><?= $currentStreak ?></div>
                            <div class="streak-label">
                                <?= $currentStreak === 1 ? 'Day' : 'Days' ?> Streak
                            </div>
                        </div>
                        <div class="streak-details">
                            <div class="streak-detail-item">
                                <i class="fas fa-crown"></i>
                                <span>Longest Streak</span>
                                <strong><?= $longestStreak ?> days</strong>
                            </div>
                            <div class="streak-detail-item">
                                <i class="fas fa-calendar-check"></i>
                                <span>Total Active Days</span>
                                <strong><?= $totalDays ?> days</strong>
                            </div>
                        </div>
                        <?php if ($currentStreak > 0): ?>
                            <div class="streak-motivation">
                                <?php if ($currentStreak < 7): ?>
                                    <p>🎯 <?= 7 - $currentStreak ?> aur din — <strong>Weekly Warrior</strong> badge milega!</p>
                                <?php elseif ($currentStreak < 30): ?>
                                    <p>📚 <?= 30 - $currentStreak ?> aur din — <strong>Monthly Master</strong> badge milega!</p>
                                <?php elseif ($currentStreak < 50): ?>
                                    <p>🌟 <?= 50 - $currentStreak ?> aur din — <strong>Consistency King</strong> badge milega!</p>
                                <?php elseif ($currentStreak < 100): ?>
                                    <p>🏆 <?= 100 - $currentStreak ?> aur din — <strong>Century Star</strong> ban jaoge!</p>
                                <?php else: ?>
                                    <p>👑 Incredible! Tum fire pe ho! Keep going!</p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- ═══ DAILY QUOTE ═══ -->
                <div class="card quote-card">
                    <div class="quote-decoration">
                        <i class="fas fa-quote-left"></i>
                    </div>
                    <blockquote class="quote-text">
                        "<?= htmlspecialchars($dailyQuote['text']) ?>"
                    </blockquote>
                    <div class="quote-author">
                        <div class="author-info">
                            <strong><?= htmlspecialchars($dailyQuote['author']) ?></strong>
                            <span><?= htmlspecialchars($dailyQuote['role']) ?></span>
                        </div>
                    </div>
                    <div class="quote-footer">
                        <i class="fas fa-lightbulb"></i> Quote of the Day
                    </div>
                </div>

            </div>

        </div>

    </main>

    <!-- ═══ FOOTER ═══ -->
    <?php include __DIR__ . '/footer.php'; ?>

    <!-- ════════════════════════════════════════ -->
    <!--         EDIT PROFILE MODAL              -->
    <!-- ════════════════════════════════════════ -->
    <div class="modal-overlay" id="editModal">
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fas fa-user-edit"></i> Edit Profile</h3>
                <button class="modal-close" onclick="closeEditModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST" action="profile.php" enctype="multipart/form-data" class="modal-body">
                <input type="hidden" name="edit_profile" value="1">

                <!-- Photo Upload -->
                <div class="form-group photo-upload-group">
                    <label>Profile Photo</label>
                    <div class="photo-upload-preview">
                        <img src="<?= htmlspecialchars($photoURL) ?>" alt="Preview" id="photoPreview"
                             onerror="this.src='uploads/profiles/default.png'">
                        <label for="photoInput" class="photo-upload-btn">
                            <i class="fas fa-camera"></i> Change Photo
                        </label>
                        <input type="file" name="profile_photo" id="photoInput"
                               accept="image/jpeg,image/png,image/gif,image/webp" hidden>
                        <small>JPG, PNG, GIF, WEBP • Max 2MB</small>
                    </div>
                </div>

                <!-- Name -->
                <div class="form-group">
                    <label for="editName"><i class="fas fa-user"></i> Full Name</label>
                    <input type="text" id="editName" name="name"
                           value="<?= htmlspecialchars($user['name']) ?>"
                           required minlength="2" maxlength="50" placeholder="Your full name">
                </div>

                <!-- Class -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="editClass"><i class="fas fa-school"></i> Class</label>
                        <select id="editClass" name="class" required>
                            <?php foreach ($classOptions as $cls): ?>
                                <option value="<?= $cls ?>" <?= $user['class'] == $cls ? 'selected' : '' ?>>
                                    Class <?= $cls ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Board -->
                    <div class="form-group">
                        <label for="editBoard"><i class="fas fa-chalkboard"></i> Board</label>
                        <select id="editBoard" name="board" required>
                            <?php foreach ($boardOptions as $brd): ?>
                                <option value="<?= $brd ?>" <?= $user['board'] === $brd ? 'selected' : '' ?>>
                                    <?= $brd ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- City & State -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="editCity"><i class="fas fa-city"></i> City</label>
                        <input type="text" id="editCity" name="city"
                               value="<?= htmlspecialchars($user['city']) ?>"
                               required minlength="2" maxlength="50" placeholder="Your city">
                    </div>

                    <div class="form-group">
                        <label for="editState"><i class="fas fa-map"></i> State</label>
                        <select id="editState" name="state" required>
                            <?php foreach ($stateOptions as $st): ?>
                                <option value="<?= $st ?>" <?= $user['state'] === $st ? 'selected' : '' ?>>
                                    <?= $st ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Submit -->
                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn btn-gradient">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>

        <!-- ═══ JAVASCRIPT (FIXED) ═══ -->
      <!-- ══════════════════════════════
         JAVASCRIPT — ALL FUNCTIONS
    ══════════════════════════════ -->
    <script>
    (function(){
        'use strict';

        // ═══ ELEMENTS ═══
        var menuToggle  = document.getElementById('menuToggle');
        var menuClose   = document.getElementById('menuClose');
        var mainMenu    = document.getElementById('mainMenu');
        var menuOverlay = document.getElementById('menuOverlay');
        var editModal   = document.getElementById('editModal');
        var photoInput  = document.getElementById('photoInput');
        var flashAlert  = document.getElementById('flashAlert');
        var navbar      = document.getElementById('navbar');

        // ═══ MOBILE MENU ═══
        function openMenu() {
            if(mainMenu) mainMenu.classList.add('open');
            if(menuOverlay) menuOverlay.classList.add('show');
            if(menuToggle) menuToggle.classList.add('open');
            document.body.classList.add('locked');
        }

        function closeMenu() {
            if(mainMenu) mainMenu.classList.remove('open');
            if(menuOverlay) menuOverlay.classList.remove('show');
            if(menuToggle) menuToggle.classList.remove('open');
            document.body.classList.remove('locked');
        }

        if(menuToggle) menuToggle.addEventListener('click', function(){
            if(mainMenu && mainMenu.classList.contains('open')){
                closeMenu();
            } else {
                openMenu();
            }
        });

        if(menuClose) menuClose.addEventListener('click', closeMenu);
        if(menuOverlay) menuOverlay.addEventListener('click', closeMenu);

        // ═══ DROPDOWN ═══
        var libraryBtn = document.getElementById('libraryBtn');
        var libraryDropdown = document.getElementById('libraryDropdown');

        if(libraryBtn && libraryDropdown){
            libraryBtn.addEventListener('click', function(e){
                e.preventDefault();
                e.stopPropagation();
                libraryDropdown.classList.toggle('open');
            });
        }

        document.addEventListener('click', function(e){
            if(libraryDropdown && !e.target.closest('#libraryDropdown')){
                libraryDropdown.classList.remove('open');
            }
        });

        // ═══ EDIT MODAL ═══
        window.openEditModal = function(){
            if(editModal){
                editModal.classList.add('active');
                document.body.classList.add('locked');
            }
        };

        window.closeEditModal = function(){
            if(editModal){
                editModal.classList.remove('active');
                document.body.classList.remove('locked');
            }
        };

        if(editModal){
            editModal.addEventListener('click', function(e){
                if(e.target === editModal) window.closeEditModal();
            });
        }

        document.addEventListener('keydown', function(e){
            if(e.key === 'Escape'){
                window.closeEditModal();
                closeMenu();
            }
        });

        // ═══ PHOTO PREVIEW ═══
        if(photoInput){
            photoInput.addEventListener('change', function(){
                var file = this.files[0];
                if(!file) return;
                if(file.size > 2*1024*1024){
                    alert('Image must be less than 2MB!');
                    this.value = '';
                    return;
                }
                var reader = new FileReader();
                reader.onload = function(ev){
                    var preview = document.getElementById('photoPreview');
                    if(preview) preview.src = ev.target.result;
                };
                reader.readAsDataURL(file);
            });
        }

        // ═══ FLASH AUTO-CLOSE ═══
        if(flashAlert){
            setTimeout(function(){
                flashAlert.style.transition = 'opacity .4s, transform .4s';
                flashAlert.style.opacity = '0';
                flashAlert.style.transform = 'translateY(-14px)';
                setTimeout(function(){ flashAlert.remove(); }, 400);
            }, 5000);
        }

        // ═══ NAVBAR SCROLL ═══
        if(navbar){
            window.addEventListener('scroll', function(){
                if(window.scrollY > 10){
                    navbar.classList.add('scrolled');
                } else {
                    navbar.classList.remove('scrolled');
                }
            });
        }

    })();
    </script>

</body>
</html>