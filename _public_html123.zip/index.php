<?php
/**
 * ============================================
 * SHIKSHARTHI - Home / Landing Page
 * ============================================
 * Public page — sabko dikhega
 * Logged in: "Go to Profile" button
 * Not logged in: Login / Register buttons
 * ============================================
 */

require_once __DIR__ . '/security.php';

$isLogged = isLoggedIn();
$flash    = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SHIKSHARTHI — AI Personalized Learning Platform</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="home-body">

    <!-- Flash Message -->
    <?php if ($flash): ?>
        <div class="home-flash alert alert-<?= $flash['type'] ?>">
            <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
            <?= htmlspecialchars($flash['message']) ?>
        </div>
    <?php endif; ?>

    <!-- ═══ HERO SECTION ═══ -->
    <section class="hero-section">
        <div class="hero-content">

            <!-- Logo & Brand -->
            <div class="hero-logo-wrapper">
                <span class="hero-emoji">🎓</span>
                <h1 class="hero-title">SHIKSHARTHI</h1>
            </div>

            <p class="hero-tagline">AI Personalized Learning Platform</p>

            <p class="hero-description">
                Class 9 se 12 tak ke students ke liye AI-powered personalized padhai ka platform.
                CBSE, ICSE, aur UP Board — sabke liye.
            </p>

            <!-- Board Badges -->
            <div class="hero-badges">
                <span class="badge">📘 CBSE</span>
                <span class="badge">📗 ICSE</span>
                <span class="badge">📙 UP Board</span>
                <span class="badge">🎯 Class 9-12</span>
            </div>

            <!-- CTA Buttons -->
            <div class="hero-actions">
                <?php if ($isLogged): ?>
                    <a href="profile.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-user"></i> Go to Profile
                    </a>
                <?php else: ?>
                    <a href="register.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-user-plus"></i> Get Started
                    </a>
                    <a href="login.php" class="btn btn-outline-white btn-lg">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                <?php endif; ?>
            </div>

            <!-- Features Mini -->
            <div class="hero-features">
                <div class="feature-mini">
                    <i class="fas fa-brain"></i>
                    <span>AI Powered</span>
                </div>
                <div class="feature-mini">
                    <i class="fas fa-user-graduate"></i>
                    <span>Personalized</span>
                </div>
                <div class="feature-mini">
                    <i class="fas fa-shield-alt"></i>
                    <span>Secure</span>
                </div>
                <div class="feature-mini">
                    <i class="fas fa-mobile-alt"></i>
                    <span>Responsive</span>
                </div>
            </div>

        </div>

        <!-- Decorative Background Shapes -->
        <div class="hero-bg-shape shape-1"></div>
        <div class="hero-bg-shape shape-2"></div>
        <div class="hero-bg-shape shape-3"></div>
    </section>

    <!-- Footer -->
    <footer class="home-footer">
        <p>&copy; <?= date('Y') ?> SHIKSHARTHI. All rights reserved.</p>
    </footer>
</body>
</html>