<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';
requireLogin();

$user = getCurrentUser();
if (!$user) { redirect('login.php'); exit; }

$subjects = $pdo->prepare("SELECT * FROM subjects WHERE class = ? AND board = ? ORDER BY sort_order");
$subjects->execute([$user['class'], $user['board']]);
$subjects = $subjects->fetchAll(PDO::FETCH_ASSOC);

$subjectId = (int)($_GET['subject'] ?? 0);
$selectedSubject = null;
$pyqs = [];

if ($subjectId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM subjects WHERE id = ? AND class = ? AND board = ?");
    $stmt->execute([$subjectId, $user['class'], $user['board']]);
    $selectedSubject = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($selectedSubject) {
        $stmt = $pdo->prepare("SELECT * FROM pyqs WHERE subject_id = ? ORDER BY year DESC");
        $stmt->execute([$subjectId]);
        $pyqs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PYQs — SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="app-body">
<?php include 'navbar.php'; ?>

<main class="main-content">

    <div class="breadcrumb">
        <a href="pyqs.php"><i class="fas fa-file-alt"></i> PYQs</a>
        <?php if ($selectedSubject): ?>
            <span class="bc-sep"><i class="fas fa-chevron-right"></i></span>
            <span><?= htmlspecialchars($selectedSubject['name']) ?></span>
        <?php endif; ?>
    </div>

    <?php if (!$subjectId): ?>
    <div class="page-header">
        <h1><i class="fas fa-file-alt"></i> Previous Year Questions</h1>
        <p>Class <?= htmlspecialchars($user['class']) ?> — <?= htmlspecialchars($user['board']) ?> Board</p>
    </div>
    <div class="subjects-grid">
        <?php foreach ($subjects as $sub): ?>
            <a href="pyqs.php?subject=<?= $sub['id'] ?>" class="subject-card" style="--card-color:<?= $sub['color'] ?>">
                <div class="subject-icon"><i class="fas <?= $sub['icon'] ?>"></i></div>
                <h3><?= htmlspecialchars($sub['name']) ?></h3>
                <span class="subject-meta">
                    <?php
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM pyqs WHERE subject_id = ?");
                    $stmt->execute([$sub['id']]);
                    echo $stmt->fetchColumn() . ' Papers';
                    ?>
                </span>
            </a>
        <?php endforeach; ?>
    </div>

    <?php else: ?>
    <div class="page-header">
        <h1><i class="fas <?= $selectedSubject['icon'] ?>"></i> <?= htmlspecialchars($selectedSubject['name']) ?> PYQs</h1>
        <p>Download previous year question papers</p>
    </div>

    <?php if (empty($pyqs)): ?>
        <div class="empty-state">
            <i class="fas fa-folder-open"></i>
            <h3>No PYQs Available</h3>
            <p>Previous year questions for this subject will be uploaded soon.</p>
        </div>
    <?php else: ?>
        <div class="pyq-grid">
            <?php foreach ($pyqs as $p): ?>
                <div class="pyq-card">
                    <div class="pyq-icon"><i class="fas fa-file-pdf"></i></div>
                    <div class="pyq-info">
                        <h3><?= htmlspecialchars($p['title']) ?></h3>
                        <span class="pyq-year"><?= htmlspecialchars($p['year']) ?></span>
                    </div>
                    <a href="<?= htmlspecialchars($p['pdf_url']) ?>" target="_blank" class="btn btn-sm btn-outline">
                        <i class="fas fa-download"></i> Download
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php endif; ?>

</main>
<?php include 'footer.php'; ?>
</body>
</html>