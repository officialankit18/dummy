<?php
/**
 * ============================================
 * SHIKSHARTHI - Secure Logout
 * ============================================
 * Session poori tarah destroy karo
 * Cookies delete karo
 * home.php pe redirect karo
 * 
 * 🔒 Back button se bhi wapas nahi aa sakta
 *    (Cache-Control headers security.php me set hain)
 * ============================================
 */

require_once __DIR__ . '/security.php';

// ── Poora session destroy karo ──
destroySession();

// ── Home page pe bhej do ──
// Note: setFlash session me store karta hai
// but humne session destroy kar diya
// toh naya session start karna padega flash ke liye
session_start();
session_regenerate_id(true);
setFlash('success', 'Successfully logout ho gaye! 👋');
redirect('index.php');