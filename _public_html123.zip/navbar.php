<?php
/**
 * ============================================
 * SHIKSHARTHI - Navbar Component
 * ============================================
 * 🔝 Har page me include karo
 * <?php include 'navbar.php'; ?>
 * ============================================
 */

$currentPage = basename($_SERVER['PHP_SELF']);

// Navbar ke liye user data (agar logged in hai)
$navUser = null;
if (isset($_SESSION['user_id'])) {
    $navUser = getCurrentUser();
}

// Profile photo for navbar avatar
$navPhoto = 'uploads/profiles/default.png';
if ($navUser && !empty($navUser['profile_photo']) && $navUser['profile_photo'] !== 'default.png') {
    $navPhotoPath = UPLOAD_DIR . $navUser['profile_photo'];
    if (file_exists($navPhotoPath)) {
        $navPhoto = UPLOAD_URL . $navUser['profile_photo'];
    }
}
?>

<!-- Navbar CSS -->
<style>
/* ═══════════════════════════════════════════ */
/*           SHIKSHARTHI NAVBAR STYLES         */
/* ═══════════════════════════════════════════ */

:root {
    --nav-height: 70px;
    --nav-bg: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    --nav-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    --accent-primary: #00d4ff;
    --accent-secondary: #7c3aed;
    --accent-gradient: linear-gradient(135deg, #00d4ff, #7c3aed);
    --text-primary: #ffffff;
    --text-secondary: rgba(255, 255, 255, 0.7);
    --hover-bg: rgba(255, 255, 255, 0.1);
    --dropdown-bg: #1e1e3f;
}

/* ── Base Navbar ── */
.sk-navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: var(--nav-height);
    background: var(--nav-bg);
    z-index: 9999;
    transition: all 0.3s ease;
}

.sk-navbar.scrolled {
    box-shadow: var(--nav-shadow);
    background: linear-gradient(135deg, #0d0d1a 0%, #0f1729 100%);
}

.sk-nav-inner {
    max-width: 1400px;
    margin: 0 auto;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px;
}

/* ── Brand Logo ── */
.sk-brand {
    display: flex;
    align-items: center;
    gap: 12px;
    text-decoration: none;
    z-index: 1001;
}

.sk-brand-icon {
    width: 45px;
    height: 45px;
    background: var(--accent-gradient);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    color: white;
    box-shadow: 0 4px 15px rgba(0, 212, 255, 0.3);
    transition: transform 0.3s ease;
}

.sk-brand:hover .sk-brand-icon {
    transform: rotate(-10deg) scale(1.1);
}

.sk-brand-name {
    font-size: 1.5rem;
    font-weight: 800;
    background: var(--accent-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: 1px;
}

/* ── Navigation Menu ── */
.sk-menu {
    display: flex;
    align-items: center;
    gap: 5px;
}

.sk-nav-link {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    color: var(--text-secondary);
    text-decoration: none;
    font-size: 0.95rem;
    font-weight: 500;
    border-radius: 10px;
    transition: all 0.3s ease;
    position: relative;
    border: none;
    background: transparent;
    cursor: pointer;
    white-space: nowrap;
}

.sk-nav-link i {
    font-size: 1.1rem;
}

.sk-nav-link:hover {
    color: var(--text-primary);
    background: var(--hover-bg);
}

.sk-nav-link.active {
    color: var(--accent-primary);
    background: rgba(0, 212, 255, 0.1);
}

.sk-nav-link.active::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 30px;
    height: 3px;
    background: var(--accent-gradient);
    border-radius: 3px;
}

/* ── Dropdown ── */
.sk-dropdown {
    position: relative;
}

.sk-dropdown-btn {
    display: flex;
    align-items: center;
    gap: 8px;
}

.sk-arrow {
    font-size: 0.7rem;
    transition: transform 0.3s ease;
    margin-left: 4px;
}

.sk-dropdown.open .sk-arrow {
    transform: rotate(180deg);
}

.sk-dropdown-menu {
    position: absolute;
    top: calc(100% + 10px);
    left: 50%;
    transform: translateX(-50%) translateY(10px);
    min-width: 180px;
    background: var(--dropdown-bg);
    border-radius: 12px;
    padding: 8px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    border: 1px solid rgba(255, 255, 255, 0.1);
}

.sk-dropdown-menu::before {
    content: '';
    position: absolute;
    top: -8px;
    left: 50%;
    transform: translateX(-50%);
    border-left: 8px solid transparent;
    border-right: 8px solid transparent;
    border-bottom: 8px solid var(--dropdown-bg);
}

.sk-dropdown.open .sk-dropdown-menu {
    opacity: 1;
    visibility: visible;
    transform: translateX(-50%) translateY(0);
}

.sk-dropdown-menu a {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 16px;
    color: var(--text-secondary);
    text-decoration: none;
    border-radius: 8px;
    transition: all 0.2s ease;
    font-size: 0.9rem;
}

.sk-dropdown-menu a:hover {
    background: var(--hover-bg);
    color: var(--text-primary);
    transform: translateX(5px);
}

.sk-dropdown-menu a.active {
    color: var(--accent-primary);
    background: rgba(0, 212, 255, 0.1);
}

.sk-dropdown-menu a i {
    width: 20px;
    text-align: center;
}

/* ── Logout Button ── */
.sk-logout-btn {
    color: #ff6b6b !important;
    margin-left: 10px;
}

.sk-logout-btn:hover {
    background: rgba(255, 107, 107, 0.15) !important;
    color: #ff4757 !important;
}

/* ── Hamburger Menu (Mobile) ── */
.sk-hamburger {
    display: none;
    flex-direction: column;
    justify-content: center;
    gap: 5px;
    width: 40px;
    height: 40px;
    background: transparent;
    border: none;
    cursor: pointer;
    z-index: 1001;
    padding: 8px;
}

.sk-hamburger span {
    display: block;
    width: 100%;
    height: 3px;
    background: var(--text-primary);
    border-radius: 3px;
    transition: all 0.3s ease;
}

.sk-hamburger.active span:nth-child(1) {
    transform: rotate(45deg) translate(5px, 5px);
}

.sk-hamburger.active span:nth-child(2) {
    opacity: 0;
    transform: translateX(-10px);
}

.sk-hamburger.active span:nth-child(3) {
    transform: rotate(-45deg) translate(6px, -6px);
}

/* ── Mobile Menu Close Button ── */
.sk-menu-close {
    display: none;
}

/* ── Overlay ── */
.sk-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    z-index: 998;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.sk-overlay.active {
    opacity: 1;
    visibility: visible;
}

/* ── Body Spacer ── */
body {
    padding-top: var(--nav-height);
}

body.nav-open {
    overflow: hidden;
}

/* ═══════════════════════════════════════════ */
/*              RESPONSIVE STYLES              */
/* ═══════════════════════════════════════════ */

@media (max-width: 1100px) {
    .sk-nav-link {
        padding: 10px 12px;
        font-size: 0.9rem;
    }
    
    .sk-brand-name {
        font-size: 1.3rem;
    }
}

@media (max-width: 900px) {
    .sk-hamburger {
        display: flex;
    }

    .sk-menu {
        position: fixed;
        top: 0;
        right: -300px;
        width: 280px;
        height: 100vh;
        background: linear-gradient(180deg, #1a1a2e 0%, #0d0d1a 100%);
        flex-direction: column;
        align-items: stretch;
        padding: 80px 20px 30px;
        gap: 5px;
        overflow-y: auto;
        transition: right 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        z-index: 999;
        box-shadow: -10px 0 30px rgba(0, 0, 0, 0.5);
    }

    .sk-menu.active {
        right: 0;
    }

    .sk-menu-close {
        display: flex;
        position: absolute;
        top: 20px;
        right: 20px;
        width: 40px;
        height: 40px;
        background: rgba(255, 255, 255, 0.1);
        border: none;
        border-radius: 10px;
        color: white;
        font-size: 1.2rem;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .sk-menu-close:hover {
        background: rgba(255, 107, 107, 0.2);
        color: #ff6b6b;
    }

    .sk-nav-link {
        padding: 14px 16px;
        border-radius: 12px;
        font-size: 1rem;
    }

    .sk-nav-link.active::after {
        display: none;
    }

    .sk-nav-link.active {
        background: rgba(0, 212, 255, 0.15);
        border-left: 3px solid var(--accent-primary);
    }

    /* Mobile Dropdown */
    .sk-dropdown {
        width: 100%;
    }

    .sk-dropdown-btn {
        width: 100%;
        justify-content: flex-start;
    }

    .sk-arrow {
        margin-left: auto;
    }

    .sk-dropdown-menu {
        position: static;
        transform: none;
        opacity: 1;
        visibility: visible;
        max-height: 0;
        overflow: hidden;
        padding: 0;
        margin: 0;
        background: rgba(0, 0, 0, 0.2);
        border: none;
        box-shadow: none;
        border-radius: 0 0 12px 12px;
        transition: max-height 0.3s ease, padding 0.3s ease, margin 0.3s ease;
    }

    .sk-dropdown-menu::before {
        display: none;
    }

    .sk-dropdown.open .sk-dropdown-menu {
        max-height: 300px;
        padding: 10px;
        margin-top: 5px;
    }

    .sk-dropdown-menu a {
        padding: 12px 20px;
    }

    .sk-logout-btn {
        margin-left: 0;
        margin-top: auto;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        padding-top: 20px;
    }
}

@media (max-width: 480px) {
    .sk-brand-name {
        font-size: 1.1rem;
    }

    .sk-brand-icon {
        width: 38px;
        height: 38px;
        font-size: 1.1rem;
    }

    .sk-menu {
        width: 100%;
        right: -100%;
    }
}

/* ── Animations ── */
@keyframes navLinkPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

.sk-nav-link:active {
    animation: navLinkPulse 0.2s ease;
}
</style>

<!-- ═══════════════════════════════════════════ -->
<!--              SHIKSHARTHI NAVBAR            -->
<!-- ═══════════════════════════════════════════ -->
<nav class="sk-navbar" id="navbar">
    <div class="sk-nav-inner">

        <!-- ── Brand Logo ── -->
        <a href="home.php" class="sk-brand">
            <div class="sk-brand-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <span class="sk-brand-name">SHIKSHARTHI</span>
        </a>

        <!-- ── Hamburger Toggle (Mobile) ── -->
        <button class="sk-hamburger" id="menuToggle" aria-label="Toggle Menu">
            <span></span>
            <span></span>
            <span></span>
        </button>

        <!-- ── Navigation Menu ── -->
        <div class="sk-menu" id="mainMenu">

            <!-- Mobile Close Button -->
            <button class="sk-menu-close" id="menuClose" aria-label="Close Menu">
                <i class="fas fa-times"></i>
            </button>

            <a href="profile.php" class="sk-nav-link <?= $currentPage === 'profile.php' ? 'active' : '' ?>">
                <i class="fas fa-user-circle"></i>
                <span>Profile</span>
            </a>

            <a href="dashboard.php" class="sk-nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
                <i class="fas fa-th-large"></i>
                <span>Dashboard</span>
            </a>

            <a href="videos.php" class="sk-nav-link <?= $currentPage === 'videos.php' ? 'active' : '' ?>">
                <i class="fas fa-play-circle"></i>
                <span>Videos</span>
            </a>

            <!-- Library Dropdown -->
            <div class="sk-dropdown" id="libraryDropdown">
                <button class="sk-nav-link sk-dropdown-btn <?= in_array($currentPage, ['notes.php','pyqs.php','syllabus.php']) ? 'active' : '' ?>">
                    <i class="fas fa-book-open"></i>
                    <span>Library</span>
                    <i class="fas fa-chevron-down sk-arrow"></i>
                </button>
                <div class="sk-dropdown-menu">
                    <a href="notes.php" class="<?= $currentPage === 'notes.php' ? 'active' : '' ?>">
                        <i class="fas fa-sticky-note"></i> Notes
                    </a>
                    <a href="pyqs.php" class="<?= $currentPage === 'pyqs.php' ? 'active' : '' ?>">
                        <i class="fas fa-file-alt"></i> PYQs
                    </a>
                    <a href="syllabus.php" class="<?= $currentPage === 'syllabus.php' ? 'active' : '' ?>">
                        <i class="fas fa-list-check"></i> Syllabus
                    </a>
                </div>
            </div>

            <a href="quizzes.php" class="sk-nav-link <?= $currentPage === 'quizzes.php' ? 'active' : '' ?>">
                <i class="fas fa-question-circle"></i>
                <span>Quizzes</span>
            </a>

            <a href="games.php" class="sk-nav-link <?= $currentPage === 'games.php' ? 'active' : '' ?>">
                <i class="fas fa-gamepad"></i>
                <span>Games</span>
            </a>

            <a href="goals.php" class="sk-nav-link <?= $currentPage === 'goals.php' ? 'active' : '' ?>">
                <i class="fas fa-bullseye"></i>
                <span>Set Goal</span>
            </a>

            <a href="about.php" class="sk-nav-link <?= $currentPage === 'about.php' ? 'active' : '' ?>">
                <i class="fas fa-info-circle"></i>
                <span>About Us</span>
            </a>

            <!-- Logout Button -->
            <a href="logout.php" class="sk-nav-link sk-logout-btn"
               onclick="return confirm('Kya aap logout karna chahte hain?')">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

    </div>
</nav>

<!-- ── Navbar Overlay (Mobile) ── -->
<div class="sk-overlay" id="menuOverlay"></div>

<script>
// ═══════════════════════════════════════════
//           NAVBAR JAVASCRIPT
// ═══════════════════════════════════════════

document.addEventListener('DOMContentLoaded', function() {
    
    // Elements
    const navbar = document.getElementById('navbar');
    const menuToggle = document.getElementById('menuToggle');
    const mainMenu = document.getElementById('mainMenu');
    const menuClose = document.getElementById('menuClose');
    const menuOverlay = document.getElementById('menuOverlay');
    const dropdowns = document.querySelectorAll('.sk-dropdown');

    // ── Toggle Mobile Menu ──
    function openMenu() {
        menuToggle.classList.add('active');
        mainMenu.classList.add('active');
        menuOverlay.classList.add('active');
        document.body.classList.add('nav-open');
    }

    function closeMenu() {
        menuToggle.classList.remove('active');
        mainMenu.classList.remove('active');
        menuOverlay.classList.remove('active');
        document.body.classList.remove('nav-open');
        // Close all dropdowns
        dropdowns.forEach(d => d.classList.remove('open'));
    }

    menuToggle.addEventListener('click', function() {
        if (mainMenu.classList.contains('active')) {
            closeMenu();
        } else {
            openMenu();
        }
    });

    menuClose.addEventListener('click', closeMenu);
    menuOverlay.addEventListener('click', closeMenu);

    // ── Dropdown Toggle ──
    dropdowns.forEach(dropdown => {
        const btn = dropdown.querySelector('.sk-dropdown-btn');
        
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const isOpen = dropdown.classList.contains('open');
            
            // Close other dropdowns
            dropdowns.forEach(d => {
                if (d !== dropdown) d.classList.remove('open');
            });
            
            // Toggle current
            dropdown.classList.toggle('open', !isOpen);
        });
    });

    // ── Close dropdown on outside click ──
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.sk-dropdown')) {
            dropdowns.forEach(d => d.classList.remove('open'));
        }
    });

    // ── Close menu on nav link click (mobile) ──
    mainMenu.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 900) {
                setTimeout(closeMenu, 100);
            }
        });
    });

    // ── Navbar Scroll Effect ──
    let lastScroll = 0;
    
    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        
        // Add shadow on scroll
        if (currentScroll > 10) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
        
        lastScroll = currentScroll;
    });

    // ── Handle Window Resize ──
    window.addEventListener('resize', function() {
        if (window.innerWidth > 900) {
            closeMenu();
        }
    });

    // ── Keyboard Navigation ──
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && mainMenu.classList.contains('active')) {
            closeMenu();
        }
    });

});
</script>