<?php
/**
 * SHIKSHARTHI — Admin AJAX Handler
 * All admin CRUD operations
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['ok' => false, 'msg' => 'Not logged in']);
    exit;
}

// Check admin
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$u = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$u || !$u['is_admin']) {
    echo json_encode(['ok' => false, 'msg' => 'Access denied']);
    exit;
}

$action = $_POST['action'] ?? '';

try {
    switch ($action) {

        // ═══════════════════════════
        //  SUBJECTS
        // ═══════════════════════════
        case 'add_subject':
            $name = trim($_POST['name'] ?? '');
            $class = trim($_POST['class'] ?? '');
            $board = trim($_POST['board'] ?? '');
            $icon = trim($_POST['icon'] ?? 'fa-book');
            $color = trim($_POST['color'] ?? '#4E89C7');

            if (!$name || !$class || !$board) {
                echo json_encode(['ok' => false, 'msg' => 'All fields required']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO subjects (name, class, board, icon, color, sort_order) VALUES (?, ?, ?, ?, ?, (SELECT COALESCE(MAX(s.sort_order),0)+1 FROM subjects s))");
            $stmt->execute([$name, $class, $board, $icon, $color]);
            echo json_encode(['ok' => true, 'id' => $pdo->lastInsertId()]);
            break;

        case 'update_subject':
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $class = trim($_POST['class'] ?? '');
            $board = trim($_POST['board'] ?? '');
            $icon = trim($_POST['icon'] ?? 'fa-book');
            $color = trim($_POST['color'] ?? '#4E89C7');

            $pdo->prepare("UPDATE subjects SET name=?, class=?, board=?, icon=?, color=? WHERE id=?")->execute([$name, $class, $board, $icon, $color, $id]);
            echo json_encode(['ok' => true]);
            break;

        case 'delete_subject':
            $id = (int)($_POST['id'] ?? 0);
            $pdo->prepare("DELETE FROM subjects WHERE id=?")->execute([$id]);
            echo json_encode(['ok' => true]);
            break;

        case 'get_subjects':
            $class = $_POST['class'] ?? '';
            $board = $_POST['board'] ?? '';
            $sql = "SELECT * FROM subjects";
            $params = [];
            if ($class && $board) {
                $sql .= " WHERE class=? AND board=?";
                $params = [$class, $board];
            }
            $sql .= " ORDER BY class, board, sort_order";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            echo json_encode(['ok' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        // ═══════════════════════════
        //  CHAPTERS
        // ═══════════════════════════
        case 'add_chapter':
            $subId = (int)($_POST['subject_id'] ?? 0);
            $num = (int)($_POST['chapter_number'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $desc = trim($_POST['description'] ?? '');

            if (!$subId || !$num || !$title) {
                echo json_encode(['ok' => false, 'msg' => 'All fields required']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO chapters (subject_id, chapter_number, title, description) VALUES (?, ?, ?, ?)");
            $stmt->execute([$subId, $num, $title, $desc]);
            echo json_encode(['ok' => true, 'id' => $pdo->lastInsertId()]);
            break;

        case 'update_chapter':
            $id = (int)($_POST['id'] ?? 0);
            $num = (int)($_POST['chapter_number'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $desc = trim($_POST['description'] ?? '');

            $pdo->prepare("UPDATE chapters SET chapter_number=?, title=?, description=? WHERE id=?")->execute([$num, $title, $desc, $id]);
            echo json_encode(['ok' => true]);
            break;

        case 'delete_chapter':
            $id = (int)($_POST['id'] ?? 0);
            $pdo->prepare("DELETE FROM chapters WHERE id=?")->execute([$id]);
            echo json_encode(['ok' => true]);
            break;

        case 'get_chapters':
            $subId = (int)($_POST['subject_id'] ?? 0);
            $stmt = $pdo->prepare("SELECT c.*, s.name as subject_name FROM chapters c JOIN subjects s ON c.subject_id=s.id WHERE c.subject_id=? ORDER BY c.chapter_number");
            $stmt->execute([$subId]);
            echo json_encode(['ok' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        // ═══════════════════════════
        //  VIDEOS
        // ═══════════════════════════
        case 'add_video':
            $chId = (int)($_POST['chapter_id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $url = trim($_POST['youtube_url'] ?? '');
            $dur = trim($_POST['duration'] ?? '');

            if (!$chId || !$title || !$url) {
                echo json_encode(['ok' => false, 'msg' => 'All fields required']);
                exit;
            }

            $order = $pdo->query("SELECT COALESCE(MAX(sort_order),0)+1 FROM videos WHERE chapter_id=$chId")->fetchColumn();
            $stmt = $pdo->prepare("INSERT INTO videos (chapter_id, title, youtube_url, duration, sort_order) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$chId, $title, $url, $dur, $order]);
            echo json_encode(['ok' => true, 'id' => $pdo->lastInsertId()]);
            break;

        case 'update_video':
            $id = (int)($_POST['id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $url = trim($_POST['youtube_url'] ?? '');
            $dur = trim($_POST['duration'] ?? '');

            $pdo->prepare("UPDATE videos SET title=?, youtube_url=?, duration=? WHERE id=?")->execute([$title, $url, $dur, $id]);
            echo json_encode(['ok' => true]);
            break;

        case 'delete_video':
            $id = (int)($_POST['id'] ?? 0);
            $pdo->prepare("DELETE FROM videos WHERE id=?")->execute([$id]);
            echo json_encode(['ok' => true]);
            break;

        case 'get_videos':
            $chId = (int)($_POST['chapter_id'] ?? 0);
            $stmt = $pdo->prepare("SELECT * FROM videos WHERE chapter_id=? ORDER BY sort_order");
            $stmt->execute([$chId]);
            echo json_encode(['ok' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        // ═══════════════════════════
        //  NOTES
        // ═══════════════════════════
        case 'add_note':
            $chId = (int)($_POST['chapter_id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $content = $_POST['content'] ?? '';
            $pdfUrl = trim($_POST['pdf_url'] ?? '');

            if (!$chId || !$title) {
                echo json_encode(['ok' => false, 'msg' => 'Title required']);
                exit;
            }

            $order = $pdo->query("SELECT COALESCE(MAX(sort_order),0)+1 FROM notes WHERE chapter_id=$chId")->fetchColumn();
            $stmt = $pdo->prepare("INSERT INTO notes (chapter_id, title, content, pdf_url, sort_order) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$chId, $title, $content, $pdfUrl, $order]);
            echo json_encode(['ok' => true, 'id' => $pdo->lastInsertId()]);
            break;

        case 'update_note':
            $id = (int)($_POST['id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $content = $_POST['content'] ?? '';
            $pdfUrl = trim($_POST['pdf_url'] ?? '');

            $pdo->prepare("UPDATE notes SET title=?, content=?, pdf_url=? WHERE id=?")->execute([$title, $content, $pdfUrl, $id]);
            echo json_encode(['ok' => true]);
            break;

        case 'delete_note':
            $id = (int)($_POST['id'] ?? 0);
            $pdo->prepare("DELETE FROM notes WHERE id=?")->execute([$id]);
            echo json_encode(['ok' => true]);
            break;

        // ═══════════════════════════
        //  PYQs
        // ═══════════════════════════
        case 'add_pyq':
            $subId = (int)($_POST['subject_id'] ?? 0);
            $year = trim($_POST['year'] ?? '');
            $title = trim($_POST['title'] ?? '');

            if (!$subId || !$year || !$title) {
                echo json_encode(['ok' => false, 'msg' => 'All fields required']);
                exit;
            }

            // Handle PDF upload
            $pdfUrl = '';
            if (isset($_FILES['pdf']) && $_FILES['pdf']['error'] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['pdf']['name'], PATHINFO_EXTENSION));
                if ($ext !== 'pdf') {
                    echo json_encode(['ok' => false, 'msg' => 'Only PDF allowed']);
                    exit;
                }
                $fname = 'pyq_' . time() . '_' . rand(1000,9999) . '.pdf';
                $dest = __DIR__ . '/uploads/pyqs/' . $fname;
                if (!is_dir(__DIR__ . '/uploads/pyqs')) mkdir(__DIR__ . '/uploads/pyqs', 0755, true);
                move_uploaded_file($_FILES['pdf']['tmp_name'], $dest);
                $pdfUrl = 'uploads/pyqs/' . $fname;
            }

            if (!$pdfUrl) {
                echo json_encode(['ok' => false, 'msg' => 'PDF file required']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO pyqs (subject_id, year, title, pdf_url) VALUES (?, ?, ?, ?)");
            $stmt->execute([$subId, $year, $title, $pdfUrl]);
            echo json_encode(['ok' => true]);
            break;

        case 'delete_pyq':
            $id = (int)($_POST['id'] ?? 0);
            // Delete file
            $stmt = $pdo->prepare("SELECT pdf_url FROM pyqs WHERE id=?");
            $stmt->execute([$id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && file_exists(__DIR__ . '/' . $row['pdf_url'])) {
                unlink(__DIR__ . '/' . $row['pdf_url']);
            }
            $pdo->prepare("DELETE FROM pyqs WHERE id=?")->execute([$id]);
            echo json_encode(['ok' => true]);
            break;

        case 'get_pyqs':
            $subId = (int)($_POST['subject_id'] ?? 0);
            $sql = "SELECT p.*, s.name as subject_name FROM pyqs p JOIN subjects s ON p.subject_id=s.id";
            $params = [];
            if ($subId) { $sql .= " WHERE p.subject_id=?"; $params = [$subId]; }
            $sql .= " ORDER BY p.year DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            echo json_encode(['ok' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        // ═══════════════════════════
        //  SYLLABUS
        // ═══════════════════════════
        case 'add_syllabus':
            $class = trim($_POST['class'] ?? '');
            $board = trim($_POST['board'] ?? '');
            $title = trim($_POST['title'] ?? '');
            $subId = (int)($_POST['subject_id'] ?? 0) ?: null;

            if (!$class || !$board || !$title) {
                echo json_encode(['ok' => false, 'msg' => 'All fields required']);
                exit;
            }

            $pdfUrl = '';
            if (isset($_FILES['pdf']) && $_FILES['pdf']['error'] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['pdf']['name'], PATHINFO_EXTENSION));
                if ($ext !== 'pdf') {
                    echo json_encode(['ok' => false, 'msg' => 'Only PDF allowed']);
                    exit;
                }
                $fname = 'syl_' . time() . '_' . rand(1000,9999) . '.pdf';
                $dest = __DIR__ . '/uploads/syllabus/' . $fname;
                if (!is_dir(__DIR__ . '/uploads/syllabus')) mkdir(__DIR__ . '/uploads/syllabus', 0755, true);
                move_uploaded_file($_FILES['pdf']['tmp_name'], $dest);
                $pdfUrl = 'uploads/syllabus/' . $fname;
            }

            if (!$pdfUrl) {
                echo json_encode(['ok' => false, 'msg' => 'PDF file required']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO syllabus (class, board, title, pdf_url, subject_id) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$class, $board, $title, $pdfUrl, $subId]);
            echo json_encode(['ok' => true]);
            break;

        case 'delete_syllabus':
            $id = (int)($_POST['id'] ?? 0);
            $stmt = $pdo->prepare("SELECT pdf_url FROM syllabus WHERE id=?");
            $stmt->execute([$id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && file_exists(__DIR__ . '/' . $row['pdf_url'])) {
                unlink(__DIR__ . '/' . $row['pdf_url']);
            }
            $pdo->prepare("DELETE FROM syllabus WHERE id=?")->execute([$id]);
            echo json_encode(['ok' => true]);
            break;

        case 'get_syllabus':
            $stmt = $pdo->query("SELECT sy.*, s.name as subject_name FROM syllabus sy LEFT JOIN subjects s ON sy.subject_id=s.id ORDER BY sy.class, sy.board");
            echo json_encode(['ok' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        // ═══════════════════════════
        //  STATS
        // ═══════════════════════════
        case 'get_stats':
            $stats = [];
            $stats['users'] = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
            $stats['subjects'] = (int)$pdo->query("SELECT COUNT(*) FROM subjects")->fetchColumn();
            $stats['chapters'] = (int)$pdo->query("SELECT COUNT(*) FROM chapters")->fetchColumn();
            $stats['videos'] = (int)$pdo->query("SELECT COUNT(*) FROM videos")->fetchColumn();
            $stats['notes'] = (int)$pdo->query("SELECT COUNT(*) FROM notes")->fetchColumn();
            $stats['pyqs'] = (int)$pdo->query("SELECT COUNT(*) FROM pyqs")->fetchColumn();
            echo json_encode(['ok' => true, 'stats' => $stats]);
            break;

        default:
            echo json_encode(['ok' => false, 'msg' => 'Unknown action']);
    }
} catch (Exception $e) {
    error_log("Admin Error: " . $e->getMessage());
    echo json_encode(['ok' => false, 'msg' => 'Server error: ' . $e->getMessage()]);
}