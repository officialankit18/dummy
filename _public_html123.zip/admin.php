<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';
requireLogin();

$user = getCurrentUser();
if (!$user || !$user['is_admin']) {
    setFlash('error', 'Access denied. Admin only.');
    redirect('profile.php');
    exit;
}

// Get all subjects for dropdowns
$allSubjects = $pdo->query("SELECT * FROM subjects ORDER BY class, board, sort_order")->fetchAll(PDO::FETCH_ASSOC);
$allChapters = $pdo->query("SELECT c.*, s.name as subject_name, s.class, s.board FROM chapters c JOIN subjects s ON c.subject_id=s.id ORDER BY s.class, s.board, s.sort_order, c.chapter_number")->fetchAll(PDO::FETCH_ASSOC);

$classes = ['6','7','8','9','10','11','12'];
$boards = ['CBSE','ICSE','UP Board','MP Board','Bihar Board','Rajasthan Board','Maharashtra Board','Other'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel — SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="app-body">
<?php include 'navbar.php'; ?>

<main class="main-content" style="max-width:1000px">

    <div class="page-header">
        <h1><i class="fas fa-shield-halved"></i> Admin Panel</h1>
        <p>Manage all content for SHIKSHARTHI</p>
    </div>

    <!-- Stats -->
    <div class="dash-stats" id="adminStats" style="margin-bottom:24px">
        <div class="dash-stat-card"><div class="ds-icon" style="background:rgba(78,137,199,.1);color:var(--blue)"><i class="fas fa-users"></i></div><div class="ds-info"><span class="ds-num" id="sUsers">-</span><span class="ds-label">Users</span></div></div>
        <div class="dash-stat-card"><div class="ds-icon" style="background:rgba(139,92,246,.1);color:var(--purple)"><i class="fas fa-book"></i></div><div class="ds-info"><span class="ds-num" id="sSubjects">-</span><span class="ds-label">Subjects</span></div></div>
        <div class="dash-stat-card"><div class="ds-icon" style="background:rgba(16,185,129,.1);color:#10b981"><i class="fas fa-play"></i></div><div class="ds-info"><span class="ds-num" id="sVideos">-</span><span class="ds-label">Videos</span></div></div>
        <div class="dash-stat-card"><div class="ds-icon" style="background:rgba(245,158,11,.1);color:#f59e0b"><i class="fas fa-file-alt"></i></div><div class="ds-info"><span class="ds-num" id="sNotes">-</span><span class="ds-label">Notes</span></div></div>
    </div>

    <!-- Tabs -->
    <div class="admin-tabs">
        <button class="atab active" data-tab="subjects"><i class="fas fa-book"></i> Subjects</button>
        <button class="atab" data-tab="chapters"><i class="fas fa-list"></i> Chapters</button>
        <button class="atab" data-tab="videos"><i class="fas fa-play"></i> Videos</button>
        <button class="atab" data-tab="notes"><i class="fas fa-sticky-note"></i> Notes</button>
        <button class="atab" data-tab="pyqs"><i class="fas fa-file-pdf"></i> PYQs</button>
        <button class="atab" data-tab="syllabus"><i class="fas fa-list-check"></i> Syllabus</button>
    </div>

    <!-- ═══ SUBJECTS TAB ═══ -->
    <div class="atab-content active" id="tab-subjects">
        <div class="card" style="margin-bottom:20px">
            <div class="card-header"><h3><i class="fas fa-plus"></i> Add Subject</h3></div>
            <div style="padding:20px">
                <div class="form-row">
                    <div class="form-group"><label>Subject Name</label><input type="text" id="subName" class="form-input" placeholder="e.g., Mathematics"></div>
                    <div class="form-group"><label>Class</label><select id="subClass" class="form-input"><option value="">Select</option><?php foreach($classes as $c): ?><option value="<?=$c?>">Class <?=$c?></option><?php endforeach; ?></select></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Board</label><select id="subBoard" class="form-input"><option value="">Select</option><?php foreach($boards as $b): ?><option value="<?=$b?>"><?=$b?></option><?php endforeach; ?></select></div>
                    <div class="form-group"><label>Icon (FA class)</label><input type="text" id="subIcon" class="form-input" placeholder="fa-calculator" value="fa-book"></div>
                    <div class="form-group"><label>Color</label><input type="color" id="subColor" value="#4E89C7" style="height:42px;width:100%;border:2px solid var(--bdr);border-radius:var(--r-md)"></div>
                </div>
                <button class="btn btn-primary btn-sm" onclick="addSubject()"><i class="fas fa-plus"></i> Add Subject</button>
            </div>
        </div>
        <div class="card"><div class="card-header"><h3><i class="fas fa-list"></i> All Subjects</h3></div><div id="subjectsList" style="padding:16px"></div></div>
    </div>

    <!-- ═══ CHAPTERS TAB ═══ -->
    <div class="atab-content" id="tab-chapters">
        <div class="card" style="margin-bottom:20px">
            <div class="card-header"><h3><i class="fas fa-plus"></i> Add Chapter</h3></div>
            <div style="padding:20px">
                <div class="form-row">
                    <div class="form-group"><label>Subject</label><select id="chSubject" class="form-input"><option value="">Select Subject</option><?php foreach($allSubjects as $s): ?><option value="<?=$s['id']?>"><?=$s['name']?> (Class <?=$s['class']?> <?=$s['board']?>)</option><?php endforeach; ?></select></div>
                    <div class="form-group"><label>Chapter Number</label><input type="number" id="chNum" class="form-input" placeholder="1" min="1"></div>
                </div>
                <div class="form-group"><label>Chapter Title</label><input type="text" id="chTitle" class="form-input" placeholder="e.g., Number Systems"></div>
                <div class="form-group"><label>Description</label><input type="text" id="chDesc" class="form-input" placeholder="Brief description"></div>
                <button class="btn btn-primary btn-sm" onclick="addChapter()"><i class="fas fa-plus"></i> Add Chapter</button>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h3><i class="fas fa-list"></i> Chapters</h3>
                <select id="chFilterSub" class="form-input" style="max-width:300px" onchange="loadChapters()">
                    <option value="">Select Subject to View</option>
                    <?php foreach($allSubjects as $s): ?><option value="<?=$s['id']?>"><?=$s['name']?> (<?=$s['class']?> <?=$s['board']?>)</option><?php endforeach; ?>
                </select>
            </div>
            <div id="chaptersList" style="padding:16px"><p class="empty-text">Select a subject above</p></div>
        </div>
    </div>

    <!-- ═══ VIDEOS TAB ═══ -->
    <div class="atab-content" id="tab-videos">
        <div class="card" style="margin-bottom:20px">
            <div class="card-header"><h3><i class="fas fa-plus"></i> Add Video</h3></div>
            <div style="padding:20px">
                <div class="form-group"><label>Chapter</label><select id="vidChapter" class="form-input"><option value="">Select Chapter</option><?php foreach($allChapters as $c): ?><option value="<?=$c['id']?>">Ch <?=$c['chapter_number']?>: <?=$c['title']?> (<?=$c['subject_name']?> <?=$c['class']?> <?=$c['board']?>)</option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Video Title</label><input type="text" id="vidTitle" class="form-input" placeholder="e.g., Introduction to Number Systems"></div>
                <div class="form-row">
                    <div class="form-group"><label>YouTube URL</label><input type="url" id="vidUrl" class="form-input" placeholder="https://www.youtube.com/watch?v=..."></div>
                    <div class="form-group"><label>Duration</label><input type="text" id="vidDur" class="form-input" placeholder="15:30"></div>
                </div>
                <button class="btn btn-primary btn-sm" onclick="addVideo()"><i class="fas fa-plus"></i> Add Video</button>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h3><i class="fas fa-list"></i> Videos</h3>
                <select id="vidFilterCh" class="form-input" style="max-width:350px" onchange="loadVideos()">
                    <option value="">Select Chapter to View</option>
                    <?php foreach($allChapters as $c): ?><option value="<?=$c['id']?>">Ch <?=$c['chapter_number']?>: <?=$c['title']?> (<?=$c['subject_name']?>)</option><?php endforeach; ?>
                </select>
            </div>
            <div id="videosList" style="padding:16px"><p class="empty-text">Select a chapter above</p></div>
        </div>
    </div>

    <!-- ═══ NOTES TAB ═══ -->
    <div class="atab-content" id="tab-notes">
        <div class="card" style="margin-bottom:20px">
            <div class="card-header"><h3><i class="fas fa-plus"></i> Add Note</h3></div>
            <div style="padding:20px">
                <div class="form-group"><label>Chapter</label><select id="noteChapter" class="form-input"><option value="">Select Chapter</option><?php foreach($allChapters as $c): ?><option value="<?=$c['id']?>">Ch <?=$c['chapter_number']?>: <?=$c['title']?> (<?=$c['subject_name']?>)</option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Note Title</label><input type="text" id="noteTitle" class="form-input" placeholder="Chapter 1 Complete Notes"></div>
                <div class="form-group"><label>Content (HTML)</label><textarea id="noteContent" class="form-input" rows="8" placeholder="<h3>Topic</h3><p>Content here...</p>"></textarea></div>
                <div class="form-group"><label>PDF URL (optional)</label><input type="text" id="notePdf" class="form-input" placeholder="uploads/notes/file.pdf"></div>
                <button class="btn btn-primary btn-sm" onclick="addNote()"><i class="fas fa-plus"></i> Add Note</button>
            </div>
        </div>
    </div>

    <!-- ═══ PYQs TAB ═══ -->
    <div class="atab-content" id="tab-pyqs">
        <div class="card" style="margin-bottom:20px">
            <div class="card-header"><h3><i class="fas fa-plus"></i> Upload PYQ</h3></div>
            <form id="pyqForm" style="padding:20px" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-group"><label>Subject</label><select id="pyqSubject" class="form-input" name="subject_id"><option value="">Select Subject</option><?php foreach($allSubjects as $s): ?><option value="<?=$s['id']?>"><?=$s['name']?> (<?=$s['class']?> <?=$s['board']?>)</option><?php endforeach; ?></select></div>
                    <div class="form-group"><label>Year</label><input type="text" id="pyqYear" class="form-input" name="year" placeholder="2024"></div>
                </div>
                <div class="form-group"><label>Title</label><input type="text" id="pyqTitle" class="form-input" name="title" placeholder="Mathematics PYQ 2024"></div>
                <div class="form-group"><label>PDF File</label><input type="file" id="pyqFile" class="form-input" name="pdf" accept=".pdf"></div>
                <button type="button" class="btn btn-primary btn-sm" onclick="addPyq()"><i class="fas fa-upload"></i> Upload PYQ</button>
            </form>
        </div>
        <div class="card"><div class="card-header"><h3><i class="fas fa-list"></i> All PYQs</h3></div><div id="pyqsList" style="padding:16px"></div></div>
    </div>

    <!-- ═══ SYLLABUS TAB ═══ -->
    <div class="atab-content" id="tab-syllabus">
        <div class="card" style="margin-bottom:20px">
            <div class="card-header"><h3><i class="fas fa-plus"></i> Upload Syllabus</h3></div>
            <form id="sylForm" style="padding:20px" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-group"><label>Class</label><select id="sylClass" class="form-input"><option value="">Select</option><?php foreach($classes as $c): ?><option value="<?=$c?>">Class <?=$c?></option><?php endforeach; ?></select></div>
                    <div class="form-group"><label>Board</label><select id="sylBoard" class="form-input"><option value="">Select</option><?php foreach($boards as $b): ?><option value="<?=$b?>"><?=$b?></option><?php endforeach; ?></select></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Title</label><input type="text" id="sylTitle" class="form-input" placeholder="Mathematics Syllabus 2025-26"></div>
                    <div class="form-group"><label>Subject (optional)</label><select id="sylSubject" class="form-input"><option value="0">General</option><?php foreach($allSubjects as $s): ?><option value="<?=$s['id']?>"><?=$s['name']?> (<?=$s['class']?> <?=$s['board']?>)</option><?php endforeach; ?></select></div>
                </div>
                <div class="form-group"><label>PDF File</label><input type="file" id="sylFile" class="form-input" accept=".pdf"></div>
                <button type="button" class="btn btn-primary btn-sm" onclick="addSyllabus()"><i class="fas fa-upload"></i> Upload</button>
            </form>
        </div>
        <div class="card"><div class="card-header"><h3><i class="fas fa-list"></i> All Syllabus</h3></div><div id="syllabusList" style="padding:16px"></div></div>
    </div>

    <!-- Message -->
    <div id="adminMsg" style="display:none;position:fixed;top:80px;right:20px;z-index:9999;max-width:350px"></div>

</main>
<?php include 'footer.php'; ?>

<script>
// ═══ TAB SWITCH ═══
document.querySelectorAll('.atab').forEach(function(t){
    t.addEventListener('click',function(){
        document.querySelectorAll('.atab').forEach(function(x){x.classList.remove('active')});
        document.querySelectorAll('.atab-content').forEach(function(x){x.classList.remove('active')});
        t.classList.add('active');
        document.getElementById('tab-'+t.dataset.tab).classList.add('active');
    });
});

// ═══ UTILITY ═══
function post(data, callback){
    var fd;
    if(data instanceof FormData){ fd=data; }
    else { fd=new URLSearchParams(data).toString(); }
    
    var opts = {method:'POST'};
    if(typeof fd === 'string'){
        opts.headers = {'Content-Type':'application/x-www-form-urlencoded'};
        opts.body = fd;
    } else {
        opts.body = fd;
    }
    
    fetch('admin_ajax.php', opts).then(function(r){return r.json()}).then(callback).catch(function(e){showMsg('Error: '+e.message,'err')});
}

function showMsg(text,type){
    var m=document.getElementById('adminMsg');
    m.innerHTML='<div class="alert alert-'+(type==='ok'?'success':'error')+'"><div class="alert-content"><i class="fas fa-'+(type==='ok'?'check-circle':'exclamation-circle')+'"></i><span>'+text+'</span></div></div>';
    m.style.display='block';
    setTimeout(function(){m.style.display='none'},3000);
}

function val(id){return document.getElementById(id).value.trim()}

// ═══ LOAD STATS ═══
function loadStats(){
    post({action:'get_stats'},function(d){
        if(d.ok){
            document.getElementById('sUsers').textContent=d.stats.users;
            document.getElementById('sSubjects').textContent=d.stats.subjects;
            document.getElementById('sVideos').textContent=d.stats.videos;
            document.getElementById('sNotes').textContent=d.stats.notes;
        }
    });
}
loadStats();

// ═══ SUBJECTS ═══
function addSubject(){
    post({action:'add_subject',name:val('subName'),class:val('subClass'),board:val('subBoard'),icon:val('subIcon'),color:val('subColor')},function(d){
        if(d.ok){showMsg('Subject added!','ok');loadAllSubjects();document.getElementById('subName').value='';}
        else showMsg(d.msg,'err');
    });
}

function loadAllSubjects(){
    post({action:'get_subjects'},function(d){
        if(!d.ok)return;
        var h='';
        if(d.data.length===0){h='<p class="empty-text">No subjects yet</p>';}
        else{
            h='<table class="admin-table"><tr><th>Name</th><th>Class</th><th>Board</th><th>Icon</th><th>Actions</th></tr>';
            d.data.forEach(function(s){
                h+='<tr><td><i class="fas '+s.icon+'" style="color:'+s.color+';margin-right:6px"></i>'+s.name+'</td><td>'+s.class+'</td><td>'+s.board+'</td><td>'+s.icon+'</td>';
                h+='<td><button class="btn btn-sm btn-danger" onclick="if(confirm(\'Delete?\'))delSubject('+s.id+')"><i class="fas fa-trash"></i></button></td></tr>';
            });
            h+='</table>';
        }
        document.getElementById('subjectsList').innerHTML=h;
    });
}
loadAllSubjects();

function delSubject(id){post({action:'delete_subject',id:id},function(){showMsg('Deleted','ok');loadAllSubjects();loadStats()});}

// ═══ CHAPTERS ═══
function addChapter(){
    post({action:'add_chapter',subject_id:val('chSubject'),chapter_number:val('chNum'),title:val('chTitle'),description:val('chDesc')},function(d){
        if(d.ok){showMsg('Chapter added!','ok');document.getElementById('chTitle').value='';document.getElementById('chDesc').value='';loadChapters();}
        else showMsg(d.msg,'err');
    });
}

function loadChapters(){
    var sid=val('chFilterSub');
    if(!sid){document.getElementById('chaptersList').innerHTML='<p class="empty-text">Select a subject</p>';return;}
    post({action:'get_chapters',subject_id:sid},function(d){
        if(!d.ok)return;
        var h='';
        if(d.data.length===0){h='<p class="empty-text">No chapters</p>';}
        else{
            h='<table class="admin-table"><tr><th>#</th><th>Title</th><th>Description</th><th>Actions</th></tr>';
            d.data.forEach(function(c){
                h+='<tr><td>Ch '+c.chapter_number+'</td><td>'+c.title+'</td><td>'+(c.description||'-')+'</td>';
                h+='<td><button class="btn btn-sm btn-danger" onclick="if(confirm(\'Delete?\'))delChapter('+c.id+')"><i class="fas fa-trash"></i></button></td></tr>';
            });
            h+='</table>';
        }
        document.getElementById('chaptersList').innerHTML=h;
    });
}

function delChapter(id){post({action:'delete_chapter',id:id},function(){showMsg('Deleted','ok');loadChapters();loadStats()});}

// ═══ VIDEOS ═══
function addVideo(){
    post({action:'add_video',chapter_id:val('vidChapter'),title:val('vidTitle'),youtube_url:val('vidUrl'),duration:val('vidDur')},function(d){
        if(d.ok){showMsg('Video added!','ok');document.getElementById('vidTitle').value='';document.getElementById('vidUrl').value='';document.getElementById('vidDur').value='';loadVideos();}
        else showMsg(d.msg,'err');
    });
}

function loadVideos(){
    var cid=val('vidFilterCh');
    if(!cid){document.getElementById('videosList').innerHTML='<p class="empty-text">Select a chapter</p>';return;}
    post({action:'get_videos',chapter_id:cid},function(d){
        if(!d.ok)return;
        var h='';
        if(d.data.length===0){h='<p class="empty-text">No videos</p>';}
        else{
            h='<table class="admin-table"><tr><th>Title</th><th>Duration</th><th>URL</th><th>Actions</th></tr>';
            d.data.forEach(function(v){
                h+='<tr><td>'+v.title+'</td><td>'+v.duration+'</td><td style="max-width:200px;overflow:hidden;text-overflow:ellipsis"><a href="'+v.youtube_url+'" target="_blank">Link</a></td>';
                h+='<td><button class="btn btn-sm btn-danger" onclick="if(confirm(\'Delete?\'))delVideo('+v.id+')"><i class="fas fa-trash"></i></button></td></tr>';
            });
            h+='</table>';
        }
        document.getElementById('videosList').innerHTML=h;
    });
}

function delVideo(id){post({action:'delete_video',id:id},function(){showMsg('Deleted','ok');loadVideos();loadStats()});}

// ═══ NOTES ═══
function addNote(){
    post({action:'add_note',chapter_id:val('noteChapter'),title:val('noteTitle'),content:document.getElementById('noteContent').value,pdf_url:val('notePdf')},function(d){
        if(d.ok){showMsg('Note added!','ok');document.getElementById('noteTitle').value='';document.getElementById('noteContent').value='';}
        else showMsg(d.msg,'err');
    });
}

// ═══ PYQs ═══
function addPyq(){
    var fd=new FormData();
    fd.append('action','add_pyq');
    fd.append('subject_id',val('pyqSubject'));
    fd.append('year',val('pyqYear'));
    fd.append('title',val('pyqTitle'));
    fd.append('pdf',document.getElementById('pyqFile').files[0]);

    post(fd,function(d){
        if(d.ok){showMsg('PYQ uploaded!','ok');loadPyqs();document.getElementById('pyqForm').reset();}
        else showMsg(d.msg,'err');
    });
}

function loadPyqs(){
    post({action:'get_pyqs'},function(d){
        if(!d.ok)return;
        var h='';
        if(d.data.length===0){h='<p class="empty-text">No PYQs</p>';}
        else{
            h='<table class="admin-table"><tr><th>Title</th><th>Subject</th><th>Year</th><th>Actions</th></tr>';
            d.data.forEach(function(p){
                h+='<tr><td>'+p.title+'</td><td>'+p.subject_name+'</td><td>'+p.year+'</td>';
                h+='<td><a href="'+p.pdf_url+'" target="_blank" class="btn btn-sm btn-outline">View</a> <button class="btn btn-sm btn-danger" onclick="if(confirm(\'Delete?\'))delPyq('+p.id+')"><i class="fas fa-trash"></i></button></td></tr>';
            });
            h+='</table>';
        }
        document.getElementById('pyqsList').innerHTML=h;
    });
}
loadPyqs();

function delPyq(id){post({action:'delete_pyq',id:id},function(){showMsg('Deleted','ok');loadPyqs()});}

// ═══ SYLLABUS ═══
function addSyllabus(){
    var fd=new FormData();
    fd.append('action','add_syllabus');
    fd.append('class',val('sylClass'));
    fd.append('board',val('sylBoard'));
    fd.append('title',val('sylTitle'));
    fd.append('subject_id',val('sylSubject'));
    fd.append('pdf',document.getElementById('sylFile').files[0]);

    post(fd,function(d){
        if(d.ok){showMsg('Syllabus uploaded!','ok');loadSyllabus();document.getElementById('sylForm').reset();}
        else showMsg(d.msg,'err');
    });
}

function loadSyllabus(){
    post({action:'get_syllabus'},function(d){
        if(!d.ok)return;
        var h='';
        if(d.data.length===0){h='<p class="empty-text">No syllabus</p>';}
        else{
            h='<table class="admin-table"><tr><th>Title</th><th>Class</th><th>Board</th><th>Subject</th><th>Actions</th></tr>';
            d.data.forEach(function(s){
                h+='<tr><td>'+s.title+'</td><td>'+s.class+'</td><td>'+s.board+'</td><td>'+(s.subject_name||'General')+'</td>';
                h+='<td><a href="'+s.pdf_url+'" target="_blank" class="btn btn-sm btn-outline">View</a> <button class="btn btn-sm btn-danger" onclick="if(confirm(\'Delete?\'))delSyllabus('+s.id+')"><i class="fas fa-trash"></i></button></td></tr>';
            });
            h+='</table>';
        }
        document.getElementById('syllabusList').innerHTML=h;
    });
}
loadSyllabus();

function delSyllabus(id){post({action:'delete_syllabus',id:id},function(){showMsg('Deleted','ok');loadSyllabus()});}
</script>
</body>
</html>