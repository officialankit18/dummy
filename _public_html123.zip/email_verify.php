<?php
/**
 * ============================================
 * SHIKSHARTHI - Email OTP Verification Page
 * ============================================
 * Shared page for:
 * 1. Registration OTP verification
 * 2. Forgot Password OTP verification
 * 
 * Flow:
 * - OTP input form dikhao
 * - Verify karo
 * - Registration: User save karo DB me → login.php
 * - Forgot Password: Reset flag set karo → forgot_password.php
 * ============================================
 */

require_once __DIR__ . '/security.php';
require_once __DIR__ . '/email.php';

// Already logged in? Profile pe bhej do
redirectIfLoggedIn();

// ── Session me OTP data hai? Nahi toh wapas bhej do ──
if (empty($_SESSION['otp_email']) || empty($_SESSION['otp_purpose'])) {
    setFlash('error', 'Pehle registration ya forgot password form bharo.');
    redirect('register.php');
}

$email   = $_SESSION['otp_email'];
$purpose = $_SESSION['otp_purpose'];
$errors  = [];

// ── Email mask karo (privacy ke liye) ──
function maskEmail($e) {
    $parts  = explode('@', $e);
    $name   = $parts[0];
    $domain = $parts[1];
    $len    = strlen($name);
    if ($len <= 3) {
        $masked = $name[0] . str_repeat('*', $len - 1);
    } else {
        $masked = substr($name, 0, 2) . str_repeat('*', $len - 4) . substr($name, -2);
    }
    return $masked . '@' . $domain;
}
$maskedEmail = maskEmail($email);

// ── Timer calculation (page refresh pe bhi sahi dikhe) ──
$otpSentAt        = $_SESSION['otp_sent_at'] ?? time();
$expiresAt        = $otpSentAt + OTP_EXPIRY_SECONDS;
$remainingSeconds = max(0, $expiresAt - time());

/* ══════════════════════════════════════════════
   FORM SUBMISSION HANDLE
   ══════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF verify
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Security token expired. Refresh karke try karo.';
    }

    $action = $_POST['action'] ?? '';

    // ═══════════════════════════════════════════
    // ACTION: VERIFY OTP
    // ═══════════════════════════════════════════
    if ($action === 'verify' && empty($errors)) {

        $otpInput = trim($_POST['otp'] ?? '');

        // Basic validation
        if (empty($otpInput)) {
            $errors[] = 'OTP daalna zaroori hai.';
        } elseif (!preg_match('/^\d{' . OTP_LENGTH . '}$/', $otpInput)) {
            $errors[] = OTP_LENGTH . ' digit ka valid OTP daalo.';
        }

        if (empty($errors)) {
            // OTP verify karo (security.php ka function)
            $result = verifyOTP($email, $otpInput, $purpose);

            if ($result['success']) {

                // ── PURPOSE: REGISTRATION ──
                if ($purpose === 'registration') {
                    // Session se registration data lo
                    $regData = $_SESSION['reg_data'] ?? null;

                    if (!$regData) {
                        $errors[] = 'Registration data expire ho gaya. Dubara register karo.';
                    } else {
                        // User ko database me save karo
                        try {
                            $db   = getDB();
                            $stmt = $db->prepare(
                                "INSERT INTO users (name, email, password, profile_photo, state, city, class, board, is_verified)
                                 VALUES (:name, :email, :password, :photo, :state, :city, :class, :board, 1)"
                            );
                            $stmt->execute([
                                ':name'     => $regData['name'],
                                ':email'    => $regData['email'],
                                ':password' => $regData['password'],
                                ':photo'    => $regData['profile_photo'],
                                ':state'    => $regData['state'],
                                ':city'     => $regData['city'],
                                ':class'    => $regData['class'],
                                ':board'    => $regData['board']
                            ]);

                            // Welcome email bhejo (optional - fail hone pe bhi chalega)
                            sendWelcomeEmail($regData['email'], $regData['name']);

                            // Session cleanup
                            unset(
                                $_SESSION['reg_data'],
                                $_SESSION['otp_email'],
                                $_SESSION['otp_purpose'],
                                $_SESSION['otp_sent_at']
                            );

                            setFlash('success', '🎉 Registration successful! Ab login karo.');
                            redirect('login.php');

                        } catch (PDOException $e) {
                            error_log("Registration DB Error: " . $e->getMessage());
                            // Duplicate email check
                            if ($e->getCode() == 23000) {
                                $errors[] = 'Ye email pehle se registered hai.';
                            } else {
                                $errors[] = 'Server error. Please try again.';
                            }
                        }
                    }
                }

                // ── PURPOSE: FORGOT PASSWORD ──
                elseif ($purpose === 'forgot_password') {
                    // Reset verified flag set karo
                    $_SESSION['reset_verified'] = true;
                    $_SESSION['reset_email']    = $email;

                    // OTP session cleanup
                    unset(
                        $_SESSION['otp_email'],
                        $_SESSION['otp_purpose'],
                        $_SESSION['otp_sent_at']
                    );

                    setFlash('success', 'OTP verified! Ab naya password set karo.');
                    redirect('forgot_password.php?step=reset');
                }

            } else {
                // OTP verification failed
                $errors[] = $result['message'];
            }
        }
    }

    // ═══════════════════════════════════════════
    // ACTION: RESEND OTP
    // ═══════════════════════════════════════════
    elseif ($action === 'resend' && empty($errors)) {

        $ip = getUserIP();

        // Rate limit check
        if (!checkRateLimit($ip, 'otp_send', MAX_OTP_SEND_PER_HOUR, 3600)) {
            $errors[] = 'Bahut zyada OTP requests. Thodi der baad try karo.';
        } elseif (!checkRateLimit($email, 'otp_send', MAX_OTP_SEND_PER_HOUR, 3600)) {
            $errors[] = 'Is email pe bahut OTP bheje gaye. Thodi der baad try karo.';
        } else {
            // New OTP generate (purana auto-invalidate ho jayega)
            $otp = generateOTP();
            saveOTP($email, $otp, $purpose);
            addRateLimitRecord($ip, 'otp_send');
            addRateLimitRecord($email, 'otp_send');

            // Name fetch karo email ke liye
            $recipientName = 'Student';
            if ($purpose === 'registration' && isset($_SESSION['reg_data']['name'])) {
                $recipientName = $_SESSION['reg_data']['name'];
            } elseif ($purpose === 'forgot_password') {
                $db   = getDB();
                $stmt = $db->prepare("SELECT name FROM users WHERE email = :email LIMIT 1");
                $stmt->execute([':email' => $email]);
                $user = $stmt->fetch();
                if ($user) $recipientName = $user['name'];
            }

            $emailResult = sendOTPEmail($email, $otp, $purpose, $recipientName);

            if ($emailResult['success']) {
                $_SESSION['otp_sent_at'] = time();
                $otpSentAt        = time();
                $expiresAt        = $otpSentAt + OTP_EXPIRY_SECONDS;
                $remainingSeconds = OTP_EXPIRY_SECONDS;
                setFlash('success', 'Naya OTP bhej diya gaya hai!');
                // Redirect to avoid resubmission
                redirect('email_verify.php');
            } else {
                $errors[] = 'Email bhejne me problem aayi. Try again.';
            }
        }
    }
}

$flash = getFlash();
$purposeText = ($purpose === 'registration') ? 'Email Verification' : 'Password Reset';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Email - SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="auth-body">

    <div class="auth-wrapper">
        <div class="auth-card auth-card-narrow">

            <!-- ═══ HEADER ═══ -->
            <div class="auth-header">
                <h1 class="auth-logo">🎓 SHIKSHARTHI</h1>
                <p class="auth-tagline"><?= $purposeText ?></p>
            </div>

            <!-- ═══ BODY ═══ -->
            <div class="auth-body-content center-content">

                <!-- Flash Message -->
                <?php if ($flash): ?>
                    <div class="alert alert-<?= $flash['type'] ?>">
                        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($flash['message']) ?>
                    </div>
                <?php endif; ?>

                <!-- Errors -->
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        <ul class="error-list">
                            <?php foreach ($errors as $err): ?>
                                <li><?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- OTP Icon -->
                <div class="otp-icon">
                    <i class="fas fa-envelope-open-text"></i>
                </div>

                <p class="otp-instruction">
                    Humne <strong><?= htmlspecialchars($maskedEmail) ?></strong> pe
                    <?= OTP_LENGTH ?> digit ka OTP bheja hai.
                </p>

                <!-- OTP Timer -->
                <div class="otp-timer" id="otpTimer">
                    <i class="fas fa-clock"></i>
                    <span id="timerText">--:--</span>
                </div>

                <!-- ═══ OTP FORM ═══ -->
                <form method="POST" id="otpForm">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="verify">

                    <div class="form-group">
                        <input type="text" id="otp" name="otp" class="form-input otp-input"
                               placeholder="<?= str_repeat('•', OTP_LENGTH) ?>"
                               maxlength="<?= OTP_LENGTH ?>"
                               pattern="\d{<?= OTP_LENGTH ?>}"
                               inputmode="numeric"
                               autocomplete="one-time-code"
                               required autofocus>
                    </div>

                    <button type="submit" class="btn btn-primary btn-full" id="verifyBtn">
                        <i class="fas fa-shield-alt"></i> Verify OTP
                    </button>
                </form>

                <!-- ═══ RESEND FORM ═══ -->
                <form method="POST" class="resend-form" id="resendForm">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="resend">
                    <p class="resend-text">OTP nahi mila?</p>
                    <button type="submit" class="btn btn-outline btn-small" id="resendBtn" disabled>
                        <i class="fas fa-redo"></i> Resend OTP
                        <span id="resendTimer"></span>
                    </button>
                </form>

                <!-- Back Link -->
                <div class="auth-footer">
                    <?php if ($purpose === 'registration'): ?>
                        <a href="register.php" class="auth-link"><i class="fas fa-arrow-left"></i> Back to Register</a>
                    <?php else: ?>
                        <a href="forgot_password.php" class="auth-link"><i class="fas fa-arrow-left"></i> Back</a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>

    <!-- ═══ JAVASCRIPT ═══ -->
    <script>
    (function() {
        /* ── OTP Expiry Countdown Timer ── */
        let remaining = <?= (int)$remainingSeconds ?>;
        const timerEl    = document.getElementById('timerText');
        const timerBox   = document.getElementById('otpTimer');
        const verifyBtn  = document.getElementById('verifyBtn');

        function updateTimer() {
            if (remaining <= 0) {
                timerEl.textContent = 'OTP Expired!';
                timerBox.classList.add('expired');
                verifyBtn.disabled = true;
                verifyBtn.innerHTML = '<i class="fas fa-times-circle"></i> OTP Expired';
                return;
            }
            const m = Math.floor(remaining / 60);
            const s = remaining % 60;
            timerEl.textContent = m.toString().padStart(2,'0') + ':' + s.toString().padStart(2,'0');
            remaining--;
            setTimeout(updateTimer, 1000);
        }
        updateTimer();

        /* ── Resend Button Cooldown (60 sec) ── */
        let resendCooldown = 60;
        const resendBtn   = document.getElementById('resendBtn');
        const resendTimer = document.getElementById('resendTimer');

        function updateResend() {
            if (resendCooldown <= 0) {
                resendBtn.disabled = false;
                resendTimer.textContent = '';
                return;
            }
            resendBtn.disabled = true;
            resendTimer.textContent = ' (' + resendCooldown + 's)';
            resendCooldown--;
            setTimeout(updateResend, 1000);
        }
        updateResend();

        /* ── OTP Input: Only digits allowed ── */
        document.getElementById('otp').addEventListener('input', function() {
            this.value = this.value.replace(/\D/g, '').substring(0, <?= OTP_LENGTH ?>);
        });

        /* ── Form Loading State ── */
        document.getElementById('otpForm').addEventListener('submit', function() {
            verifyBtn.disabled = true;
            verifyBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
        });
    })();
    </script>

</body>
</html>