<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';
requireLogin();

$user = getCurrentUser();
if (!$user) { redirect('login.php'); exit; }

$userClass = $user['class'];
$userBoard = $user['board'];

// ── Get subjects ──
$subjects = $pdo->prepare("SELECT * FROM subjects WHERE class = ? AND board = ? ORDER BY sort_order");
$subjects->execute([$userClass, $userBoard]);
$subjects = $subjects->fetchAll(PDO::FETCH_ASSOC);

// ── Selected subject ──
$subjectId = (int)($_GET['subject'] ?? 0);
$chapterId = (int)($_GET['chapter'] ?? 0);
$selectedSubject = null;
$chapters = [];
$videos = [];
$currentVideo = null;

if ($subjectId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM subjects WHERE id = ? AND class = ? AND board = ?");
    $stmt->execute([$subjectId, $userClass, $userBoard]);
    $selectedSubject = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($selectedSubject) {
        $stmt = $pdo->prepare("SELECT c.*, 
            (SELECT COUNT(*) FROM videos WHERE chapter_id = c.id) as total_videos,
            (SELECT COUNT(*) FROM user_progress up JOIN videos v ON up.content_id = v.id WHERE v.chapter_id = c.id AND up.user_id = ? AND up.content_type = 'video') as done_videos
            FROM chapters c WHERE c.subject_id = ? ORDER BY c.chapter_number");
        $stmt->execute([$_SESSION['user_id'], $subjectId]);
        $chapters = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

if ($chapterId > 0 && $selectedSubject) {
    $stmt = $pdo->prepare("SELECT v.*, 
        (SELECT COUNT(*) FROM user_progress WHERE user_id = ? AND content_type = 'video' AND content_id = v.id) as is_completed
        FROM videos v WHERE v.chapter_id = ? ORDER BY v.sort_order");
    $stmt->execute([$_SESSION['user_id'], $chapterId]);
    $videos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $videoId = (int)($_GET['v'] ?? 0);
    if ($videoId > 0) {
        foreach ($videos as $vid) {
            if ($vid['id'] == $videoId) { $currentVideo = $vid; break; }
        }
    }
    if (!$currentVideo && !empty($videos)) {
        $currentVideo = $videos[0];
    }
}

// YouTube ID extractor
function getYouTubeId($url) {
    $pattern = '/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/';
    preg_match($pattern, $url, $matches);
    return $matches[1] ?? '';
}

// Get current chapter info
$currentChapter = null;
if ($chapterId > 0) {
    foreach ($chapters as $ch) {
        if ($ch['id'] == $chapterId) { $currentChapter = $ch; break; }
    }
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Videos — SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="app-body">
<?php include 'navbar.php'; ?>

<main class="main-content">

    <!-- Breadcrumb -->
    <div class="breadcrumb">
        <a href="videos.php"><i class="fas fa-play-circle"></i> Videos</a>
        <?php if ($selectedSubject): ?>
            <span class="bc-sep"><i class="fas fa-chevron-right"></i></span>
            <a href="videos.php?subject=<?= $subjectId ?>"><?= htmlspecialchars($selectedSubject['name']) ?></a>
        <?php endif; ?>
        <?php if ($currentChapter): ?>
            <span class="bc-sep"><i class="fas fa-chevron-right"></i></span>
            <span>Chapter <?= $currentChapter['chapter_number'] ?></span>
        <?php endif; ?>
    </div>

    <?php if (!$subjectId): ?>
    <!-- ═══ SUBJECTS GRID ═══ -->
    <div class="page-header">
        <h1><i class="fas fa-play-circle"></i> Video Lectures</h1>
        <p>Class <?= htmlspecialchars($userClass) ?> — <?= htmlspecialchars($userBoard) ?> Board</p>
    </div>

    <div class="subjects-grid">
        <?php foreach ($subjects as $sub): ?>
            <a href="videos.php?subject=<?= $sub['id'] ?>" class="subject-card" style="--card-color:<?= $sub['color'] ?>">
                <div class="subject-icon"><i class="fas <?= $sub['icon'] ?>"></i></div>
                <h3><?= htmlspecialchars($sub['name']) ?></h3>
                <span class="subject-meta">
                    <?php
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM chapters WHERE subject_id = ?");
                    $stmt->execute([$sub['id']]);
                    echo $stmt->fetchColumn() . ' Chapters';
                    ?>
                </span>
            </a>
        <?php endforeach; ?>
    </div>

    <?php elseif ($subjectId && !$chapterId): ?>
    <!-- ═══ CHAPTERS LIST ═══ -->
    <div class="page-header">
        <h1><i class="fas <?= $selectedSubject['icon'] ?>"></i> <?= htmlspecialchars($selectedSubject['name']) ?></h1>
        <p>Select a chapter to watch video lectures</p>
    </div>

    <div class="chapters-list">
        <?php foreach ($chapters as $ch): ?>
            <?php $pct = $ch['total_videos'] > 0 ? round(($ch['done_videos'] / $ch['total_videos']) * 100) : 0; ?>
            <a href="videos.php?subject=<?= $subjectId ?>&chapter=<?= $ch['id'] ?>" class="chapter-card">
                <div class="chapter-num">Ch <?= $ch['chapter_number'] ?></div>
                <div class="chapter-info">
                    <h3><?= htmlspecialchars($ch['title']) ?></h3>
                    <p><?= htmlspecialchars($ch['description'] ?? '') ?></p>
                    <div class="chapter-meta">
                        <span><i class="fas fa-play"></i> <?= $ch['total_videos'] ?> Videos</span>
                        <span><i class="fas fa-check-circle"></i> <?= $ch['done_videos'] ?>/<?= $ch['total_videos'] ?> Done</span>
                    </div>
                    <div class="progress-bar"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
                </div>
                <div class="chapter-pct"><?= $pct ?>%</div>
            </a>
        <?php endforeach; ?>
    </div>

    <?php elseif ($currentVideo): ?>
    <!-- ═══ VIDEO PLAYER ═══ -->
    <div class="video-layout">
        <div class="video-player-section">
            <div class="video-player">
                <iframe 
                    src="https://www.youtube.com/embed/<?= getYouTubeId($currentVideo['youtube_url']) ?>?rel=0" 
                    frameborder="0" 
                    allowfullscreen
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture">
                </iframe>
            </div>
            <div class="video-info-bar">
                <div>
                    <h2><?= htmlspecialchars($currentVideo['title']) ?></h2>
                    <p class="video-duration"><i class="fas fa-clock"></i> <?= $currentVideo['duration'] ?></p>
                </div>
                <button class="btn-mark <?= $currentVideo['is_completed'] ? 'completed' : '' ?>" 
                        onclick="toggleComplete('video', <?= $currentVideo['id'] ?>, this)">
                    <i class="fas <?= $currentVideo['is_completed'] ? 'fa-check-circle' : 'fa-circle' ?>"></i>
                    <span><?= $currentVideo['is_completed'] ? 'Completed' : 'Mark as Complete' ?></span>
                </button>
            </div>
        </div>

        <div class="video-sidebar">
            <h3><i class="fas fa-list"></i> Videos in this Chapter</h3>
            <div class="video-list">
                <?php foreach ($videos as $i => $v): ?>
                    <a href="videos.php?subject=<?= $subjectId ?>&chapter=<?= $chapterId ?>&v=<?= $v['id'] ?>" 
                       class="video-list-item <?= $v['id'] == $currentVideo['id'] ? 'playing' : '' ?> <?= $v['is_completed'] ? 'done' : '' ?>">
                        <span class="vl-num"><?= $i + 1 ?></span>
                        <div class="vl-info">
                            <span class="vl-title"><?= htmlspecialchars($v['title']) ?></span>
                            <span class="vl-dur"><?= $v['duration'] ?></span>
                        </div>
                        <?php if ($v['is_completed']): ?>
                            <i class="fas fa-check-circle vl-check"></i>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

</main>

<?php include 'footer.php'; ?>

<script>
function toggleComplete(type, id, btn) {
    fetch('ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=toggle_complete&type=' + type + '&id=' + id
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (data.completed) {
                btn.classList.add('completed');
                btn.innerHTML = '<i class="fas fa-check-circle"></i><span>Completed</span>';
            } else {
                btn.classList.remove('completed');
                btn.innerHTML = '<i class="fas fa-circle"></i><span>Mark as Complete</span>';
            }
        }
    });
}
</script>
</body>
</html>