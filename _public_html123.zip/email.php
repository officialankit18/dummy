<?php
/**
 * ============================================
 * SHIKSHARTHI - Email Module (REUSABLE)
 * ============================================
 * Brevo (Sendinblue) SMTP + PHPMailer
 * 300 emails/day FREE
 * 
 * 🔄 REUSABLE: Include this file anywhere and
 *    call sendEmail() or sendOTPEmail()
 * 
 * USAGE:
 *   require_once 'email.php';
 *   
 *   // General email:
 *   $result = sendEmail('user@example.com', 'Subject', '<h1>Hello</h1>');
 *   
 *   // OTP email:
 *   $result = sendOTPEmail('user@example.com', '123456', 'registration', 'Rahul');
 * 
 * 🔒 This file cannot be accessed directly from the browser
 * ============================================
 */

// Constants needed (for SMTP settings)
require_once __DIR__ . '/constants.php';

// ── Load PHPMailer files ──
// These 3 files should be in vendor/phpmailer/
require_once __DIR__ . '/vendor/phpmailer/PHPMailer.php';
require_once __DIR__ . '/vendor/phpmailer/SMTP.php';
require_once __DIR__ . '/vendor/phpmailer/Exception.php';

// PHPMailer namespaces
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


/* ══════════════════════════════════════════════
   GENERAL EMAIL FUNCTION
   
   Send any email to anyone
   This is the base function - most versatile
   ══════════════════════════════════════════════ */

/**
 * Send email via Brevo SMTP
 * 
 * @param string $toEmail  - Receiver's email
 * @param string $subject  - Email subject
 * @param string $htmlBody - HTML email body
 * @param string $toName   - Receiver's name (optional)
 * @return array ['success' => bool, 'message' => string]
 */
function sendEmail($toEmail, $subject, $htmlBody, $toName = '') {
    $mail = new PHPMailer(true); // true = exceptions enabled
    
    try {
        /* ── SMTP Configuration (Brevo) ── */
        $mail->isSMTP();                                    // Use SMTP
        $mail->Host       = SMTP_HOST;                      // smtp-relay.brevo.com
        $mail->SMTPAuth   = true;                           // Authentication ON
        $mail->Username   = SMTP_USER;                      // Brevo email
        $mail->Password   = SMTP_PASS;                      // Brevo SMTP key
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // TLS encryption
        $mail->Port       = SMTP_PORT;                      // 587
        $mail->CharSet    = 'UTF-8';                        // Unicode support
        $mail->Encoding   = 'base64';                       // Encoding
        
        // Timeout (fail if no response in 30 seconds)
        $mail->Timeout       = 30;
        $mail->SMTPKeepAlive = false;
        
        /* ── Sender & Receiver ── */
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);   // From: SHIKSHARTHI
        $mail->addAddress($toEmail, $toName);                // To: Student
        $mail->addReplyTo(SMTP_FROM_EMAIL, SMTP_FROM_NAME); // Reply-To
        
        /* ── Email Content ── */
        $mail->isHTML(true);                    // HTML email
        $mail->Subject = $subject;
        $mail->Body    = $htmlBody;
        
        // Plain text version (for clients that don't support HTML)
        $mail->AltBody = strip_tags(
            str_replace(
                ['<br>', '<br/>', '<br />', '</p>', '</div>', '</li>'],
                "\n",
                $htmlBody
            )
        );
        
        /* ── SEND! ── */
        $mail->send();
        
        return [
            'success' => true,
            'message' => 'Email has been sent successfully!'
        ];
        
    } catch (Exception $e) {
        // Log error (for debugging)
        error_log("SHIKSHARTHI Email Error: " . $mail->ErrorInfo);
        
        return [
            'success' => false,
            'message' => 'There was a problem sending the email. Please try again shortly.'
        ];
    }
}


/* ══════════════════════════════════════════════
   OTP EMAIL FUNCTION
   
   Send OTP with a beautiful HTML template
   Works for both Registration and Forgot Password
   ══════════════════════════════════════════════ */

/**
 * Send OTP email (with beautiful template)
 * 
 * @param string $email   - Student's email
 * @param string $otp     - 6 digit OTP
 * @param string $purpose - 'registration' or 'forgot_password'
 * @param string $name    - Student's name
 * @return array ['success' => bool, 'message' => string]
 */
function sendOTPEmail($email, $otp, $purpose = 'registration', $name = 'Student') {
    
    // Customize content based on purpose
    if ($purpose === 'registration') {
        $subject  = '🎓 SHIKSHARTHI - Email Verification OTP';
        $heading  = 'Email Verification';
        $message  = 'Use the OTP given below to verify your email address:';
        $icon     = '✉️';
    } else {
        $subject  = '🔒 SHIKSHARTHI - Password Reset OTP';
        $heading  = 'Password Reset';
        $message  = 'Use the OTP given below to reset your password:';
        $icon     = '🔑';
    }
    
    $expiryMinutes = OTP_EXPIRY_SECONDS / 60;
    $year = date('Y');
    
    // ── Beautiful HTML Email Template ──
    $htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$subject}</title>
</head>
<body style="margin:0; padding:0; background-color:#f0f2f5; font-family: 'Segoe UI', Arial, sans-serif;">
    
    <!-- Outer Container -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0" 
           style="background-color:#f0f2f5; padding:40px 20px;">
        <tr>
            <td align="center">
                
                <!-- Email Card -->
                <table width="580" cellpadding="0" cellspacing="0" border="0" 
                       style="background-color:#ffffff; border-radius:16px; 
                              box-shadow:0 4px 24px rgba(0,0,0,0.08); overflow:hidden;
                              max-width:580px; width:100%;">
                    
                    <!-- ═══ HEADER ═══ -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #a855f7 100%); 
                                   padding:32px 30px; text-align:center;">
                            <h1 style="color:#ffffff; margin:0; font-size:28px; 
                                       font-weight:700; letter-spacing:3px;">
                                🎓 SHIKSHARTHI
                            </h1>
                            <p style="color:rgba(255,255,255,0.8); margin:8px 0 0; 
                                      font-size:13px; letter-spacing:1px;">
                                AI Personalized Learning Platform
                            </p>
                        </td>
                    </tr>
                    
                    <!-- ═══ BODY ═══ -->
                    <tr>
                        <td style="padding:40px 36px;">
                            
                            <!-- Icon + Heading -->
                            <div style="text-align:center; margin-bottom:24px;">
                                <span style="font-size:48px;">{$icon}</span>
                                <h2 style="color:#1f2937; margin:12px 0 0; font-size:22px; font-weight:600;">
                                    {$heading}
                                </h2>
                            </div>
                            
                            <!-- Greeting -->
                            <p style="color:#4b5563; font-size:15px; line-height:1.7; margin:0 0 8px;">
                                Hello <strong style="color:#1f2937;">{$name}</strong> 👋
                            </p>
                            <p style="color:#4b5563; font-size:15px; line-height:1.7; margin:0 0 28px;">
                                {$message}
                            </p>
                            
                            <!-- ═══ OTP BOX ═══ -->
                            <div style="text-align:center; margin:0 0 28px;">
                                <div style="display:inline-block; 
                                            background: linear-gradient(135deg, #6366f1, #8b5cf6); 
                                            padding:22px 48px; border-radius:12px;
                                            box-shadow:0 4px 16px rgba(99,102,241,0.3);">
                                    <span style="font-size:38px; font-weight:800; color:#ffffff; 
                                                 letter-spacing:14px; font-family: 'Courier New', monospace;">
                                        {$otp}
                                    </span>
                                </div>
                            </div>
                            
                            <!-- Timer -->
                            <p style="color:#9ca3af; font-size:13px; text-align:center; margin:0 0 28px;">
                                ⏱️ This OTP will expire in <strong style="color:#6366f1;">{$expiryMinutes} minutes</strong>
                            </p>
                            
                            <!-- Divider -->
                            <hr style="border:none; border-top:1px solid #e5e7eb; margin:28px 0;">
                            
                            <!-- Security Warning -->
                            <div style="background-color:#fef3c7; border-left:4px solid #f59e0b; 
                                        padding:14px 18px; border-radius:0 10px 10px 0;">
                                <p style="color:#92400e; margin:0; font-size:13px; line-height:1.6;">
                                    ⚠️ <strong>Security Warning:</strong><br>
                                    • Do <strong>not share</strong> this OTP with anyone<br>
                                    • SHIKSHARTHI will never ask for your OTP via phone or email<br>
                                    • If you did not request this, please ignore this email
                                </p>
                            </div>
                            
                        </td>
                    </tr>
                    
                    <!-- ═══ FOOTER ═══ -->
                    <tr>
                        <td style="background-color:#f9fafb; padding:24px 36px; 
                                   text-align:center; border-top:1px solid #e5e7eb;">
                            <p style="color:#9ca3af; font-size:12px; margin:0 0 6px;">
                                © {$year} SHIKSHARTHI. All rights reserved.
                            </p>
                            <p style="color:#d1d5db; font-size:11px; margin:0;">
                                This is an automated email. Please do not reply.
                            </p>
                        </td>
                    </tr>
                    
                </table>
                
            </td>
        </tr>
    </table>
    
</body>
</html>
HTML;
    
    // Send email (using the general sendEmail function)
    return sendEmail($email, $subject, $htmlBody, $name);
}


/* ══════════════════════════════════════════════
   WELCOME EMAIL (After Registration)
   
   Optional - send a welcome email after
   registration is complete
   ══════════════════════════════════════════════ */

/**
 * Send welcome email (after registration)
 */
function sendWelcomeEmail($email, $name) {
    $subject = '🎉 Welcome to SHIKSHARTHI, ' . $name . '!';
    $year = date('Y');
    $appUrl = APP_URL;
    $htmlBody = <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="margin:0; padding:0; background-color:#f0f2f5; font-family: 'Segoe UI', Arial, sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f0f2f5; padding:40px 20px;">
        <tr><td align="center">
            <table width="580" cellpadding="0" cellspacing="0" 
                   style="background:#fff; border-radius:16px; box-shadow:0 4px 24px rgba(0,0,0,0.08); 
                          overflow:hidden; max-width:580px; width:100%;">
                
                <tr>
                    <td style="background:linear-gradient(135deg, #10b981, #059669); padding:32px; text-align:center;">
                        <h1 style="color:#fff; margin:0; font-size:28px;">🎓 SHIKSHARTHI</h1>
                        <p style="color:rgba(255,255,255,0.8); margin:8px 0 0; font-size:13px; letter-spacing:1px;">
                            AI Personalized Learning Platform
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <td style="padding:40px 36px; text-align:center;">
                        <span style="font-size:64px;">🎉</span>
                        <h2 style="color:#1f2937; margin:16px 0 8px; font-size:24px;">
                            Welcome Aboard, {$name}!
                        </h2>
                        <p style="color:#4b5563; font-size:15px; line-height:1.8; margin:0 0 10px;">
                            Your account has been created successfully! 🚀<br>
                            We're thrilled to have you join the SHIKSHARTHI family.
                        </p>
                        <p style="color:#4b5563; font-size:15px; line-height:1.8; margin:0 0 24px;">
                            Your personalized learning journey starts right now. Get ready to learn smarter, 
                            not harder — powered by AI that adapts to <strong>you</strong>.
                        </p>

                        <!-- Features Section -->
                        <table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 28px; text-align:left;">
                            <tr>
                                <td style="padding:12px 16px; background:#f0fdf4; border-radius:10px; margin-bottom:8px;">
                                    <p style="margin:0; color:#166534; font-size:14px; line-height:1.6;">
                                        🤖 <strong>AI-Powered Personalization</strong><br>
                                        <span style="color:#4b5563; font-size:13px;">Smart learning paths that adapt to your pace, strengths, and goals in real time.</span>
                                    </p>
                                </td>
                            </tr>
                            <tr><td style="height:8px;"></td></tr>
                            <tr>
                                <td style="padding:12px 16px; background:#eff6ff; border-radius:10px;">
                                    <p style="margin:0; color:#1e40af; font-size:14px; line-height:1.6;">
                                        📊 <strong>Track Your Progress</strong><br>
                                        <span style="color:#4b5563; font-size:13px;">Beautiful dashboards & analytics to see how far you've come and what's next.</span>
                                    </p>
                                </td>
                            </tr>
                            <tr><td style="height:8px;"></td></tr>
                            <tr>
                                <td style="padding:12px 16px; background:#fdf4ff; border-radius:10px;">
                                    <p style="margin:0; color:#7e22ce; font-size:14px; line-height:1.6;">
                                        🧠 <strong>Smart Quizzes & Assessments</strong><br>
                                        <span style="color:#4b5563; font-size:13px;">AI-generated quizzes that test what matters — and help you remember it forever.</span>
                                    </p>
                                </td>
                            </tr>
                            <tr><td style="height:8px;"></td></tr>
                            <tr>
                                <td style="padding:12px 16px; background:#fefce8; border-radius:10px;">
                                    <p style="margin:0; color:#a16207; font-size:14px; line-height:1.6;">
                                        📚 <strong>Learn Any Subject, Your Way</strong><br>
                                        <span style="color:#4b5563; font-size:13px;">From Maths to Science to Coding — study what you love with content made just for you.</span>
                                    </p>
                                </td>
                            </tr>
                            <tr><td style="height:8px;"></td></tr>
                            <tr>
                                <td style="padding:12px 16px; background:#fff1f2; border-radius:10px;">
                                    <p style="margin:0; color:#be123c; font-size:14px; line-height:1.6;">
                                        🏆 <strong>Earn Badges & Stay Motivated</strong><br>
                                        <span style="color:#4b5563; font-size:13px;">Unlock achievements, earn rewards, and celebrate every milestone on your journey.</span>
                                    </p>
                                </td>
                            </tr>
                        </table>

                        <p style="color:#6b7280; font-size:14px; line-height:1.7; margin:0 0 24px; 
                                  font-style:italic; background:#f9fafb; padding:16px; border-radius:10px;">
                            "Education is not the filling of a pail, but the lighting of a fire." 🔥<br>
                            <span style="font-size:12px;">— W.B. Yeats</span><br><br>
                            Let SHIKSHARTHI light that fire for you. We believe in <strong>you</strong>!
                        </p>

                        <a href="{$appUrl}/login.php" 
                           style="display:inline-block; background:linear-gradient(135deg, #6366f1, #8b5cf6); 
                                  color:#fff; padding:14px 36px; border-radius:8px; text-decoration:none; 
                                  font-weight:600; margin-top:8px; font-size:15px;
                                  box-shadow:0 4px 16px rgba(99,102,241,0.3);">
                            🚀 Start Learning Now →
                        </a>
                    </td>
                </tr>
                
                <tr>
                    <td style="background:#f9fafb; padding:20px; text-align:center; border-top:1px solid #e5e7eb;">
                        <p style="color:#9ca3af; font-size:12px; margin:0 0 4px;">
                            © {$year} SHIKSHARTHI. All rights reserved.
                        </p>
                        <p style="color:#d1d5db; font-size:11px; margin:0;">
                            This is an automated email. Please do not reply.
                        </p>
                    </td>
                </tr>
            </table>
        </td></tr>
    </table>
</body>
</html>
HTML;

    return sendEmail($email, $subject, $htmlBody, $name);
}