<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';
requireLogin();

$user = getCurrentUser();
if (!$user) { redirect('login.php'); exit; }

$userId = $_SESSION['user_id'];
$userClass = $user['class'];
$userBoard = $user['board'];

// ── Get subjects with progress ──
$stmt = $pdo->prepare("SELECT * FROM subjects WHERE class = ? AND board = ? ORDER BY sort_order");
$stmt->execute([$userClass, $userBoard]);
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalAll = 0; $doneAll = 0;
$subjectProgress = [];

foreach ($subjects as $sub) {
    // Videos
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM videos v JOIN chapters c ON v.chapter_id=c.id WHERE c.subject_id=?");
    $stmt->execute([$sub['id']]);
    $tv = (int)$stmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_progress up JOIN videos v ON up.content_id=v.id JOIN chapters c ON v.chapter_id=c.id WHERE up.user_id=? AND up.content_type='video' AND c.subject_id=?");
    $stmt->execute([$userId, $sub['id']]);
    $dv = (int)$stmt->fetchColumn();

    // Notes
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notes n JOIN chapters c ON n.chapter_id=c.id WHERE c.subject_id=?");
    $stmt->execute([$sub['id']]);
    $tn = (int)$stmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_progress up JOIN notes n ON up.content_id=n.id JOIN chapters c ON n.chapter_id=c.id WHERE up.user_id=? AND up.content_type='note' AND c.subject_id=?");
    $stmt->execute([$userId, $sub['id']]);
    $dn = (int)$stmt->fetchColumn();

    $total = $tv + $tn;
    $done = $dv + $dn;
    $pct = $total > 0 ? round(($done/$total)*100) : 0;

    $totalAll += $total;
    $doneAll += $done;

    $subjectProgress[] = [
        'name' => $sub['name'],
        'icon' => $sub['icon'],
        'color' => $sub['color'],
        'total' => $total,
        'done' => $done,
        'percent' => $pct,
        'vt' => $tv, 'vd' => $dv,
        'nt' => $tn, 'nd' => $dn,
    ];
}

$overallPct = $totalAll > 0 ? round(($doneAll/$totalAll)*100) : 0;

// ── Recent activity ──
$stmt = $pdo->prepare("SELECT up.*, up.content_type as type,
    CASE WHEN up.content_type='video' THEN v.title ELSE n.title END as item_title,
    CASE WHEN up.content_type='video' THEN sv.name ELSE sn.name END as subject_name
    FROM user_progress up
    LEFT JOIN videos v ON up.content_type='video' AND up.content_id=v.id
    LEFT JOIN chapters cv ON v.chapter_id=cv.id
    LEFT JOIN subjects sv ON cv.subject_id=sv.id
    LEFT JOIN notes n ON up.content_type='note' AND up.content_id=n.id
    LEFT JOIN chapters cn ON n.chapter_id=cn.id
    LEFT JOIN subjects sn ON cn.subject_id=sn.id
    WHERE up.user_id=? ORDER BY up.completed_at DESC LIMIT 10");
$stmt->execute([$userId]);
$recentActivity = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ── Active goals ──
$stmt = $pdo->prepare("SELECT ug.*, 
    (SELECT COUNT(*) FROM goal_items WHERE goal_id=ug.id) as total_items,
    (SELECT SUM(is_completed) FROM goal_items WHERE goal_id=ug.id) as done_items
    FROM user_goals ug WHERE ug.user_id=? AND ug.status='active' ORDER BY ug.target_date ASC LIMIT 3");
$stmt->execute([$userId]);
$activeGoals = $stmt->fetchAll(PDO::FETCH_ASSOC);

$streak = (int)($user['current_streak'] ?? 0);
$totalDays = (int)($user['total_active_days'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="app-body">
<?php include 'navbar.php'; ?>

<main class="main-content">

    <div class="page-header">
        <h1><i class="fas fa-th-large"></i> Dashboard</h1>
        <p>Welcome back, <?= htmlspecialchars($user['name']) ?>!</p>
    </div>

    <!-- ── Overview Cards ── -->
    <div class="dash-stats">
        <div class="dash-stat-card">
            <div class="ds-icon" style="background:rgba(78,137,199,.1);color:var(--blue)"><i class="fas fa-chart-pie"></i></div>
            <div class="ds-info">
                <span class="ds-num"><?= $overallPct ?>%</span>
                <span class="ds-label">Overall Progress</span>
            </div>
        </div>
        <div class="dash-stat-card">
            <div class="ds-icon" style="background:rgba(139,92,246,.1);color:var(--purple)"><i class="fas fa-check-double"></i></div>
            <div class="ds-info">
                <span class="ds-num"><?= $doneAll ?>/<?= $totalAll ?></span>
                <span class="ds-label">Content Completed</span>
            </div>
        </div>
        <div class="dash-stat-card">
            <div class="ds-icon" style="background:rgba(239,68,68,.1);color:#ef4444"><i class="fas fa-fire"></i></div>
            <div class="ds-info">
                <span class="ds-num"><?= $streak ?></span>
                <span class="ds-label">Day Streak</span>
            </div>
        </div>
        <div class="dash-stat-card">
            <div class="ds-icon" style="background:rgba(16,185,129,.1);color:#10b981"><i class="fas fa-calendar-check"></i></div>
            <div class="ds-info">
                <span class="ds-num"><?= $totalDays ?></span>
                <span class="ds-label">Active Days</span>
            </div>
        </div>
    </div>

    <div class="dash-grid">
        <!-- ── Subject Progress ── -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-chart-bar"></i> Subject-wise Progress</h3>
            </div>
            <div class="subject-progress-list">
                <?php foreach ($subjectProgress as $sp): ?>
                    <div class="sp-item">
                        <div class="sp-head">
                            <div class="sp-icon" style="color:<?= $sp['color'] ?>"><i class="fas <?= $sp['icon'] ?>"></i></div>
                            <span class="sp-name"><?= $sp['name'] ?></span>
                            <span class="sp-pct"><?= $sp['percent'] ?>%</span>
                        </div>
                        <div class="progress-bar"><div class="progress-fill" style="width:<?= $sp['percent'] ?>%;background:<?= $sp['color'] ?>"></div></div>
                        <div class="sp-detail">
                            <span><i class="fas fa-play"></i> Videos: <?= $sp['vd'] ?>/<?= $sp['vt'] ?></span>
                            <span><i class="fas fa-file-alt"></i> Notes: <?= $sp['nd'] ?>/<?= $sp['nt'] ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- ── Right Column ── -->
        <div class="dash-right">
            <!-- Recent Activity -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-history"></i> Recent Activity</h3>
                </div>
                <div class="activity-list">
                    <?php if (empty($recentActivity)): ?>
                        <p class="empty-text">No activity yet. Start learning!</p>
                    <?php else: ?>
                        <?php foreach ($recentActivity as $act): ?>
                            <div class="activity-item">
                                <div class="act-icon">
                                    <i class="fas <?= $act['type'] === 'video' ? 'fa-play' : 'fa-file-alt' ?>"></i>
                                </div>
                                <div class="act-info">
                                    <span class="act-title"><?= htmlspecialchars($act['item_title'] ?? 'Unknown') ?></span>
                                    <span class="act-meta"><?= htmlspecialchars($act['subject_name'] ?? '') ?> • <?= date('d M, h:i A', strtotime($act['completed_at'])) ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Active Goals -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-bullseye"></i> Active Goals</h3>
                    <a href="goals.php" class="btn btn-sm btn-outline">View All</a>
                </div>
                <div class="goals-preview">
                    <?php if (empty($activeGoals)): ?>
                        <p class="empty-text">No active goals. <a href="goals.php">Set one now!</a></p>
                    <?php else: ?>
                        <?php foreach ($activeGoals as $g): 
                            $gPct = $g['total_items'] > 0 ? round(($g['done_items']/$g['total_items'])*100) : 0;
                            $daysLeft = max(0, (int)((strtotime($g['target_date']) - time()) / 86400));
                        ?>
                            <div class="goal-mini">
                                <div class="gm-top">
                                    <span class="gm-title"><?= htmlspecialchars($g['title']) ?></span>
                                    <span class="gm-days"><?= $daysLeft ?> days left</span>
                                </div>
                                <div class="progress-bar"><div class="progress-fill" style="width:<?= $gPct ?>%"></div></div>
                                <span class="gm-pct"><?= $gPct ?>% complete</span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</main>
<?php include 'footer.php'; ?>
</body>
</html>