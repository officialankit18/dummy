<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';
requireLogin();

$user = getCurrentUser();
if (!$user) { redirect('login.php'); exit; }

$userClass = $user['class'];
$userBoard = $user['board'];

$subjects = $pdo->prepare("SELECT * FROM subjects WHERE class = ? AND board = ? ORDER BY sort_order");
$subjects->execute([$userClass, $userBoard]);
$subjects = $subjects->fetchAll(PDO::FETCH_ASSOC);

$subjectId = (int)($_GET['subject'] ?? 0);
$chapterId = (int)($_GET['chapter'] ?? 0);
$noteId = (int)($_GET['note'] ?? 0);
$selectedSubject = null;
$chapters = [];
$notes = [];
$currentNote = null;

if ($subjectId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM subjects WHERE id = ? AND class = ? AND board = ?");
    $stmt->execute([$subjectId, $userClass, $userBoard]);
    $selectedSubject = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($selectedSubject) {
        $stmt = $pdo->prepare("SELECT c.*, 
            (SELECT COUNT(*) FROM notes WHERE chapter_id = c.id) as total_notes,
            (SELECT COUNT(*) FROM user_progress up JOIN notes n ON up.content_id = n.id WHERE n.chapter_id = c.id AND up.user_id = ? AND up.content_type = 'note') as done_notes
            FROM chapters c WHERE c.subject_id = ? ORDER BY c.chapter_number");
        $stmt->execute([$_SESSION['user_id'], $subjectId]);
        $chapters = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

if ($chapterId > 0 && $selectedSubject) {
    $stmt = $pdo->prepare("SELECT n.*, 
        (SELECT COUNT(*) FROM user_progress WHERE user_id = ? AND content_type = 'note' AND content_id = n.id) as is_completed
        FROM notes n WHERE n.chapter_id = ? ORDER BY n.sort_order");
    $stmt->execute([$_SESSION['user_id'], $chapterId]);
    $notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($noteId > 0) {
        foreach ($notes as $n) {
            if ($n['id'] == $noteId) { $currentNote = $n; break; }
        }
    }
    if (!$currentNote && !empty($notes)) {
        $currentNote = $notes[0];
    }
}

$currentChapter = null;
if ($chapterId > 0) {
    foreach ($chapters as $ch) {
        if ($ch['id'] == $chapterId) { $currentChapter = $ch; break; }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes — SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="app-body">
<?php include 'navbar.php'; ?>

<main class="main-content">

    <div class="breadcrumb">
        <a href="notes.php"><i class="fas fa-sticky-note"></i> Notes</a>
        <?php if ($selectedSubject): ?>
            <span class="bc-sep"><i class="fas fa-chevron-right"></i></span>
            <a href="notes.php?subject=<?= $subjectId ?>"><?= htmlspecialchars($selectedSubject['name']) ?></a>
        <?php endif; ?>
        <?php if ($currentChapter): ?>
            <span class="bc-sep"><i class="fas fa-chevron-right"></i></span>
            <span>Chapter <?= $currentChapter['chapter_number'] ?></span>
        <?php endif; ?>
    </div>

    <?php if (!$subjectId): ?>
    <div class="page-header">
        <h1><i class="fas fa-sticky-note"></i> Study Notes</h1>
        <p>Class <?= htmlspecialchars($userClass) ?> — <?= htmlspecialchars($userBoard) ?> Board</p>
    </div>
    <div class="subjects-grid">
        <?php foreach ($subjects as $sub): ?>
            <a href="notes.php?subject=<?= $sub['id'] ?>" class="subject-card" style="--card-color:<?= $sub['color'] ?>">
                <div class="subject-icon"><i class="fas <?= $sub['icon'] ?>"></i></div>
                <h3><?= htmlspecialchars($sub['name']) ?></h3>
                <span class="subject-meta">
                    <?php
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM chapters WHERE subject_id = ?");
                    $stmt->execute([$sub['id']]);
                    echo $stmt->fetchColumn() . ' Chapters';
                    ?>
                </span>
            </a>
        <?php endforeach; ?>
    </div>

    <?php elseif ($subjectId && !$chapterId): ?>
    <div class="page-header">
        <h1><i class="fas <?= $selectedSubject['icon'] ?>"></i> <?= htmlspecialchars($selectedSubject['name']) ?> Notes</h1>
        <p>Select a chapter to read notes</p>
    </div>
    <div class="chapters-list">
        <?php foreach ($chapters as $ch): ?>
            <?php $pct = $ch['total_notes'] > 0 ? round(($ch['done_notes'] / $ch['total_notes']) * 100) : 0; ?>
            <a href="notes.php?subject=<?= $subjectId ?>&chapter=<?= $ch['id'] ?>" class="chapter-card">
                <div class="chapter-num">Ch <?= $ch['chapter_number'] ?></div>
                <div class="chapter-info">
                    <h3><?= htmlspecialchars($ch['title']) ?></h3>
                    <p><?= htmlspecialchars($ch['description'] ?? '') ?></p>
                    <div class="chapter-meta">
                        <span><i class="fas fa-file-alt"></i> <?= $ch['total_notes'] ?> Notes</span>
                        <span><i class="fas fa-check-circle"></i> <?= $ch['done_notes'] ?>/<?= $ch['total_notes'] ?> Done</span>
                    </div>
                    <div class="progress-bar"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
                </div>
                <div class="chapter-pct"><?= $pct ?>%</div>
            </a>
        <?php endforeach; ?>
    </div>

    <?php elseif ($currentNote): ?>
    <div class="note-layout">
        <div class="note-reader">
            <div class="note-header-bar">
                <h2><?= htmlspecialchars($currentNote['title']) ?></h2>
                <button class="btn-mark <?= $currentNote['is_completed'] ? 'completed' : '' ?>" 
                        onclick="toggleComplete('note', <?= $currentNote['id'] ?>, this)">
                    <i class="fas <?= $currentNote['is_completed'] ? 'fa-check-circle' : 'fa-circle' ?>"></i>
                    <span><?= $currentNote['is_completed'] ? 'Completed' : 'Mark as Complete' ?></span>
                </button>
            </div>
            <div class="note-content">
                <?= $currentNote['content'] ?>
            </div>
            <?php if (!empty($currentNote['pdf_url'])): ?>
                <a href="<?= htmlspecialchars($currentNote['pdf_url']) ?>" target="_blank" class="btn btn-outline btn-sm" style="margin-top:16px">
                    <i class="fas fa-download"></i> Download PDF
                </a>
            <?php endif; ?>
        </div>
        <div class="note-sidebar">
            <h3><i class="fas fa-list"></i> Notes in this Chapter</h3>
            <div class="note-list">
                <?php foreach ($notes as $i => $n): ?>
                    <a href="notes.php?subject=<?= $subjectId ?>&chapter=<?= $chapterId ?>&note=<?= $n['id'] ?>" 
                       class="note-list-item <?= $n['id'] == $currentNote['id'] ? 'active' : '' ?> <?= $n['is_completed'] ? 'done' : '' ?>">
                        <span class="nl-num"><?= $i + 1 ?></span>
                        <span class="nl-title"><?= htmlspecialchars($n['title']) ?></span>
                        <?php if ($n['is_completed']): ?>
                            <i class="fas fa-check-circle nl-check"></i>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

</main>
<?php include 'footer.php'; ?>

<script>
function toggleComplete(type, id, btn) {
    fetch('ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=toggle_complete&type=' + type + '&id=' + id
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (data.completed) {
                btn.classList.add('completed');
                btn.innerHTML = '<i class="fas fa-check-circle"></i><span>Completed</span>';
            } else {
                btn.classList.remove('completed');
                btn.innerHTML = '<i class="fas fa-circle"></i><span>Mark as Complete</span>';
            }
        }
    });
}
</script>
</body>
</html>