<?php
/**
 * ============================================
 * SHIKSHARTHI - Security Module
 * ============================================
 * CSRF Protection
 * Input Sanitization & Validation
 * Rate Limiting
 * Login Attempt Tracking
 * OTP Management
 * File Upload Security
 * HTTP Security Headers
 * 
 * 🔒 Is file ko directly browser se access nahi kar sakte
 * ============================================
 */

// ── Config load karo (DB + Session already start ho jayega) ──
require_once __DIR__ . '/config.php';


/* ══════════════════════════════════════════════
   CSRF TOKEN MANAGEMENT
   
   Har form me ek hidden token hoga
   Form submit hone pe verify hoga
   Ye Cross-Site Request Forgery attack rokta hai
   ══════════════════════════════════════════════ */

/**
 * CSRF Token generate karo
 * Agar pehle se valid token hai toh wahi return karo
 */
function generateCSRFToken() {
    // Naya token banao agar:
    // - Token hai hi nahi
    // - Token expire ho gaya hai
    if (empty($_SESSION['csrf_token']) || 
        empty($_SESSION['csrf_token_time']) ||
        (time() - $_SESSION['csrf_token_time'] > CSRF_TOKEN_LIFETIME)) {
        
        // 32 bytes random = 64 character hex string
        $_SESSION['csrf_token']      = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    
    return $_SESSION['csrf_token'];
}

/**
 * CSRF Token verify karo
 * 
 * @param string $token - Form se aaya token
 * @return bool - true = valid, false = invalid/attack
 */
function verifyCSRFToken($token) {
    // Token empty hai
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    
    // Timing-safe comparison (timing attack se bachao)
    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        return false;
    }
    
    // Token expire ho gaya
    if (time() - ($_SESSION['csrf_token_time'] ?? 0) > CSRF_TOKEN_LIFETIME) {
        unset($_SESSION['csrf_token'], $_SESSION['csrf_token_time']);
        return false;
    }
    
    return true;
}

/**
 * CSRF Hidden Field - Form me paste karo
 * 
 * Usage (HTML form ke andar):
 * <?= csrfField() ?>
 */
function csrfField() {
    $token = generateCSRFToken();
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
}


/* ══════════════════════════════════════════════
   INPUT SANITIZATION & VALIDATION
   
   Har user input ko clean karo pehle
   Kabhi bhi raw input directly use mat karo
   ══════════════════════════════════════════════ */

/**
 * General text input clean karo
 * XSS attack se bachata hai
 * 
 * Usage: $name = sanitizeInput($_POST['name']);
 */
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    $input = trim($input);                                    // Extra spaces hatao
    $input = stripslashes($input);                            // Backslashes hatao
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');  // HTML entities me convert karo
    return $input;
}

/**
 * Email clean karo
 */
function sanitizeEmail($email) {
    $email = trim($email);
    $email = strtolower($email);
    return filter_var($email, FILTER_SANITIZE_EMAIL);
}

/**
 * Email valid hai ya nahi check karo
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Name valid hai check karo
 * Sirf letters, spaces, dots, hyphens allowed
 * 2 se 100 characters
 */
function isValidName($name) {
    // Unicode letters bhi allow karo (Hindi names ke liye)
    return preg_match('/^[a-zA-Z\s.\-\'\p{L}]{2,100}$/u', $name);
}

/**
 * Password strong hai check karo
 * Rules:
 * - Minimum 8 characters
 * - Kam se kam 1 uppercase letter (A-Z)
 * - Kam se kam 1 lowercase letter (a-z)
 * - Kam se kam 1 number (0-9)
 * - Kam se kam 1 special character (!@#$%^&* etc)
 * 
 * @return array ['valid' => bool, 'errors' => array]
 */
function validatePassword($password) {
    $errors = [];
    
    if (strlen($password) < 8) {
        $errors[] = 'Password kam se kam 8 characters ka hona chahiye';
    }
    if (strlen($password) > 64) {
        $errors[] = 'Password 64 characters se zyada nahi ho sakta';
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Kam se kam 1 uppercase letter (A-Z) chahiye';
    }
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = 'Kam se kam 1 lowercase letter (a-z) chahiye';
    }
    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = 'Kam se kam 1 number (0-9) chahiye';
    }
   if (!preg_match('/[^a-zA-Z0-9]/', $password)) {
    $errors[] = 'Kam se kam 1 special character chahiye (!@#$% etc)';
}
    
    return [
        'valid'  => empty($errors),
        'errors' => $errors
    ];
}

/**
 * Validate karo ki value allowed list me hai
 * Dropdown options verify karne ke liye
 */
function isValidOption($value, $allowedJson) {
    $allowed = json_decode($allowedJson, true);
    return in_array($value, $allowed, true);
}


/* ══════════════════════════════════════════════
   RATE LIMITING
   
   Ek user kitni baar kuch kar sakta hai - control karo
   Brute force aur spam se bachao
   ══════════════════════════════════════════════ */

/**
 * Rate limit check karo
 * 
 * @param string $identifier - IP ya email address
 * @param string $action     - 'otp_send', 'login', 'register' etc
 * @param int    $maxAttempts - Kitni baar allowed hai
 * @param int    $windowSecs  - Kitne seconds me (time window)
 * @return bool  true = allowed (limit me hai), false = blocked (limit cross ho gayi)
 */
function checkRateLimit($identifier, $action, $maxAttempts, $windowSecs) {
    $db = getDB();
    
    // Purane expired records clean karo (performance ke liye)
    $cleanup = $db->prepare(
        "DELETE FROM rate_limits 
         WHERE attempted_at < DATE_SUB(NOW(), INTERVAL :window SECOND)"
    );
    $cleanup->execute([':window' => $windowSecs * 2]); // 2x window purane delete karo
    
    // Current attempts count karo
    $stmt = $db->prepare(
        "SELECT COUNT(*) as cnt 
         FROM rate_limits 
         WHERE identifier = :id 
         AND action = :action 
         AND attempted_at > DATE_SUB(NOW(), INTERVAL :window SECOND)"
    );
    $stmt->execute([
        ':id'     => $identifier,
        ':action' => $action,
        ':window' => $windowSecs
    ]);
    
    $count = $stmt->fetch()['cnt'];
    
    return ($count < $maxAttempts); // true = still allowed
}

/**
 * Rate limit record add karo (har attempt pe call karo)
 */
function addRateLimitRecord($identifier, $action) {
    $db = getDB();
    $stmt = $db->prepare(
        "INSERT INTO rate_limits (identifier, action) VALUES (:id, :action)"
    );
    $stmt->execute([':id' => $identifier, ':action' => $action]);
}


/* ══════════════════════════════════════════════
   LOGIN ATTEMPT TRACKING
   
   Failed login attempts track karo
   Zyada attempts pe lockout karo
   ══════════════════════════════════════════════ */

/**
 * Login attempt record karo
 */
function recordLoginAttempt($ip, $email, $success = false) {
    $db = getDB();
    $stmt = $db->prepare(
        "INSERT INTO login_attempts (ip_address, email, success) 
         VALUES (:ip, :email, :success)"
    );
    $stmt->execute([
        ':ip'      => $ip,
        ':email'   => $email,
        ':success' => $success ? 1 : 0
    ]);
}

/**
 * Check karo login allowed hai ya nahi
 * IP aur email dono se check karo
 * 
 * @return array ['allowed' => bool, 'remaining' => int, 'lockout_seconds' => int]
 */
function isLoginAllowed($ip, $email = null) {
    $db = getDB();
    
    // ── IP se check karo ──
    $stmt = $db->prepare(
        "SELECT COUNT(*) as cnt 
         FROM login_attempts 
         WHERE ip_address = :ip 
         AND success = 0 
         AND attempted_at > DATE_SUB(NOW(), INTERVAL :lockout SECOND)"
    );
    $stmt->execute([':ip' => $ip, ':lockout' => LOGIN_LOCKOUT_SECONDS]);
    $ipAttempts = (int)$stmt->fetch()['cnt'];
    
    // ── Email se check karo (agar diya hai) ──
    $emailAttempts = 0;
    if ($email) {
        $stmt = $db->prepare(
            "SELECT COUNT(*) as cnt 
             FROM login_attempts 
             WHERE email = :email 
             AND success = 0 
             AND attempted_at > DATE_SUB(NOW(), INTERVAL :lockout SECOND)"
        );
        $stmt->execute([':email' => $email, ':lockout' => LOGIN_LOCKOUT_SECONDS]);
        $emailAttempts = (int)$stmt->fetch()['cnt'];
    }
    
    $maxUsed = max($ipAttempts, $emailAttempts);
    $remaining = MAX_LOGIN_ATTEMPTS - $maxUsed;
    
    return [
        'allowed'         => ($maxUsed < MAX_LOGIN_ATTEMPTS),
        'remaining'       => max(0, $remaining),
        'lockout_seconds' => LOGIN_LOCKOUT_SECONDS
    ];
}

/**
 * Successful login ke baad failed attempts clear karo
 */
function clearLoginAttempts($ip, $email) {
    $db = getDB();
    $stmt = $db->prepare(
        "DELETE FROM login_attempts 
         WHERE (ip_address = :ip OR email = :email) 
         AND success = 0"
    );
    $stmt->execute([':ip' => $ip, ':email' => $email]);
}


/* ══════════════════════════════════════════════
   OTP MANAGEMENT
   
   Generate → Save (hashed) → Send → Verify
   ══════════════════════════════════════════════ */

/**
 * Random OTP generate karo
 * Cryptographically secure random number
 * 
 * @return string - 6 digit OTP (leading zeros ke saath)
 */
function generateOTP() {
    // random_int() cryptographically secure hai
    $max = pow(10, OTP_LENGTH) - 1;
    $otp = random_int(0, $max);
    
    // Leading zeros ke saath pad karo (e.g., "007845")
    return str_pad($otp, OTP_LENGTH, '0', STR_PAD_LEFT);
}

/**
 * OTP database me save karo (HASHED - security ke liye)
 * Plain text me OTP kabhi mat rakho
 * 
 * @param string $email   - User ka email
 * @param string $otp     - Plain OTP (ye hash hoke store hoga)
 * @param string $purpose - 'registration' ya 'forgot_password'
 */
function saveOTP($email, $otp, $purpose) {
    $db = getDB();
    
    // Pehle se koi unused OTP hai toh invalidate karo
    // (Same email + same purpose ke liye)
    $stmt = $db->prepare(
        "UPDATE otp_codes SET is_used = 1 
         WHERE email = :email AND purpose = :purpose AND is_used = 0"
    );
    $stmt->execute([':email' => $email, ':purpose' => $purpose]);
    
    // Naya OTP save karo (HASHED)
    $stmt = $db->prepare(
        "INSERT INTO otp_codes (email, otp_hash, purpose, expires_at) 
         VALUES (:email, :hash, :purpose, DATE_ADD(NOW(), INTERVAL :expiry SECOND))"
    );
    $stmt->execute([
        ':email'   => $email,
        ':hash'    => password_hash($otp, PASSWORD_BCRYPT), // Bcrypt hash
        ':purpose' => $purpose,
        ':expiry'  => OTP_EXPIRY_SECONDS
    ]);
    
    return true;
}

/**
 * OTP verify karo
 * 
 * @param string $email   - User ka email
 * @param string $otp     - User ne jo OTP daala
 * @param string $purpose - 'registration' ya 'forgot_password'
 * @return array ['success' => bool, 'message' => string]
 */
function verifyOTP($email, $otp, $purpose) {
    $db = getDB();
    
    // Latest unused + non-expired OTP dhundho
    $stmt = $db->prepare(
        "SELECT * FROM otp_codes 
         WHERE email = :email 
         AND purpose = :purpose 
         AND is_used = 0 
         AND expires_at > NOW() 
         ORDER BY created_at DESC 
         LIMIT 1"
    );
    $stmt->execute([':email' => $email, ':purpose' => $purpose]);
    $record = $stmt->fetch();
    
    // Koi OTP mila hi nahi
    if (!$record) {
        return [
            'success' => false,
            'message' => 'OTP expire ho gaya hai ya invalid hai. Naya OTP request karo.'
        ];
    }
    
    // Max attempts exceed ho gaye
    if ($record['attempts'] >= MAX_OTP_ATTEMPTS) {
        // OTP ko invalidate karo
        $stmt = $db->prepare("UPDATE otp_codes SET is_used = 1 WHERE id = :id");
        $stmt->execute([':id' => $record['id']]);
        
        return [
            'success' => false,
            'message' => 'Bahut zyada galat attempts ho gaye. Naya OTP request karo.'
        ];
    }
    
    // OTP match karo (hash se verify)
    if (password_verify($otp, $record['otp_hash'])) {
        // ✅ OTP sahi hai! Mark as used
        $stmt = $db->prepare("UPDATE otp_codes SET is_used = 1 WHERE id = :id");
        $stmt->execute([':id' => $record['id']]);
        
        return [
            'success' => true,
            'message' => 'OTP verified successfully!'
        ];
    } else {
        // ❌ Galat OTP - attempt count badhao
        $stmt = $db->prepare(
            "UPDATE otp_codes SET attempts = attempts + 1 WHERE id = :id"
        );
        $stmt->execute([':id' => $record['id']]);
        
        $remaining = MAX_OTP_ATTEMPTS - $record['attempts'] - 1;
        
        return [
            'success' => false,
            'message' => "Galat OTP! $remaining attempts baaki hain."
        ];
    }
}


/* ══════════════════════════════════════════════
   FILE UPLOAD SECURITY (Profile Photo)
   
   Multiple layers of validation:
   1. Extension check
   2. MIME type check
   3. Image validity check
   4. Size check
   5. Random filename (predictable naam mat rakho)
   ══════════════════════════════════════════════ */

/**
 * Profile photo securely upload karo
 * 
 * @param array $file - $_FILES['profile_photo']
 * @return array ['success' => bool, 'filename' => string, 'message' => string]
 */
function uploadProfilePhoto($file) {
    
    // ── Basic checks ──
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE   => 'File server limit se badi hai.',
            UPLOAD_ERR_FORM_SIZE  => 'File form limit se badi hai.',
            UPLOAD_ERR_PARTIAL    => 'File poori upload nahi hui.',
            UPLOAD_ERR_NO_FILE    => 'Koi file select nahi ki.',
            UPLOAD_ERR_NO_TMP_DIR => 'Server error: temp folder nahi mila.',
            UPLOAD_ERR_CANT_WRITE => 'Server error: file write nahi ho payi.',
        ];
        $errCode = $file['error'] ?? UPLOAD_ERR_NO_FILE;
        $msg = $errorMessages[$errCode] ?? 'File upload me error aaya.';
        
        return ['success' => false, 'message' => $msg];
    }
    
    // ── File size check (2MB max) ──
    if ($file['size'] > MAX_FILE_SIZE) {
        $maxMB = MAX_FILE_SIZE / (1024 * 1024);
        return ['success' => false, 'message' => "File size {$maxMB}MB se zyada hai."];
    }
    
    // ── Extension check ──
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, ALLOWED_EXTENSIONS)) {
        return [
            'success' => false, 
            'message' => 'Sirf ' . implode(', ', ALLOWED_EXTENSIONS) . ' files allowed hain.'
        ];
    }
    
    // ── MIME type check (actual file content verify karo) ──
    $finfo    = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, ALLOWED_MIME_TYPES)) {
        return ['success' => false, 'message' => 'Invalid file type. Sirf images allowed hain.'];
    }
    
    // ── Image validity check (kya ye sach me image hai?) ──
    $imageInfo = @getimagesize($file['tmp_name']);
    if ($imageInfo === false) {
        return ['success' => false, 'message' => 'Ye valid image file nahi hai.'];
    }
    
    // ── Upload directory banao agar nahi hai ──
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
    
    // ── Random unique filename generate karo ──
    // Original naam mat rakho (security + collision avoid)
    $newFilename = 'pfp_' . bin2hex(random_bytes(16)) . '.' . $extension;
    $destination = UPLOAD_DIR . $newFilename;
    
    // ── File move karo temp se permanent location pe ──
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        // Read-only permission set karo
        chmod($destination, 0644);
        
        return [
            'success'  => true,
            'filename' => $newFilename,
            'message'  => 'Photo uploaded successfully!'
        ];
    }
    
    return ['success' => false, 'message' => 'File save nahi ho payi. Please try again.'];
}

/**
 * Profile photo delete karo (purana photo hatao)
 */
function deleteProfilePhoto($filename) {
    // Default photo ko delete mat karo
    if (!empty($filename) && $filename !== 'default.png') {
        $filepath = UPLOAD_DIR . $filename;
        if (file_exists($filepath)) {
            unlink($filepath);
            return true;
        }
    }
    return false;
}


/* ══════════════════════════════════════════════
   HTTP SECURITY HEADERS
   
   Browser ko batao security rules kya hain
   Ye headers har response me automatically lag jayenge
   ══════════════════════════════════════════════ */
function setSecurityHeaders() {
    // Content type sniffing band karo
    header('X-Content-Type-Options: nosniff');
    
    // Iframe me mat dikhao (Clickjacking attack rokho)
    header('X-Frame-Options: DENY');
    
    // Browser XSS filter ON karo
    header('X-XSS-Protection: 1; mode=block');
    
    // Referrer info control karo
    header('Referrer-Policy: strict-origin-when-cross-origin');
    
    // Camera, mic, location access band karo
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    
    // Content Security Policy (kya load ho sakta hai control karo)
    header("Content-Security-Policy: default-src 'self'; "
         . "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com; "
         . "font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; "
         . "img-src 'self' data:; "
         . "script-src 'self' 'unsafe-inline'; "
         . "connect-src 'self';"
    );
    
    // 🔴 Sensitive pages cache mat karo (logout ke baad back button se na dikhe)
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Cache-Control: post-check=0, pre-check=0', false);
    header('Pragma: no-cache');
    header('Expires: 0');
}

// ⚡ Har page pe security headers automatically lag jayenge
setSecurityHeaders();