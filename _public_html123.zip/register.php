<?php
/**
 * ============================================
 * SHIKSHARTHI - Registration Page
 * ============================================
 * Flow:
 * 1. User form bhare → Submit kare
 * 2. Server validate kare sab inputs
 * 3. Profile photo upload ho (agar diya hai)
 * 4. Temp data session me store ho
 * 5. OTP generate → hash → save → email bheje
 * 6. Redirect → email_verify.php
 * ============================================
 */

require_once __DIR__ . '/security.php';
require_once __DIR__ . '/email.php';

// ── Already logged in? Profile pe bhej do ──
redirectIfLoggedIn();

$errors = [];
$old    = []; // Form repopulation ke liye

/* ══════════════════════════════════════════════
   FORM SUBMISSION HANDLE
   ══════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ── CSRF Token Verify ──
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Security token expired. Page refresh karke dubara try karo.';
    }

    if (empty($errors)) {
        // ── Inputs Sanitize ──
        $name            = sanitizeInput($_POST['name'] ?? '');
        $email           = sanitizeEmail($_POST['email'] ?? '');
        $state           = sanitizeInput($_POST['state'] ?? '');
        $city            = sanitizeInput($_POST['city'] ?? '');
        $class           = sanitizeInput($_POST['class'] ?? '');
        $board           = sanitizeInput($_POST['board'] ?? '');
        $password        = $_POST['password'] ?? '';        // Raw - hash hoga
        $confirmPassword = $_POST['confirm_password'] ?? '';

        // Old values store karo (agar error aaye toh form me wapas dikhe)
        $old = compact('name', 'email', 'state', 'city', 'class', 'board');

        // ── VALIDATIONS ──

        // Name
        if (empty($name)) {
            $errors[] = 'Naam daalna zaroori hai.';
        } elseif (!isValidName($name)) {
            $errors[] = 'Naam me sirf letters, spaces, dots allowed hain (2-100 characters).';
        }

        // Email
        if (empty($email)) {
            $errors[] = 'Email daalna zaroori hai.';
        } elseif (!isValidEmail($email)) {
            $errors[] = 'Valid email address daalo.';
        }

        // State (dropdown se aaya - verify karo)
        if (empty($state) || !isValidOption($state, INDIAN_STATES)) {
            $errors[] = 'Apna state select karo.';
        }

        // City
        if (empty($city)) {
            $errors[] = 'City ka naam daalo.';
        } elseif (strlen($city) < 2 || strlen($city) > 100) {
            $errors[] = 'City 2 se 100 characters ka hona chahiye.';
        }

        // Class (dropdown verify)
        if (empty($class) || !isValidOption($class, CLASS_OPTIONS)) {
            $errors[] = 'Apni class select karo.';
        }

        // Board (dropdown verify)
        if (empty($board) || !isValidOption($board, BOARD_OPTIONS)) {
            $errors[] = 'Apna board select karo.';
        }

        // Password strength
        $passCheck = validatePassword($password);
        if (!$passCheck['valid']) {
            $errors = array_merge($errors, $passCheck['errors']);
        }

        // Confirm password match
        if ($password !== $confirmPassword) {
            $errors[] = 'Password aur Confirm Password match nahi kar rahe.';
        }

        // ── PROFILE PHOTO UPLOAD ──
        $photoFilename = 'default.png';

        // Pehle se pending photo hai toh delete karo (user ne wapas form bhara)
        if (isset($_SESSION['reg_data']['profile_photo']) &&
            $_SESSION['reg_data']['profile_photo'] !== 'default.png') {
            deleteProfilePhoto($_SESSION['reg_data']['profile_photo']);
        }

        if (isset($_FILES['profile_photo']) &&
            $_FILES['profile_photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploadResult = uploadProfilePhoto($_FILES['profile_photo']);
            if ($uploadResult['success']) {
                $photoFilename = $uploadResult['filename'];
            } else {
                $errors[] = $uploadResult['message'];
            }
        }

        // ── DUPLICATE EMAIL CHECK ──
        if (empty($errors)) {
            $db   = getDB();
            $stmt = $db->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
            $stmt->execute([':email' => $email]);
            if ($stmt->fetch()) {
                $errors[] = 'Ye email pehle se registered hai. Login karo ya dusra email use karo.';
                if ($photoFilename !== 'default.png') {
                    deleteProfilePhoto($photoFilename);
                }
            }
        }

        // ── RATE LIMIT CHECK ──
        if (empty($errors)) {
            $ip = getUserIP();
            if (!checkRateLimit($ip, 'otp_send', MAX_OTP_SEND_PER_HOUR, 3600)) {
                $errors[] = 'Bahut zyada requests. 1 ghante baad try karo.';
            }
            if (!checkRateLimit($email, 'otp_send', MAX_OTP_SEND_PER_HOUR, 3600)) {
                $errors[] = 'Is email pe bahut OTP bheje gaye. Thodi der baad try karo.';
            }
        }

        // ── ALL GOOD! OTP GENERATE + SEND ──
        if (empty($errors)) {
            // Session me temp registration data store karo
            $_SESSION['reg_data'] = [
                'name'          => $name,
                'email'         => $email,
                'password'      => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
                'profile_photo' => $photoFilename,
                'state'         => $state,
                'city'          => $city,
                'class'         => $class,
                'board'         => $board
            ];

            // OTP generate + save (hashed) + rate limit record
            $otp = generateOTP();
            saveOTP($email, $otp, 'registration');
            addRateLimitRecord(getUserIP(), 'otp_send');
            addRateLimitRecord($email, 'otp_send');

            // Email bhejo
            $emailResult = sendOTPEmail($email, $otp, 'registration', $name);

            if ($emailResult['success']) {
                $_SESSION['otp_email']   = $email;
                $_SESSION['otp_purpose'] = 'registration';
                $_SESSION['otp_sent_at'] = time();
                setFlash('success', 'OTP bhej diya gaya hai: ' . $email);
                redirect('email_verify.php');
            } else {
                $errors[] = 'Email bhejne me problem aayi. Thodi der me try karo.';
                // Cleanup on failure
                if ($photoFilename !== 'default.png') {
                    deleteProfilePhoto($photoFilename);
                }
                unset($_SESSION['reg_data']);
            }
        }
    }
}

// ── Dropdown Options Load ──
$states  = json_decode(INDIAN_STATES, true);
$classes = json_decode(CLASS_OPTIONS, true);
$boards  = json_decode(BOARD_OPTIONS, true);
$flash   = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="auth-body">

    <div class="auth-wrapper">
        <div class="auth-card">

            <!-- ═══ CARD HEADER ═══ -->
            <div class="auth-header">
                <h1 class="auth-logo">🎓 SHIKSHARTHI</h1>
                <p class="auth-tagline">Create Your Account</p>
            </div>

            <!-- ═══ CARD BODY ═══ -->
            <div class="auth-body-content">

                <!-- Flash Message -->
                <?php if ($flash): ?>
                    <div class="alert alert-<?= $flash['type'] ?>">
                        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($flash['message']) ?>
                    </div>
                <?php endif; ?>

                <!-- Error Messages -->
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        <ul class="error-list">
                            <?php foreach ($errors as $err): ?>
                                <li><?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- ═══ REGISTRATION FORM ═══ -->
                <form method="POST" enctype="multipart/form-data" id="registerForm" novalidate>
                    <?= csrfField() ?>

                    <!-- Profile Photo Upload -->
                    <div class="form-group photo-group">
                        <div class="photo-upload-wrapper">
                            <div class="photo-preview-container" id="photoContainer">
                                <img id="photoPreview" src="uploads/profiles/default.png" alt="Profile Preview">
                                <div class="photo-overlay">
                                    <i class="fas fa-camera"></i>
                                    <span>Upload</span>
                                </div>
                            </div>
                            <input type="file" id="profile_photo" name="profile_photo"
                                   accept=".jpg,.jpeg,.png,.webp" hidden>
                        </div>
                        <p class="form-hint">Max 2MB • JPG, PNG, WebP (Optional)</p>
                    </div>

                    <!-- Name -->
                    <div class="form-group">
                        <label class="form-label" for="name">
                            <i class="fas fa-user"></i> Full Name <span class="required">*</span>
                        </label>
                        <input type="text" id="name" name="name" class="form-input"
                               value="<?= htmlspecialchars($old['name'] ?? '') ?>"
                               placeholder="Apna poora naam likhein"
                               autocomplete="name" required maxlength="100">
                    </div>

                    <!-- Email -->
                    <div class="form-group">
                        <label class="form-label" for="email">
                            <i class="fas fa-envelope"></i> Email Address <span class="required">*</span>
                        </label>
                        <input type="email" id="email" name="email" class="form-input"
                               value="<?= htmlspecialchars($old['email'] ?? '') ?>"
                               placeholder="example@email.com"
                               autocomplete="email" required maxlength="255">
                    </div>

                    <!-- State & City (Side by Side) -->
                    <div class="form-row">
                        <div class="form-group form-col">
                            <label class="form-label" for="state">
                                <i class="fas fa-map-marker-alt"></i> State <span class="required">*</span>
                            </label>
                            <select id="state" name="state" class="form-input form-select" required>
                                <option value="">-- Select State --</option>
                                <?php foreach ($states as $st): ?>
                                    <option value="<?= htmlspecialchars($st) ?>"
                                        <?= (($old['state'] ?? '') === $st) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($st) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group form-col">
                            <label class="form-label" for="city">
                                <i class="fas fa-city"></i> City <span class="required">*</span>
                            </label>
                            <input type="text" id="city" name="city" class="form-input"
                                   value="<?= htmlspecialchars($old['city'] ?? '') ?>"
                                   placeholder="Apna city likhein"
                                   required maxlength="100">
                        </div>
                    </div>

                    <!-- Class & Board (Side by Side) -->
                    <div class="form-row">
                        <div class="form-group form-col">
                            <label class="form-label" for="class">
                                <i class="fas fa-school"></i> Class <span class="required">*</span>
                            </label>
                            <select id="class" name="class" class="form-input form-select" required>
                                <option value="">-- Select --</option>
                                <?php foreach ($classes as $cl): ?>
                                    <option value="<?= htmlspecialchars($cl) ?>"
                                        <?= (($old['class'] ?? '') === $cl) ? 'selected' : '' ?>>
                                        Class <?= htmlspecialchars($cl) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group form-col">
                            <label class="form-label" for="board">
                                <i class="fas fa-chalkboard"></i> Board <span class="required">*</span>
                            </label>
                            <select id="board" name="board" class="form-input form-select" required>
                                <option value="">-- Select --</option>
                                <?php foreach ($boards as $bd): ?>
                                    <option value="<?= htmlspecialchars($bd) ?>"
                                        <?= (($old['board'] ?? '') === $bd) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($bd) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Password -->
                    <div class="form-group">
                        <label class="form-label" for="password">
                            <i class="fas fa-lock"></i> Password <span class="required">*</span>
                        </label>
                        <div class="input-password-wrapper">
                            <input type="password" id="password" name="password" class="form-input"
                                   placeholder="Strong password banao"
                                   autocomplete="new-password" required maxlength="64">
                            <button type="button" class="password-toggle" onclick="togglePassword('password', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <!-- Password Requirements Live Checker -->
                        <div class="password-requirements" id="passReqs">
                            <p class="req" id="req-length"><i class="fas fa-circle"></i> Minimum 8 characters</p>
                            <p class="req" id="req-upper"><i class="fas fa-circle"></i> 1 uppercase (A-Z)</p>
                            <p class="req" id="req-lower"><i class="fas fa-circle"></i> 1 lowercase (a-z)</p>
                            <p class="req" id="req-number"><i class="fas fa-circle"></i> 1 number (0-9)</p>
                            <p class="req" id="req-special"><i class="fas fa-circle"></i> 1 special char (!@#$%)</p>
                        </div>
                    </div>

                    <!-- Confirm Password -->
                    <div class="form-group">
                        <label class="form-label" for="confirm_password">
                            <i class="fas fa-lock"></i> Confirm Password <span class="required">*</span>
                        </label>
                        <div class="input-password-wrapper">
                            <input type="password" id="confirm_password" name="confirm_password"
                                   class="form-input" placeholder="Password dubara likhein"
                                   autocomplete="new-password" required maxlength="64">
                            <button type="button" class="password-toggle" onclick="togglePassword('confirm_password', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <p class="form-hint" id="matchHint" style="display:none;">
                            <i class="fas fa-check-circle" style="color:var(--success)"></i> Passwords match!
                        </p>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-primary btn-full" id="submitBtn">
                        <i class="fas fa-user-plus"></i> Register & Verify Email
                    </button>
                </form>

                <!-- Footer Link -->
                <div class="auth-footer">
                    <p>Already have an account? <a href="login.php" class="auth-link">Login here</a></p>
                </div>

            </div>
        </div>
    </div>

    <!-- ═══ JAVASCRIPT ═══ -->
    <script>
    /* ── Photo Preview ── */
    document.getElementById('photoContainer').addEventListener('click', function() {
        document.getElementById('profile_photo').click();
    });

    document.getElementById('profile_photo').addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            // Size check (2MB)
            if (file.size > 2 * 1024 * 1024) {
                alert('File 2MB se chhoti honi chahiye!');
                this.value = '';
                return;
            }
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('photoPreview').src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });

    /* ── Password Show/Hide Toggle ── */
    function togglePassword(fieldId, btn) {
        const field = document.getElementById(fieldId);
        const icon = btn.querySelector('i');
        if (field.type === 'password') {
            field.type = 'text';
            icon.className = 'fas fa-eye-slash';
        } else {
            field.type = 'password';
            icon.className = 'fas fa-eye';
        }
    }

    /* ── Password Requirements Live Check ── */
    document.getElementById('password').addEventListener('input', function() {
        const val = this.value;
        toggleReq('req-length',  val.length >= 8);
        toggleReq('req-upper',   /[A-Z]/.test(val));
        toggleReq('req-lower',   /[a-z]/.test(val));
        toggleReq('req-number',  /[0-9]/.test(val));
        toggleReq('req-special', /[!@#$%^&*(),.?":{}|<>\-_=+\[\]\\\/~`]/.test(val));
        checkMatch();
    });

    function toggleReq(id, met) {
        const el = document.getElementById(id);
        if (met) {
            el.classList.add('met');
            el.querySelector('i').className = 'fas fa-check-circle';
        } else {
            el.classList.remove('met');
            el.querySelector('i').className = 'fas fa-circle';
        }
    }

    /* ── Confirm Password Match ── */
    document.getElementById('confirm_password').addEventListener('input', checkMatch);

    function checkMatch() {
        const p = document.getElementById('password').value;
        const c = document.getElementById('confirm_password').value;
        const hint = document.getElementById('matchHint');
        if (c.length > 0 && p === c) {
            hint.style.display = 'block';
        } else {
            hint.style.display = 'none';
        }
    }

    /* ── Form Submit Loading State ── */
    document.getElementById('registerForm').addEventListener('submit', function() {
        const btn = document.getElementById('submitBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    });
    </script>

</body>
</html>