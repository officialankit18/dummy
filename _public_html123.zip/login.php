<?php
/**
 * ============================================
 * SHIKSHARTHI - Login Page
 * ============================================
 * Features:
 * - Email + Password login
 * - Brute force protection (attempt tracking)
 * - CSRF protection
 * - Session fixation protection
 * - Lockout after max attempts
 * ============================================
 */

require_once __DIR__ . '/security.php';

// Already logged in? Profile pe bhej do
redirectIfLoggedIn();

$errors = [];
$old    = [];

/* ══════════════════════════════════════════════
   FORM SUBMISSION HANDLE
   ══════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF verify
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Security token expired. Refresh karke try karo.';
    }

    if (empty($errors)) {
        $email    = sanitizeEmail($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $ip       = getUserIP();

        $old['email'] = $email;

        // Basic validation
        if (empty($email) || !isValidEmail($email)) {
            $errors[] = 'Valid email daalo.';
        }
        if (empty($password)) {
            $errors[] = 'Password daalo.';
        }

        // ── BRUTE FORCE CHECK ──
        if (empty($errors)) {
            $loginCheck = isLoginAllowed($ip, $email);

            if (!$loginCheck['allowed']) {
                $lockMins = ceil($loginCheck['lockout_seconds'] / 60);
                $errors[] = "Bahut zyada galat attempts. {$lockMins} minute baad try karo.";
            }
        }

        // ── AUTHENTICATE ──
        if (empty($errors)) {
            $db   = getDB();
            $stmt = $db->prepare(
                "SELECT * FROM users WHERE email = :email AND is_active = 1 LIMIT 1"
            );
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {

                // ── Email verified hai? ──
                if ($user['is_verified'] != 1) {
                    $errors[] = 'Pehle apna email verify karo. Registration complete karo.';
                    recordLoginAttempt($ip, $email, false);
                } else {
                    // ✅ LOGIN SUCCESS!
                    recordLoginAttempt($ip, $email, true);
                    clearLoginAttempts($ip, $email);
                    setLoginSession($user);

                    setFlash('success', 'Welcome back, ' . $user['name'] . '! 🎉');
                    redirect('profile.php');
                }

            } else {
                // ❌ Wrong credentials
                recordLoginAttempt($ip, $email, false);

                $loginCheck = isLoginAllowed($ip, $email);
                $rem = $loginCheck['remaining'];

                if ($rem > 0) {
                    $errors[] = "Email ya Password galat hai. {$rem} attempts baaki.";
                } else {
                    $lockMins = ceil($loginCheck['lockout_seconds'] / 60);
                    $errors[] = "Account locked. {$lockMins} minute baad try karo.";
                }
            }
        }
    }
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="auth-body">

    <div class="auth-wrapper">
        <div class="auth-card auth-card-narrow">

            <!-- ═══ HEADER ═══ -->
            <div class="auth-header">
                <h1 class="auth-logo">🎓 SHIKSHARTHI</h1>
                <p class="auth-tagline">Welcome Back!</p>
            </div>

            <!-- ═══ BODY ═══ -->
            <div class="auth-body-content">

                <!-- Flash Message -->
                <?php if ($flash): ?>
                    <div class="alert alert-<?= $flash['type'] ?>">
                        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($flash['message']) ?>
                    </div>
                <?php endif; ?>

                <!-- Errors -->
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        <ul class="error-list">
                            <?php foreach ($errors as $err): ?>
                                <li><?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Login Icon -->
                <div class="auth-icon">
                    <i class="fas fa-sign-in-alt"></i>
                </div>

                <!-- ═══ LOGIN FORM ═══ -->
                <form method="POST" id="loginForm" novalidate>
                    <?= csrfField() ?>

                    <!-- Email -->
                    <div class="form-group">
                        <label class="form-label" for="email">
                            <i class="fas fa-envelope"></i> Email Address
                        </label>
                        <input type="email" id="email" name="email" class="form-input"
                               value="<?= htmlspecialchars($old['email'] ?? '') ?>"
                               placeholder="Apna registered email daalo"
                               autocomplete="email" required>
                    </div>

                    <!-- Password -->
                    <div class="form-group">
                        <label class="form-label" for="password">
                            <i class="fas fa-lock"></i> Password
                        </label>
                        <div class="input-password-wrapper">
                            <input type="password" id="password" name="password" class="form-input"
                                   placeholder="Apna password daalo"
                                   autocomplete="current-password" required>
                            <button type="button" class="password-toggle" onclick="togglePassword('password', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Forgot Password Link -->
                    <div class="forgot-link">
                        <a href="forgot_password.php" class="auth-link">
                            <i class="fas fa-key"></i> Forgot Password?
                        </a>
                    </div>

                    <!-- Submit -->
                    <button type="submit" class="btn btn-primary btn-full" id="loginBtn">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </button>
                </form>

                <!-- Footer -->
                <div class="auth-footer">
                    <p>Don't have an account? <a href="register.php" class="auth-link">Register here</a></p>
                </div>

            </div>
        </div>
    </div>

    <script>
    function togglePassword(fieldId, btn) {
        const field = document.getElementById(fieldId);
        const icon = btn.querySelector('i');
        if (field.type === 'password') {
            field.type = 'text';
            icon.className = 'fas fa-eye-slash';
        } else {
            field.type = 'password';
            icon.className = 'fas fa-eye';
        }
    }

    document.getElementById('loginForm').addEventListener('submit', function() {
        const btn = document.getElementById('loginBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';
    });
    </script>

</body>
</html>