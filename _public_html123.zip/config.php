<?php
/**
 * ============================================
 * SHIKSHARTHI - Database Connection & Helpers
 * ============================================
 * Ye file database connection manage karti hai
 * Session management bhi yahi hai
 * Helper functions bhi yahi hain
 * 
 * 🔒 Is file ko directly browser se access nahi kar sakte
 *    (.htaccess me block kiya hai)
 * ============================================
 */

// ── Constants file load karo (settings) ──
require_once __DIR__ . '/constants.php';

/* ══════════════════════════════════════════════
   DATABASE CONNECTION CLASS (Singleton Pattern)
   
   Singleton = Poore application me sirf EK connection
   banega, baar baar naya nahi banega
   ══════════════════════════════════════════════ */
class Database {
    
    /** @var Database|null Singleton instance */
    private static $instance = null;
    
    /** @var PDO Database connection */
    private $pdo;
    
    /**
     * Constructor - Private hai taaki bahar se new Database() na kar sake
     * Sirf getInstance() se access hoga
     */
    private function __construct() {
        try {
            // DSN (Data Source Name) banao
            $dsn = sprintf(
                "mysql:host=%s;dbname=%s;charset=%s",
                DB_HOST, DB_NAME, DB_CHARSET
            );
            
            // PDO Options - Security & Performance ke liye
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::ATTR_PERSISTENT         => false,
];            
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            
        } catch (PDOException $e) {
            // 🔴 Production me KABHI actual DB error user ko mat dikhao
            error_log("SHIKSHARTHI DB Error: " . $e->getMessage());
            die(json_encode([
                'error' => true,
                'message' => 'Service temporarily unavailable. Please try again later.'
            ]));
        }
    }
    
    /**
     * Singleton Instance - Har baar same connection reuse hoga
     * Usage: $db = Database::getInstance()->getConnection();
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * PDO connection object return karo
     */
    public function getConnection() {
        return $this->pdo;
    }
    
    // Clone block karo (Singleton todne se rokho)
    private function __clone() {}
    
    // Unserialize block karo
    public function __wakeup() {
        throw new \Exception("Cannot unserialize a singleton.");
    }
}

/* ══════════════════════════════════════════════
   QUICK HELPER: DB Connection
   
   Kahi bhi use karo:
   $db = getDB();
   $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
   ══════════════════════════════════════════════ */
function getDB() {
    return Database::getInstance()->getConnection();
}


/* ══════════════════════════════════════════════
   SECURE SESSION MANAGEMENT
   
   Ye function:
   - Secure cookies set karta hai
   - Session hijacking rokta hai
   - Session fixation rokta hai
   - Auto expire karta hai
   ══════════════════════════════════════════════ */
function initSecureSession() {
    // Agar session pehle se chalu hai toh dobara start mat karo
    if (session_status() === PHP_SESSION_NONE) {
        
        // Check karo HTTPS hai ya nahi
        $isHTTPS = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                   || ($_SERVER['SERVER_PORT'] ?? 80) == 443;
        
        // ── Secure Session Settings ──
        ini_set('session.cookie_httponly', '1');     // JS se cookie access BLOCK
        ini_set('session.cookie_secure', $isHTTPS ? '1' : '0');  // HTTPS pe hi cookie bheje
        ini_set('session.use_strict_mode', '1');     // Invalid session IDs reject karo
        ini_set('session.use_only_cookies', '1');    // Sirf cookies use karo (URL me session ID nahi)
        ini_set('session.cookie_samesite', 'Strict'); // Cross-site requests block
        ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
        
        // Cookie parameters set karo
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $isHTTPS,    // HTTPS check dynamic
            'httponly'  => true,        // JavaScript access BLOCK
            'samesite' => 'Strict'     // CSRF protection
        ]);
        
        session_start();
        
        // ── SESSION FIXATION PROTECTION ──
        // Pehli baar session start ho toh regenerate karo
        if (!isset($_SESSION['_initiated'])) {
            session_regenerate_id(true);  // Purani session destroy + nayi banao
            $_SESSION['_initiated']   = true;
            $_SESSION['_created']     = time();
            $_SESSION['_last_active'] = time();
            
            // Browser fingerprint store karo (hijacking detection)
            $_SESSION['_fingerprint'] = hash('sha256',
                ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown') .
                ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0')
            );
        }
        
        // ── SESSION EXPIRY CHECK ──
        // Agar session purani ho gayi toh destroy karo
        if (isset($_SESSION['_created']) && 
            (time() - $_SESSION['_created'] > SESSION_LIFETIME)) {
            
            // Poora session destroy karo
            $_SESSION = [];
            
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }
            
            session_destroy();
            session_start();
            session_regenerate_id(true);
            return; // Session expired, fresh start
        }
        
        // ── SESSION HIJACKING DETECTION ──
        // Agar browser fingerprint match nahi karta = kisi ne session churai hai
        $currentFingerprint = hash('sha256',
            ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown') .
            ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0')
        );
        
        if (isset($_SESSION['_fingerprint']) && 
            $_SESSION['_fingerprint'] !== $currentFingerprint) {
            
            // 🚨 Session hijack attempt! Destroy karo sab kuch
            $_SESSION = [];
            session_destroy();
            session_start();
            session_regenerate_id(true);
            return;
        }
        
        // ── LAST ACTIVITY UPDATE ──
        $_SESSION['_last_active'] = time();
    }
}

// ⚡ Session HAMESHA start karo jab config.php load ho
initSecureSession();


/* ══════════════════════════════════════════════
   AUTHENTICATION HELPERS
   ══════════════════════════════════════════════ */

/**
 * Check karo user logged in hai ya nahi
 * 
 * Usage: if (isLoggedIn()) { ... }
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && 
           !empty($_SESSION['user_id']) &&
           isset($_SESSION['logged_in']) && 
           $_SESSION['logged_in'] === true;
}

/**
 * Protected page guard - Login nahi hai toh bhaga do login page pe
 * 
 * Usage: Har protected page ke top pe likho
 * requireLogin();
 */
function requireLogin() {
    if (!isLoggedIn()) {
        setFlash('error', 'Please login first.');
        redirect('login.php');
    }
}

/**
 * Agar already logged in hai toh profile pe bhej do
 * Login aur Register page pe use karo
 * 
 * Usage: redirectIfLoggedIn();
 */
function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        redirect('profile.php');
    }
}

/**
 * Login session set karo (successful login ke baad)
 * 
 * @param array $user - Database se aaya user data
 */
function setLoginSession($user) {
    // Session regenerate karo (fixation attack se bachao)
    session_regenerate_id(true);
    
    $_SESSION['user_id']    = (int)$user['id'];
    $_SESSION['user_name']  = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_class'] = $user['class'];
    $_SESSION['user_board'] = $user['board'];
    $_SESSION['logged_in']  = true;
    $_SESSION['login_time'] = time();
    $_SESSION['_created']   = time(); // Session timer reset
    
    // New fingerprint bhi update karo
    $_SESSION['_fingerprint'] = hash('sha256',
        ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown') .
        ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0')
    );
}

/**
 * Logout - Session poori tarah destroy karo
 * Koi bhi trace mat chhodho
 */
function destroySession() {
    // Session variables clear karo
    $_SESSION = [];
    
    // Session cookie delete karo
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    
    // Session file delete karo
    session_destroy();
}


/* ══════════════════════════════════════════════
   FLASH MESSAGES (Success/Error dikhane ke liye)
   
   Ek page pe set karo, dusre page pe dikhao
   Show hone ke baad auto-delete ho jata hai
   ══════════════════════════════════════════════ */

/**
 * Flash message set karo
 * 
 * Usage: setFlash('success', 'Registration successful!');
 *        setFlash('error', 'Kuch galat ho gaya');
 */
function setFlash($type, $message) {
    $_SESSION['flash'] = [
        'type'    => $type,     // 'success', 'error', 'warning', 'info'
        'message' => $message
    ];
}

/**
 * Flash message get karo (aur delete bhi karo)
 * 
 * Usage: $flash = getFlash();
 *        if ($flash) { echo $flash['message']; }
 */
function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']); // Ek baar dikhake delete karo
        return $flash;
    }
    return null;
}


/* ══════════════════════════════════════════════
   UTILITY HELPERS
   ══════════════════════════════════════════════ */

/**
 * Safe redirect
 */
function redirect($url) {
    header("Location: $url");
    exit();
}

/**
 * User ka real IP address lo
 * Proxy/Load balancer ke peeche bhi kaam kare
 */
function getUserIP() {
    // Priority order me headers check karo
    $headers = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ];
    
    foreach ($headers as $header) {
        if (!empty($_SERVER[$header])) {
            // Multiple IPs ho sakte hain (comma separated) - pehla lo
            $ips = explode(',', $_SERVER[$header]);
            $ip  = trim($ips[0]);
            
            // Validate IP (private/reserved IPs skip karo)
            if (filter_var($ip, FILTER_VALIDATE_IP, 
                FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
    }
    
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * Current logged in user ka data DB se fresh fetch karo
 * 
 * Usage: $user = getCurrentUser();
 */
function getCurrentUser() {
    if (!isLoggedIn()) return null;
    
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = :id AND is_active = 1 LIMIT 1");
    $stmt->execute([':id' => $_SESSION['user_id']]);
    return $stmt->fetch();
}

$pdo = getDB();