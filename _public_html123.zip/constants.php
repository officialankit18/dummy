<?php
/**
 * ============================================
 * SHIKSHARTHI - Constants & Configuration
 * ============================================
 * 🔴 IMPORTANT: Sirf ISI file me apni settings change karo
 * Baaki files me kuch mat badlo
 * 
 * ⚠️ CHANGE wala comment jaha dikhein - waha apni values dalo
 * ============================================
 */

/* ──────────────────────────────────────────────
   ERROR HANDLING
   Production me: display_errors = 0
   Development/Testing me: display_errors = 1
   ────────────────────────────────────────────── */
error_reporting(E_ALL);
ini_set('display_errors', '0');  // ⚠️ Testing ke time '1' karo, live me '0' rakho
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/logs/error.log');

/* ──────────────────────────────────────────────
   DATABASE SETTINGS (Hostinger)
   ⚠️ Ye 4 values Hostinger hPanel se copy karo
   ────────────────────────────────────────────── */
define('DB_HOST', 'localhost');                       // ⚠️ CHANGE: Mostly localhost hota hai Hostinger me
define('DB_NAME', 'u418541364_Student');      // ⚠️ CHANGE: Hostinger se exact name (prefix ke saath)
define('DB_USER', 'u418541364_student2026');    // ⚠️ CHANGE: Hostinger se exact username
define('DB_PASS', 'Shiksha@2026');         // ⚠️ CHANGE: Jo password tumne set kiya tha
define('DB_CHARSET', 'utf8mb4');

/* ──────────────────────────────────────────────
   BREVO SMTP SETTINGS (Email bhejne ke liye)
   300 emails/day FREE
   ⚠️ Brevo dashboard se ye values lo
   ────────────────────────────────────────────── */
define('SMTP_HOST', 'smtp-relay.brevo.com');          // Brevo SMTP server (ye same rahega)
define('SMTP_PORT', 587);                              // TLS port (ye same rahega)
define('SMTP_USER', 'a4fac6001@smtp-brevo.com');    // ⚠️ CHANGE: Brevo me registered email
define('SMTP_PASS', 'xsmtpsib-db3d12682637ee1088a188e389b4a83592dbcd83c636ae3ae92721189425c7d4-y4w5XBSg8PtLAqYP');     // ⚠️ CHANGE: Brevo SMTP key
define('SMTP_FROM_EMAIL', 'infoshiksharthi@gmail.com'); // ⚠️ CHANGE: From email (verified domain ya Brevo email)
define('SMTP_FROM_NAME', 'SHIKSHARTHI');               // App name - email me dikhega

/* ──────────────────────────────────────────────
   APP SETTINGS
   ────────────────────────────────────────────── */
define('APP_NAME', 'SHIKSHARTHI');
define('APP_URL', 'https://shiksharthi.online');          // ⚠️ CHANGE: Apna domain dalo (https ke saath)
define('APP_VERSION', '1.0.0');
define('APP_TAGLINE', 'AI Personalized Learning Platform');

/* ──────────────────────────────────────────────
   SECURITY SETTINGS
   In values ko samjho - zaroorat ho toh change karo
   ────────────────────────────────────────────── */
define('OTP_EXPIRY_SECONDS', 600);       // OTP kitne seconds me expire ho → 600 = 10 min
define('OTP_LENGTH', 6);                  // OTP kitne digits ka → 6
define('MAX_OTP_ATTEMPTS', 3);            // Ek OTP pe max galat attempts → 3
define('MAX_OTP_SEND_PER_HOUR', 5);      // 1 ghante me max kitne OTP bheje → 5
define('MAX_LOGIN_ATTEMPTS', 5);          // Max login attempts before lockout → 5
define('LOGIN_LOCKOUT_SECONDS', 900);     // Lockout kitne seconds ka → 900 = 15 min
define('SESSION_LIFETIME', 3600);         // Session kitne seconds tak valid → 3600 = 1 hour
define('CSRF_TOKEN_LIFETIME', 3600);      // CSRF token expiry → 3600 = 1 hour

/* ──────────────────────────────────────────────
   FILE UPLOAD SETTINGS (Profile Photo)
   ────────────────────────────────────────────── */
define('UPLOAD_DIR', __DIR__ . '/uploads/profiles/');  // Server path
define('UPLOAD_URL', APP_URL . '/uploads/profiles/');  // Browser URL
define('MAX_FILE_SIZE', 2 * 1024 * 1024);              // Max 2MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'webp']);
define('ALLOWED_MIME_TYPES', ['image/jpeg', 'image/png', 'image/webp']);

/* ──────────────────────────────────────────────
   INDIAN STATES LIST (Registration dropdown ke liye)
   ────────────────────────────────────────────── */
define('INDIAN_STATES', json_encode([
    'Andhra Pradesh',
    'Arunachal Pradesh',
    'Assam',
    'Bihar',
    'Chhattisgarh',
    'Goa',
    'Gujarat',
    'Haryana',
    'Himachal Pradesh',
    'Jharkhand',
    'Karnataka',
    'Kerala',
    'Madhya Pradesh',
    'Maharashtra',
    'Manipur',
    'Meghalaya',
    'Mizoram',
    'Nagaland',
    'Odisha',
    'Punjab',
    'Rajasthan',
    'Sikkim',
    'Tamil Nadu',
    'Telangana',
    'Tripura',
    'Uttar Pradesh',
    'Uttarakhand',
    'West Bengal',
    'Andaman and Nicobar Islands',
    'Chandigarh',
    'Dadra and Nagar Haveli and Daman and Diu',
    'Delhi',
    'Jammu and Kashmir',
    'Ladakh',
    'Lakshadweep',
    'Puducherry'
]));

/* ──────────────────────────────────────────────
   CLASS & BOARD OPTIONS (Registration dropdown ke liye)
   Future me aur add karna ho toh yahi karo
   ────────────────────────────────────────────── */
define('CLASS_OPTIONS', json_encode(['9', '10', '11', '12']));
define('BOARD_OPTIONS', json_encode(['CBSE', 'ICSE', 'UP']));