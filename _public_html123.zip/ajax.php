<?php
/**
 * SHIKSHARTHI — AJAX Handler
 * Handles: mark complete, goals, progress
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$userId = $_SESSION['user_id'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ═══ TOGGLE COMPLETE (video/note) ═══
    case 'toggle_complete':
        $type = $_POST['type'] ?? '';
        $id = (int)($_POST['id'] ?? 0);

        if (!in_array($type, ['video', 'note']) || $id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid data']);
            exit;
        }

        // Check if already completed
        $stmt = $pdo->prepare("SELECT id FROM user_progress WHERE user_id = ? AND content_type = ? AND content_id = ?");
        $stmt->execute([$userId, $type, $id]);

        if ($stmt->fetch()) {
            // Remove completion
            $pdo->prepare("DELETE FROM user_progress WHERE user_id = ? AND content_type = ? AND content_id = ?")->execute([$userId, $type, $id]);
            echo json_encode(['success' => true, 'completed' => false]);
        } else {
            // Mark complete
            $pdo->prepare("INSERT INTO user_progress (user_id, content_type, content_id) VALUES (?, ?, ?)")->execute([$userId, $type, $id]);
            echo json_encode(['success' => true, 'completed' => true]);
        }
        break;

    // ═══ GET PROGRESS DATA ═══
    case 'get_progress':
        $user = getCurrentUser();
        $class = $user['class'];
        $board = $user['board'];

        // Get all subjects
        $stmt = $pdo->prepare("SELECT * FROM subjects WHERE class = ? AND board = ? ORDER BY sort_order");
        $stmt->execute([$class, $board]);
        $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $progress = [];
        foreach ($subjects as $sub) {
            // Total videos
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM videos v JOIN chapters c ON v.chapter_id = c.id WHERE c.subject_id = ?");
            $stmt->execute([$sub['id']]);
            $totalVids = (int)$stmt->fetchColumn();

            // Completed videos
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_progress up JOIN videos v ON up.content_id = v.id JOIN chapters c ON v.chapter_id = c.id WHERE up.user_id = ? AND up.content_type = 'video' AND c.subject_id = ?");
            $stmt->execute([$userId, $sub['id']]);
            $doneVids = (int)$stmt->fetchColumn();

            // Total notes
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM notes n JOIN chapters c ON n.chapter_id = c.id WHERE c.subject_id = ?");
            $stmt->execute([$sub['id']]);
            $totalNotes = (int)$stmt->fetchColumn();

            // Completed notes
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_progress up JOIN notes n ON up.content_id = n.id JOIN chapters c ON n.chapter_id = c.id WHERE up.user_id = ? AND up.content_type = 'note' AND c.subject_id = ?");
            $stmt->execute([$userId, $sub['id']]);
            $doneNotes = (int)$stmt->fetchColumn();

            $total = $totalVids + $totalNotes;
            $done = $doneVids + $doneNotes;
            $pct = $total > 0 ? round(($done / $total) * 100) : 0;

            $progress[] = [
                'subject' => $sub['name'],
                'icon' => $sub['icon'],
                'color' => $sub['color'],
                'total' => $total,
                'done' => $done,
                'percent' => $pct,
                'videos_total' => $totalVids,
                'videos_done' => $doneVids,
                'notes_total' => $totalNotes,
                'notes_done' => $doneNotes,
            ];
        }

        echo json_encode(['success' => true, 'progress' => $progress]);
        break;

    // ═══ SAVE GOAL ═══
    case 'save_goal':
        $title = trim($_POST['title'] ?? '');
        $targetDate = $_POST['target_date'] ?? '';
        $chapterIds = json_decode($_POST['chapter_ids'] ?? '[]', true);

        if (empty($title) || empty($targetDate) || empty($chapterIds)) {
            echo json_encode(['success' => false, 'message' => 'Please fill all fields']);
            exit;
        }

        if (strtotime($targetDate) <= time()) {
            echo json_encode(['success' => false, 'message' => 'Target date must be in future']);
            exit;
        }

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO user_goals (user_id, title, target_date) VALUES (?, ?, ?)");
            $stmt->execute([$userId, $title, $targetDate]);
            $goalId = $pdo->lastInsertId();

            $stmt = $pdo->prepare("INSERT INTO goal_items (goal_id, chapter_id) VALUES (?, ?)");
            foreach ($chapterIds as $chId) {
                $stmt->execute([$goalId, (int)$chId]);
            }

            $pdo->commit();
            echo json_encode(['success' => true, 'goal_id' => $goalId]);
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => 'Error saving goal']);
        }
        break;

    // ═══ TOGGLE GOAL ITEM ═══
    case 'toggle_goal_item':
        $itemId = (int)($_POST['item_id'] ?? 0);

        $stmt = $pdo->prepare("SELECT gi.*, ug.user_id FROM goal_items gi JOIN user_goals ug ON gi.goal_id = ug.id WHERE gi.id = ? AND ug.user_id = ?");
        $stmt->execute([$itemId, $userId]);
        $item = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$item) {
            echo json_encode(['success' => false]);
            exit;
        }

        $newStatus = $item['is_completed'] ? 0 : 1;
        $completedAt = $newStatus ? date('Y-m-d H:i:s') : null;

        $pdo->prepare("UPDATE goal_items SET is_completed = ?, completed_at = ? WHERE id = ?")->execute([$newStatus, $completedAt, $itemId]);

        // Check if all items complete
        $stmt = $pdo->prepare("SELECT COUNT(*) as total, SUM(is_completed) as done FROM goal_items WHERE goal_id = ?");
        $stmt->execute([$item['goal_id']]);
        $counts = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($counts['total'] == $counts['done'] && $counts['total'] > 0) {
            $pdo->prepare("UPDATE user_goals SET status = 'completed' WHERE id = ?")->execute([$item['goal_id']]);
        } else {
            $pdo->prepare("UPDATE user_goals SET status = 'active' WHERE id = ?")->execute([$item['goal_id']]);
        }

        echo json_encode(['success' => true, 'completed' => (bool)$newStatus]);
        break;

    // ═══ DELETE GOAL ═══
    case 'delete_goal':
        $goalId = (int)($_POST['goal_id'] ?? 0);
        $pdo->prepare("DELETE FROM user_goals WHERE id = ? AND user_id = ?")->execute([$goalId, $userId]);
        echo json_encode(['success' => true]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Unknown action']);
}