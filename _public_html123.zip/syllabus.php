<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';
requireLogin();

$user = getCurrentUser();
if (!$user) { redirect('login.php'); exit; }

$stmt = $pdo->prepare("SELECT s.*, sub.name as subject_name, sub.icon, sub.color FROM syllabus s LEFT JOIN subjects sub ON s.subject_id = sub.id WHERE s.class = ? AND s.board = ? ORDER BY sub.sort_order");
$stmt->execute([$user['class'], $user['board']]);
$syllabusItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Syllabus — SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="app-body">
<?php include 'navbar.php'; ?>

<main class="main-content">

    <div class="page-header">
        <h1><i class="fas fa-list-check"></i> Syllabus</h1>
        <p>Class <?= htmlspecialchars($user['class']) ?> — <?= htmlspecialchars($user['board']) ?> Board</p>
    </div>

    <?php if (empty($syllabusItems)): ?>
        <div class="empty-state">
            <i class="fas fa-folder-open"></i>
            <h3>No Syllabus Available</h3>
            <p>Syllabus documents will be uploaded soon.</p>
        </div>
    <?php else: ?>
        <div class="pyq-grid">
            <?php foreach ($syllabusItems as $s): ?>
                <div class="pyq-card">
                    <div class="pyq-icon" style="color:<?= $s['color'] ?? 'var(--blue)' ?>">
                        <i class="fas <?= $s['icon'] ?? 'fa-file-alt' ?>"></i>
                    </div>
                    <div class="pyq-info">
                        <h3><?= htmlspecialchars($s['title']) ?></h3>
                        <span class="pyq-year"><?= htmlspecialchars($s['subject_name'] ?? 'General') ?></span>
                    </div>
                    <a href="<?= htmlspecialchars($s['pdf_url']) ?>" target="_blank" class="btn btn-sm btn-outline">
                        <i class="fas fa-download"></i> Download
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</main>
<?php include 'footer.php'; ?>
</body>
</html>