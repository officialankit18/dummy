<?php
/**
 * ============================================
 * SHIKSHARTHI - Forgot Password Page
 * ============================================
 * Multi-step flow:
 * Step 1 (default): Email daalo → OTP bheja → email_verify.php
 * Step 2 (?step=reset): OTP verified → New password set karo
 * ============================================
 */

require_once __DIR__ . '/security.php';
require_once __DIR__ . '/email.php';

// Already logged in? Profile pe bhej do
redirectIfLoggedIn();

$step   = $_GET['step'] ?? 'email';   // 'email' or 'reset'
$errors = [];
$old    = [];

/* ══════════════════════════════════════════════
   STEP 1: EMAIL SUBMIT → SEND OTP
   ══════════════════════════════════════════════ */
if ($step === 'email' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Security token expired. Refresh karo.';
    }

    if (empty($errors)) {
        $email      = sanitizeEmail($_POST['email'] ?? '');
        $old['email'] = $email;

        if (empty($email) || !isValidEmail($email)) {
            $errors[] = 'Valid email daalo.';
        }

        // ── Check email exists & verified ──
        if (empty($errors)) {
            $db   = getDB();
            $stmt = $db->prepare(
                "SELECT id, name FROM users WHERE email = :email AND is_verified = 1 AND is_active = 1 LIMIT 1"
            );
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch();

            if (!$user) {
                // Security: Generic message (actual email exist karta hai ya nahi - mat batao)
                $errors[] = 'Agar ye email registered hai toh OTP bhej diya jayega.';
                // Actually we won't send — but same message dikhao (enumeration attack se bachao)
                // Lekin better UX ke liye — let me just tell them
                $errors = ['Is email se koi account nahi mila. Check karo ya register karo.'];
            }
        }

        // ── Rate limit ──
        if (empty($errors)) {
            $ip = getUserIP();
            if (!checkRateLimit($ip, 'otp_send', MAX_OTP_SEND_PER_HOUR, 3600) ||
                !checkRateLimit($email, 'otp_send', MAX_OTP_SEND_PER_HOUR, 3600)) {
                $errors[] = 'Bahut zyada requests. Thodi der baad try karo.';
            }
        }

        // ── Send OTP ──
        if (empty($errors)) {
            $otp = generateOTP();
            saveOTP($email, $otp, 'forgot_password');
            addRateLimitRecord($ip, 'otp_send');
            addRateLimitRecord($email, 'otp_send');

            $emailResult = sendOTPEmail($email, $otp, 'forgot_password', $user['name']);

            if ($emailResult['success']) {
                $_SESSION['otp_email']   = $email;
                $_SESSION['otp_purpose'] = 'forgot_password';
                $_SESSION['otp_sent_at'] = time();
                setFlash('success', 'OTP bhej diya gaya hai: ' . $email);
                redirect('email_verify.php');
            } else {
                $errors[] = 'Email nahi bhej paaye. Thodi der me try karo.';
            }
        }
    }
}

/* ══════════════════════════════════════════════
   STEP 2: NEW PASSWORD SET (OTP verified ke baad)
   ══════════════════════════════════════════════ */
if ($step === 'reset') {

    // ── Verify ki OTP sach me verified hai ──
    if (empty($_SESSION['reset_verified']) || $_SESSION['reset_verified'] !== true ||
        empty($_SESSION['reset_email'])) {
        setFlash('error', 'Pehle OTP verify karo.');
        redirect('forgot_password.php');
    }

    $resetEmail = $_SESSION['reset_email'];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            $errors[] = 'Security token expired.';
        }

        if (empty($errors)) {
            $newPassword     = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';

            // Validate new password
            $passCheck = validatePassword($newPassword);
            if (!$passCheck['valid']) {
                $errors = array_merge($errors, $passCheck['errors']);
            }
            if ($newPassword !== $confirmPassword) {
                $errors[] = 'Password aur Confirm Password match nahi kar rahe.';
            }

            // ── Update password in DB ──
            if (empty($errors)) {
                $db   = getDB();
                $hash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
                $stmt = $db->prepare("UPDATE users SET password = :pass WHERE email = :email");
                $stmt->execute([':pass' => $hash, ':email' => $resetEmail]);

                // Session cleanup
                unset($_SESSION['reset_verified'], $_SESSION['reset_email']);

                setFlash('success', '🔒 Password successfully change ho gaya! Ab login karo.');
                redirect('login.php');
            }
        }
    }
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="auth-body">

    <div class="auth-wrapper">
        <div class="auth-card auth-card-narrow">

            <!-- ═══ HEADER ═══ -->
            <div class="auth-header">
                <h1 class="auth-logo">🎓 SHIKSHARTHI</h1>
                <p class="auth-tagline">
                    <?= ($step === 'reset') ? 'Set New Password' : 'Forgot Password' ?>
                </p>
            </div>

            <!-- ═══ BODY ═══ -->
            <div class="auth-body-content center-content">

                <!-- Flash -->
                <?php if ($flash): ?>
                    <div class="alert alert-<?= $flash['type'] ?>">
                        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($flash['message']) ?>
                    </div>
                <?php endif; ?>

                <!-- Errors -->
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        <ul class="error-list">
                            <?php foreach ($errors as $err): ?>
                                <li><?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ($step === 'email'): ?>
                    <!-- ═══════════════════════════════════════
                         STEP 1: EMAIL INPUT
                         ═══════════════════════════════════════ -->
                    <div class="auth-icon">
                        <i class="fas fa-key"></i>
                    </div>
                    <p class="auth-description">
                        Apna registered email daalo. Hum tumhe OTP bhejenge password reset ke liye.
                    </p>

                    <form method="POST" id="forgotForm" novalidate>
                        <?= csrfField() ?>

                        <div class="form-group">
                            <label class="form-label" for="email">
                                <i class="fas fa-envelope"></i> Email Address
                            </label>
                            <input type="email" id="email" name="email" class="form-input"
                                   value="<?= htmlspecialchars($old['email'] ?? '') ?>"
                                   placeholder="Apna registered email daalo"
                                   autocomplete="email" required autofocus>
                        </div>

                        <button type="submit" class="btn btn-primary btn-full" id="sendBtn">
                            <i class="fas fa-paper-plane"></i> Send OTP
                        </button>
                    </form>

                <?php elseif ($step === 'reset'): ?>
                    <!-- ═══════════════════════════════════════
                         STEP 2: NEW PASSWORD
                         ═══════════════════════════════════════ -->
                    <div class="auth-icon auth-icon-success">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <p class="auth-description">
                        OTP verified! Ab naya password set karo.
                    </p>

                    <form method="POST" id="resetForm" novalidate>
                        <?= csrfField() ?>

                        <div class="form-group">
                            <label class="form-label" for="password">
                                <i class="fas fa-lock"></i> New Password
                            </label>
                            <div class="input-password-wrapper">
                                <input type="password" id="password" name="password" class="form-input"
                                       placeholder="Naya strong password"
                                       autocomplete="new-password" required maxlength="64">
                                <button type="button" class="password-toggle" onclick="togglePassword('password', this)">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div class="password-requirements" id="passReqs">
                                <p class="req" id="req-length"><i class="fas fa-circle"></i> Min 8 characters</p>
                                <p class="req" id="req-upper"><i class="fas fa-circle"></i> 1 uppercase (A-Z)</p>
                                <p class="req" id="req-lower"><i class="fas fa-circle"></i> 1 lowercase (a-z)</p>
                                <p class="req" id="req-number"><i class="fas fa-circle"></i> 1 number (0-9)</p>
                                <p class="req" id="req-special"><i class="fas fa-circle"></i> 1 special char</p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="confirm_password">
                                <i class="fas fa-lock"></i> Confirm New Password
                            </label>
                            <div class="input-password-wrapper">
                                <input type="password" id="confirm_password" name="confirm_password" class="form-input"
                                       placeholder="Password dubara likhein"
                                       autocomplete="new-password" required maxlength="64">
                                <button type="button" class="password-toggle" onclick="togglePassword('confirm_password', this)">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary btn-full" id="resetBtn">
                            <i class="fas fa-save"></i> Update Password
                        </button>
                    </form>
                <?php endif; ?>

                <!-- Footer -->
                <div class="auth-footer">
                    <a href="login.php" class="auth-link"><i class="fas fa-arrow-left"></i> Back to Login</a>
                </div>

            </div>
        </div>
    </div>

    <script>
    function togglePassword(fieldId, btn) {
        const field = document.getElementById(fieldId);
        const icon = btn.querySelector('i');
        field.type = (field.type === 'password') ? 'text' : 'password';
        icon.className = (field.type === 'password') ? 'fas fa-eye' : 'fas fa-eye-slash';
    }

    /* Password requirements (step=reset ke liye) */
    const passField = document.getElementById('password');
    if (passField) {
        passField.addEventListener('input', function() {
            const v = this.value;
            tg('req-length',  v.length >= 8);
            tg('req-upper',   /[A-Z]/.test(v));
            tg('req-lower',   /[a-z]/.test(v));
            tg('req-number',  /[0-9]/.test(v));
            tg('req-special', /[!@#$%^&*(),.?":{}|<>\-_=+\[\]\\\/~`]/.test(v));
        });
    }
    function tg(id, met) {
        const el = document.getElementById(id);
        if (!el) return;
        el.classList.toggle('met', met);
        el.querySelector('i').className = met ? 'fas fa-check-circle' : 'fas fa-circle';
    }

    /* Loading states */
    ['forgotForm','resetForm'].forEach(function(fid) {
        const f = document.getElementById(fid);
        if (f) {
            f.addEventListener('submit', function() {
                const b = f.querySelector('button[type="submit"]');
                b.disabled = true;
                b.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            });
        }
    });
    </script>

</body>
</html>