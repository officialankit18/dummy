<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';
requireLogin();

$user = getCurrentUser();
if (!$user) { redirect('login.php'); exit; }

$userId = $_SESSION['user_id'];

// Expire old goals
$pdo->prepare("UPDATE user_goals SET status='expired' WHERE user_id=? AND status='active' AND target_date < CURDATE()")->execute([$userId]);

// Get subjects & chapters
$stmt = $pdo->prepare("SELECT s.*, c.id as ch_id, c.chapter_number, c.title as ch_title FROM subjects s JOIN chapters c ON c.subject_id=s.id WHERE s.class=? AND s.board=? ORDER BY s.sort_order, c.chapter_number");
$stmt->execute([$user['class'], $user['board']]);
$allData = $stmt->fetchAll(PDO::FETCH_ASSOC);

$subChapters = [];
foreach ($allData as $row) {
    $sid = $row['id'];
    if (!isset($subChapters[$sid])) {
        $subChapters[$sid] = ['name' => $row['name'], 'icon' => $row['icon'], 'chapters' => []];
    }
    $subChapters[$sid]['chapters'][] = ['id' => $row['ch_id'], 'num' => $row['chapter_number'], 'title' => $row['ch_title']];
}

// Get user goals
$stmt = $pdo->prepare("SELECT ug.*, 
    (SELECT COUNT(*) FROM goal_items WHERE goal_id=ug.id) as total_items,
    (SELECT SUM(is_completed) FROM goal_items WHERE goal_id=ug.id) as done_items
    FROM user_goals ug WHERE ug.user_id=? ORDER BY FIELD(ug.status,'active','completed','expired'), ug.target_date ASC");
$stmt->execute([$userId]);
$goals = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get goal items for active goals
$goalItems = [];
foreach ($goals as $g) {
    $stmt = $pdo->prepare("SELECT gi.*, c.chapter_number, c.title as ch_title, s.name as sub_name FROM goal_items gi JOIN chapters c ON gi.chapter_id=c.id JOIN subjects s ON c.subject_id=s.id WHERE gi.goal_id=? ORDER BY s.sort_order, c.chapter_number");
    $stmt->execute([$g['id']]);
    $goalItems[$g['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Goal — SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="app-body">
<?php include 'navbar.php'; ?>

<main class="main-content">

    <div class="page-header">
        <h1><i class="fas fa-bullseye"></i> Set Goal</h1>
        <p>Plan your study schedule and track your progress</p>
    </div>

    <!-- ── Create Goal Form ── -->
    <div class="card" style="margin-bottom:24px">
        <div class="card-header">
            <h3><i class="fas fa-plus-circle"></i> Create New Goal</h3>
        </div>
        <div style="padding:22px" id="goalForm">
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-heading"></i> Goal Title</label>
                    <input type="text" id="goalTitle" class="form-input" placeholder="e.g., Complete Math by June">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Target Date</label>
                    <input type="date" id="goalDate" class="form-input" min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
                </div>
            </div>

            <label style="font-size:13px;font-weight:600;color:var(--txt2);margin-bottom:10px;display:block">
                <i class="fas fa-book" style="color:var(--blue)"></i> Select Chapters to Complete:
            </label>

            <div class="goal-chapters-grid">
                <?php foreach ($subChapters as $sid => $sub): ?>
                    <div class="goal-subject">
                        <h4><i class="fas <?= $sub['icon'] ?>"></i> <?= $sub['name'] ?></h4>
                        <?php foreach ($sub['chapters'] as $ch): ?>
                            <label class="goal-ch-item">
                                <input type="checkbox" name="chapters[]" value="<?= $ch['id'] ?>">
                                <span>Ch <?= $ch['num'] ?>: <?= htmlspecialchars($ch['title']) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <button class="btn btn-primary" onclick="saveGoal()" style="margin-top:16px">
                <i class="fas fa-save"></i> Create Goal
            </button>
            <p id="goalMsg" style="margin-top:10px;font-size:14px"></p>
        </div>
    </div>

    <!-- ── My Goals ── -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list-check"></i> My Goals</h3>
        </div>
        <div style="padding:22px">
            <?php if (empty($goals)): ?>
                <p class="empty-text">No goals yet. Create one above!</p>
            <?php endif; ?>

            <?php foreach ($goals as $g): 
                $gPct = $g['total_items'] > 0 ? round((($g['done_items'] ?? 0)/$g['total_items'])*100) : 0;
                $daysLeft = max(0, (int)((strtotime($g['target_date']) - time()) / 86400));
                $perDay = $daysLeft > 0 ? ceil(($g['total_items'] - ($g['done_items'] ?? 0)) / $daysLeft) : 0;
            ?>
                <div class="goal-card status-<?= $g['status'] ?>">
                    <div class="goal-top">
                        <div>
                            <h3><?= htmlspecialchars($g['title']) ?></h3>
                            <div class="goal-meta-row">
                                <span><i class="fas fa-calendar"></i> Target: <?= date('d M Y', strtotime($g['target_date'])) ?></span>
                                <span><i class="fas fa-clock"></i> <?= $daysLeft ?> days left</span>
                                <?php if ($g['status'] === 'active' && $perDay > 0): ?>
                                    <span><i class="fas fa-tachometer-alt"></i> ~<?= $perDay ?> chapter<?= $perDay > 1 ? 's' : '' ?>/day needed</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="goal-status-badge s-<?= $g['status'] ?>"><?= ucfirst($g['status']) ?></div>
                    </div>

                    <div class="progress-bar" style="margin:12px 0"><div class="progress-fill" style="width:<?= $gPct ?>%"></div></div>
                    <p style="font-size:13px;color:var(--txt3);margin-bottom:14px"><?= $gPct ?>% complete — <?= ($g['done_items'] ?? 0) ?>/<?= $g['total_items'] ?> chapters done</p>

                    <!-- Goal Items -->
                    <div class="goal-items-list">
                        <?php foreach ($goalItems[$g['id']] ?? [] as $gi): ?>
                            <div class="gi-item <?= $gi['is_completed'] ? 'gi-done' : '' ?>">
                                <button class="gi-check" onclick="toggleGoalItem(<?= $gi['id'] ?>, this)" <?= $g['status'] !== 'active' ? 'disabled' : '' ?>>
                                    <i class="fas <?= $gi['is_completed'] ? 'fa-check-circle' : 'fa-circle' ?>"></i>
                                </button>
                                <span><?= htmlspecialchars($gi['sub_name']) ?> — Ch <?= $gi['chapter_number'] ?>: <?= htmlspecialchars($gi['ch_title']) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($g['status'] === 'active'): ?>
                        <button class="btn btn-sm btn-danger" style="margin-top:12px" onclick="if(confirm('Delete this goal?'))deleteGoal(<?= $g['id'] ?>)">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</main>
<?php include 'footer.php'; ?>

<script>
function saveGoal(){
    var title = document.getElementById('goalTitle').value.trim();
    var date = document.getElementById('goalDate').value;
    var checks = document.querySelectorAll('input[name="chapters[]"]:checked');
    var ids = [];
    checks.forEach(function(c){ ids.push(parseInt(c.value)); });

    if(!title||!date||ids.length===0){
        document.getElementById('goalMsg').innerHTML='<span style="color:var(--err)">Please fill all fields and select at least one chapter.</span>';
        return;
    }

    fetch('ajax.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=save_goal&title='+encodeURIComponent(title)+'&target_date='+date+'&chapter_ids='+JSON.stringify(ids)
    }).then(r=>r.json()).then(data=>{
        if(data.success){ location.reload(); }
        else{ document.getElementById('goalMsg').innerHTML='<span style="color:var(--err)">'+data.message+'</span>'; }
    });
}

function toggleGoalItem(itemId, btn){
    fetch('ajax.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=toggle_goal_item&item_id='+itemId
    }).then(r=>r.json()).then(data=>{
        if(data.success){ location.reload(); }
    });
}

function deleteGoal(goalId){
    fetch('ajax.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=delete_goal&goal_id='+goalId
    }).then(r=>r.json()).then(function(){ location.reload(); });
}
</script>
</body>
</html>