<?php
/**
 * ============================================
 * SHIKSHARTHI - Footer Component
 * ============================================
 * 🔻 Har page me include karo
 * <?php include 'footer.php'; ?>
 * ============================================
 */

$currentPage = basename($_SERVER['PHP_SELF']);
$currentYear = date('Y');
?>

<!-- Footer CSS -->
<style>
/* ═══════════════════════════════════════════ */
/*          SHIKSHARTHI FOOTER STYLES          */
/* ═══════════════════════════════════════════ */

:root {
    --footer-bg: linear-gradient(135deg, #0d0d1a 0%, #1a1a2e 50%, #16213e 100%);
    --footer-text: rgba(255, 255, 255, 0.7);
    --footer-heading: #ffffff;
    --footer-link-hover: #00d4ff;
    --footer-border: rgba(255, 255, 255, 0.1);
    --accent-gradient: linear-gradient(135deg, #00d4ff, #7c3aed);
    --mobile-nav-height: 70px;
}

/* ═══════════════════════════════════════════ */
/*              DESKTOP FOOTER                 */
/* ═══════════════════════════════════════════ */

.sk-footer {
    background: var(--footer-bg);
    padding: 60px 0 30px;
    position: relative;
    overflow: hidden;
}

/* Decorative Elements */
.sk-footer::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--accent-gradient);
}

.sk-footer::after {
    content: '';
    position: absolute;
    top: -100px;
    right: -100px;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(0, 212, 255, 0.1) 0%, transparent 70%);
    border-radius: 50%;
    pointer-events: none;
}

.sk-footer-inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    position: relative;
    z-index: 1;
}

/* ── Footer Grid ── */
.sk-footer-grid {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1fr;
    gap: 40px;
    margin-bottom: 50px;
}

/* ── Brand Column ── */
.sk-footer-brand {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 20px;
}

.sk-footer-brand-icon {
    width: 50px;
    height: 50px;
    background: var(--accent-gradient);
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
    box-shadow: 0 4px 20px rgba(0, 212, 255, 0.3);
}

.sk-footer-brand-name {
    font-size: 1.6rem;
    font-weight: 800;
    background: var(--accent-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.sk-footer-desc {
    color: var(--footer-text);
    font-size: 0.95rem;
    line-height: 1.7;
    margin-bottom: 25px;
    max-width: 300px;
}

/* ── Social Links ── */
.sk-footer-social {
    display: flex;
    gap: 12px;
}

.sk-footer-social a {
    width: 42px;
    height: 42px;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--footer-text);
    font-size: 1.1rem;
    transition: all 0.3s ease;
    border: 1px solid rgba(255, 255, 255, 0.1);
}

.sk-footer-social a:hover {
    background: var(--accent-gradient);
    color: white;
    transform: translateY(-3px);
    box-shadow: 0 5px 20px rgba(0, 212, 255, 0.3);
}

/* ── Footer Columns ── */
.sk-footer-col h4 {
    color: var(--footer-heading);
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 25px;
    position: relative;
    padding-bottom: 12px;
}

.sk-footer-col h4::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 40px;
    height: 3px;
    background: var(--accent-gradient);
    border-radius: 3px;
}

/* ── Quick Links ── */
.sk-footer-links {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sk-footer-links li {
    margin-bottom: 14px;
}

.sk-footer-links a {
    color: var(--footer-text);
    text-decoration: none;
    font-size: 0.95rem;
    display: flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.sk-footer-links a i {
    font-size: 0.7rem;
    color: #00d4ff;
    transition: transform 0.3s ease;
}

.sk-footer-links a:hover {
    color: var(--footer-link-hover);
    transform: translateX(5px);
}

.sk-footer-links a:hover i {
    transform: translateX(3px);
}

/* ── Contact Info ── */
.sk-footer-contact {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sk-footer-contact li {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    margin-bottom: 18px;
    color: var(--footer-text);
    font-size: 0.95rem;
}

.sk-footer-contact li i {
    color: #00d4ff;
    font-size: 1rem;
    margin-top: 3px;
    width: 20px;
    text-align: center;
}

.sk-footer-contact a {
    color: var(--footer-text);
    text-decoration: none;
    transition: color 0.3s ease;
}

.sk-footer-contact a:hover {
    color: var(--footer-link-hover);
}

/* ── Footer Bottom ── */
.sk-footer-bottom {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 30px;
    border-top: 1px solid var(--footer-border);
    flex-wrap: wrap;
    gap: 15px;
}

.sk-footer-copyright {
    color: var(--footer-text);
    font-size: 0.9rem;
}

.sk-footer-copyright span {
    color: #00d4ff;
    font-weight: 600;
}

.sk-footer-legal {
    display: flex;
    align-items: center;
    gap: 20px;
}

.sk-footer-legal a {
    color: var(--footer-text);
    text-decoration: none;
    font-size: 0.9rem;
    transition: color 0.3s ease;
    display: flex;
    align-items: center;
    gap: 6px;
}

.sk-footer-legal a:hover {
    color: var(--footer-link-hover);
}

.sk-footer-legal a i {
    font-size: 0.8rem;
}

/* ═══════════════════════════════════════════ */
/*          MOBILE BOTTOM NAVIGATION           */
/* ═══════════════════════════════════════════ */

.sk-mobile-nav {
    display: none;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: var(--mobile-nav-height);
    background: linear-gradient(180deg, #1a1a2e 0%, #0d0d1a 100%);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    z-index: 9998;
    padding: 8px 0;
    padding-bottom: env(safe-area-inset-bottom, 8px);
    box-shadow: 0 -5px 30px rgba(0, 0, 0, 0.3);
}

.sk-mobile-nav-inner {
    display: flex;
    justify-content: space-around;
    align-items: center;
    height: 100%;
    max-width: 500px;
    margin: 0 auto;
}

.sk-mobile-nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 4px;
    padding: 8px 16px;
    text-decoration: none;
    color: rgba(255, 255, 255, 0.5);
    font-size: 0.7rem;
    font-weight: 500;
    border-radius: 12px;
    transition: all 0.3s ease;
    position: relative;
}

.sk-mobile-nav-item i {
    font-size: 1.3rem;
    transition: all 0.3s ease;
}

.sk-mobile-nav-item span {
    transition: all 0.3s ease;
}

.sk-mobile-nav-item:hover {
    color: rgba(255, 255, 255, 0.8);
}

.sk-mobile-nav-item.active {
    color: #00d4ff;
}

.sk-mobile-nav-item.active::before {
    content: '';
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 30px;
    height: 3px;
    background: var(--accent-gradient);
    border-radius: 0 0 3px 3px;
}

.sk-mobile-nav-item.active i {
    transform: scale(1.1);
    filter: drop-shadow(0 0 8px rgba(0, 212, 255, 0.5));
}

/* ── Center Dashboard Button (Special) ── */
.sk-mobile-nav-item.center-btn {
    position: relative;
}

.sk-mobile-nav-item.center-btn i {
    width: 50px;
    height: 50px;
    background: var(--accent-gradient);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    color: white;
    margin-top: -25px;
    box-shadow: 0 4px 20px rgba(0, 212, 255, 0.4);
    transition: all 0.3s ease;
}

.sk-mobile-nav-item.center-btn:hover i,
.sk-mobile-nav-item.center-btn.active i {
    transform: scale(1.1);
    box-shadow: 0 6px 25px rgba(0, 212, 255, 0.5);
}

.sk-mobile-nav-item.center-btn.active::before {
    display: none;
}

.sk-mobile-nav-item.center-btn span {
    margin-top: 5px;
}

/* ═══════════════════════════════════════════ */
/*              RESPONSIVE STYLES              */
/* ═══════════════════════════════════════════ */

@media (max-width: 1024px) {
    .sk-footer-grid {
        grid-template-columns: 1fr 1fr;
        gap: 40px 30px;
    }
}

@media (max-width: 768px) {
    .sk-footer {
        padding: 50px 0 100px; /* Extra padding for mobile nav */
    }

    .sk-footer-grid {
        grid-template-columns: 1fr;
        gap: 35px;
        text-align: center;
    }

    .sk-footer-brand {
        justify-content: center;
    }

    .sk-footer-desc {
        max-width: 100%;
    }

    .sk-footer-social {
        justify-content: center;
    }

    .sk-footer-col h4::after {
        left: 50%;
        transform: translateX(-50%);
    }

    .sk-footer-links a {
        justify-content: center;
    }

    .sk-footer-contact li {
        justify-content: center;
    }

    .sk-footer-bottom {
        flex-direction: column;
        text-align: center;
        gap: 15px;
    }

    .sk-footer-legal {
        flex-wrap: wrap;
        justify-content: center;
    }

    /* Show Mobile Nav */
    .sk-mobile-nav {
        display: block;
    }

    .sk-mobile-nav-inner {
        display: flex;
    }
}

@media (max-width: 480px) {
    .sk-footer {
        padding: 40px 0 90px;
    }

    .sk-footer-brand-name {
        font-size: 1.3rem;
    }

    .sk-footer-col h4 {
        font-size: 1rem;
    }

    .sk-mobile-nav-item {
        padding: 8px 12px;
    }

    .sk-mobile-nav-item i {
        font-size: 1.2rem;
    }

    .sk-mobile-nav-item span {
        font-size: 0.65rem;
    }
}

/* ── Scroll to Top Button ── */
.sk-scroll-top {
    position: fixed;
    bottom: 90px;
    right: 20px;
    width: 45px;
    height: 45px;
    background: var(--accent-gradient);
    border: none;
    border-radius: 12px;
    color: white;
    font-size: 1.2rem;
    cursor: pointer;
    z-index: 999;
    opacity: 0;
    visibility: hidden;
    transform: translateY(20px);
    transition: all 0.3s ease;
    box-shadow: 0 4px 20px rgba(0, 212, 255, 0.3);
}

.sk-scroll-top.visible {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.sk-scroll-top:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 25px rgba(0, 212, 255, 0.4);
}

@media (min-width: 769px) {
    .sk-scroll-top {
        bottom: 30px;
    }
}

/* ── Animation for footer elements ── */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.sk-footer-col {
    animation: fadeInUp 0.6s ease forwards;
}

.sk-footer-col:nth-child(1) { animation-delay: 0.1s; }
.sk-footer-col:nth-child(2) { animation-delay: 0.2s; }
.sk-footer-col:nth-child(3) { animation-delay: 0.3s; }
.sk-footer-col:nth-child(4) { animation-delay: 0.4s; }
</style>

<!-- ═══════════════════════════════════════════ -->
<!--          SHIKSHARTHI DESKTOP FOOTER        -->
<!-- ═══════════════════════════════════════════ -->
<footer class="sk-footer">
    <div class="sk-footer-inner">

        <div class="sk-footer-grid">

            <!-- ── Brand Column ── -->
            <div class="sk-footer-col">
                <div class="sk-footer-brand">
                    <div class="sk-footer-brand-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <span class="sk-footer-brand-name">SHIKSHARTHI</span>
                </div>
                <p class="sk-footer-desc">
                    AI-Powered Personalized Learning Platform for Indian Students.
                    Har student ki zaroorat, hamari zimmedari. 🎯
                </p>
                <div class="sk-footer-social">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                    <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>

            <!-- ── Quick Links ── -->
            <div class="sk-footer-col">
                <h4>Quick Links</h4>
                <ul class="sk-footer-links">
                    <li><a href="dashboard.php"><i class="fas fa-chevron-right"></i> Dashboard</a></li>
                    <li><a href="videos.php"><i class="fas fa-chevron-right"></i> Video Lectures</a></li>
                    <li><a href="notes.php"><i class="fas fa-chevron-right"></i> Study Notes</a></li>
                    <li><a href="quizzes.php"><i class="fas fa-chevron-right"></i> Practice Quizzes</a></li>
                    <li><a href="games.php"><i class="fas fa-chevron-right"></i> Learning Games</a></li>
                </ul>
            </div>

            <!-- ── Resources ── -->
            <div class="sk-footer-col">
                <h4>Resources</h4>
                <ul class="sk-footer-links">
                    <li><a href="pyqs.php"><i class="fas fa-chevron-right"></i> Previous Year Papers</a></li>
                    <li><a href="syllabus.php"><i class="fas fa-chevron-right"></i> Syllabus</a></li>
                    <li><a href="goals.php"><i class="fas fa-chevron-right"></i> Set Goals</a></li>
                    <li><a href="profile.php"><i class="fas fa-chevron-right"></i> My Profile</a></li>
                    <li><a href="about.php"><i class="fas fa-chevron-right"></i> About Us</a></li>
                </ul>
            </div>

            <!-- ── Contact Info ── -->
            <div class="sk-footer-col">
                <h4>Contact Us</h4>
                <ul class="sk-footer-contact">
                    <li>
                        <i class="fas fa-envelope"></i>
                        <a href="mailto:support@shiksharthi.com">support@shiksharthi.com</a>
                    </li>
                    <li>
                        <i class="fas fa-phone-alt"></i>
                        <span>+91 98765 43210</span>
                    </li>
                    <li>
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Kanpur, Uttar Pradesh, India</span>
                    </li>
                    <li>
                        <i class="fas fa-clock"></i>
                        <span>Mon - Sat: 9 AM - 6 PM</span>
                    </li>
                </ul>
            </div>

        </div>

        <!-- ── Copyright Bar ── -->
        <div class="sk-footer-bottom">
            <p class="sk-footer-copyright">
                &copy; <?= $currentYear ?> <span>SHIKSHARTHI</span>. Made with ❤️ for Indian Students.
            </p>
            <div class="sk-footer-legal">
                <a href="terms.php">
                    <i class="fas fa-file-contract"></i> Terms & Conditions
                </a>
                <a href="privacy.php">
                    <i class="fas fa-shield-alt"></i> Privacy Policy
                </a>
                <a href="faq.php">
                    <i class="fas fa-question-circle"></i> FAQ
                </a>
            </div>
        </div>

    </div>
</footer>

<!-- ═══════════════════════════════════════════ -->
<!--       MOBILE BOTTOM NAVIGATION BAR         -->
<!-- ═══════════════════════════════════════════ -->
<nav class="sk-mobile-nav" id="mobileNav">
    <div class="sk-mobile-nav-inner">
        
        <a href="videos.php" class="sk-mobile-nav-item <?= $currentPage === 'videos.php' ? 'active' : '' ?>">
            <i class="fas fa-play-circle"></i>
            <span>Videos</span>
        </a>
        
        <a href="notes.php" class="sk-mobile-nav-item <?= in_array($currentPage, ['notes.php','pyqs.php','syllabus.php']) ? 'active' : '' ?>">
            <i class="fas fa-book-open"></i>
            <span>Library</span>
        </a>
        
        <a href="dashboard.php" class="sk-mobile-nav-item center-btn <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-th-large"></i>
            <span>Dashboard</span>
        </a>
        
        <a href="quizzes.php" class="sk-mobile-nav-item <?= $currentPage === 'quizzes.php' ? 'active' : '' ?>">
            <i class="fas fa-question-circle"></i>
            <span>Quiz</span>
        </a>
        
        <a href="games.php" class="sk-mobile-nav-item <?= $currentPage === 'games.php' ? 'active' : '' ?>">
            <i class="fas fa-gamepad"></i>
            <span>Games</span>
        </a>
        
    </div>
</nav>

<!-- ── Scroll to Top Button ── -->
<button class="sk-scroll-top" id="scrollTopBtn" aria-label="Scroll to Top">
    <i class="fas fa-arrow-up"></i>
</button>

<script>
// ═══════════════════════════════════════════
//           FOOTER JAVASCRIPT
// ═══════════════════════════════════════════

document.addEventListener('DOMContentLoaded', function() {
    
    // ── Scroll to Top Button ──
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            scrollTopBtn.classList.add('visible');
        } else {
            scrollTopBtn.classList.remove('visible');
        }
    });
    
    scrollTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // ── Mobile Nav Active State with Haptic Feedback ──
    const mobileNavItems = document.querySelectorAll('.sk-mobile-nav-item');
    
    mobileNavItems.forEach(item => {
        item.addEventListener('click', function() {
            // Add click animation
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 100);
            
            // Haptic feedback (if supported)
            if (navigator.vibrate) {
                navigator.vibrate(10);
            }
        });
    });

    // ── Hide mobile nav on scroll down, show on scroll up ──
    let lastScrollY = window.pageYOffset;
    const mobileNav = document.getElementById('mobileNav');
    
    window.addEventListener('scroll', function() {
        const currentScrollY = window.pageYOffset;
        
        if (currentScrollY > lastScrollY && currentScrollY > 100) {
            // Scrolling down
            mobileNav.style.transform = 'translateY(100%)';
        } else {
            // Scrolling up
            mobileNav.style.transform = 'translateY(0)';
        }
        
        lastScrollY = currentScrollY;
    });

    // ── Footer Animation on Scroll ──
    const footerCols = document.querySelectorAll('.sk-footer-col');
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    footerCols.forEach(col => {
        col.style.opacity = '0';
        col.style.transform = 'translateY(20px)';
        col.style.transition = 'all 0.6s ease';
        observer.observe(col);
    });

});
</script>