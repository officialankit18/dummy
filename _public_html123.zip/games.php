<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/security.php';
requireLogin();
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Games — SHIKSHARTHI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="app-body">
<?php include 'navbar.php'; ?>

<main class="main-content">
    <div class="page-header">
        <h1><i class="fas fa-gamepad"></i> Learning Games</h1>
        <p>Learn while having fun!</p>
    </div>

    <div class="games-grid">

        <!-- Math Speed -->
        <div class="game-card" id="mathGameCard">
            <div class="game-icon" style="background:rgba(78,137,199,.1);color:var(--blue)"><i class="fas fa-calculator"></i></div>
            <h3>Math Speed</h3>
            <p>Solve math problems as fast as you can! Test your mental math skills.</p>
            <button class="btn btn-primary btn-sm" onclick="startMathGame()">Play Now</button>
        </div>

        <!-- Word Scramble -->
        <div class="game-card">
            <div class="game-icon" style="background:rgba(139,92,246,.1);color:var(--purple)"><i class="fas fa-spell-check"></i></div>
            <h3>Word Scramble</h3>
            <p>Unscramble the letters to find the correct word. Boost your vocabulary!</p>
            <button class="btn btn-primary btn-sm" onclick="startWordGame()">Play Now</button>
        </div>

        <!-- Memory Match -->
        <div class="game-card">
            <div class="game-icon" style="background:rgba(16,185,129,.1);color:#10b981"><i class="fas fa-brain"></i></div>
            <h3>Memory Match</h3>
            <p>Match pairs of cards to test your memory. How fast can you finish?</p>
            <button class="btn btn-primary btn-sm" onclick="startMemoryGame()">Play Now</button>
        </div>

        <!-- Typing Test -->
        <div class="game-card">
            <div class="game-icon" style="background:rgba(245,158,11,.1);color:#f59e0b"><i class="fas fa-keyboard"></i></div>
            <h3>Typing Speed</h3>
            <p>Test how fast and accurately you can type. Improve your typing skills!</p>
            <button class="btn btn-primary btn-sm" onclick="startTypingGame()">Play Now</button>
        </div>
    </div>

    <!-- Game Area -->
    <div class="game-area card" id="gameArea" style="display:none">
        <div class="game-area-header">
            <h3 id="gameTitle"></h3>
            <button class="btn btn-sm btn-secondary" onclick="closeGame()"><i class="fas fa-times"></i> Close</button>
        </div>
        <div class="game-area-body" id="gameBody"></div>
    </div>

</main>
<?php include 'footer.php'; ?>

<script>
var gameArea = document.getElementById('gameArea');
var gameBody = document.getElementById('gameBody');
var gameTitle = document.getElementById('gameTitle');

function closeGame(){ gameArea.style.display='none'; gameBody.innerHTML=''; }

// ═══ MATH SPEED GAME ═══
function startMathGame(){
    gameTitle.textContent = '⚡ Math Speed Challenge';
    gameArea.style.display = 'block';
    gameArea.scrollIntoView({behavior:'smooth'});

    var score=0, total=0, maxQ=10, timer=30, interval;
    function genQ(){
        var ops=['+','-','×'];
        var op=ops[Math.floor(Math.random()*3)];
        var a=Math.floor(Math.random()*50)+1;
        var b=Math.floor(Math.random()*20)+1;
        var ans;
        if(op==='+') ans=a+b;
        else if(op==='-'){if(a<b){var t=a;a=b;b=t;} ans=a-b;}
        else{a=Math.floor(Math.random()*12)+1;b=Math.floor(Math.random()*12)+1;ans=a*b;}
        return {q:a+' '+op+' '+b+' = ?', a:ans};
    }

    function showQ(){
        if(total>=maxQ||timer<=0){endMath();return;}
        var qq=genQ();
        gameBody.innerHTML='<div class="game-center"><p class="game-timer">Time: <strong>'+timer+'s</strong> | Score: <strong>'+score+'/'+total+'</strong></p><h2 class="game-question">'+qq.q+'</h2><input type="number" id="mathAns" class="game-input" autofocus placeholder="Your answer"><button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="checkMath('+qq.a+')">Submit</button></div>';
        document.getElementById('mathAns').focus();
        document.getElementById('mathAns').addEventListener('keydown',function(e){if(e.key==='Enter')checkMath(qq.a);});
    }

    window.checkMath=function(correct){
        var ans=parseInt(document.getElementById('mathAns').value);
        total++;
        if(ans===correct) score++;
        showQ();
    };

    function endMath(){
        clearInterval(interval);
        gameBody.innerHTML='<div class="game-center"><h2>🎉 Game Over!</h2><p class="game-score">Score: <strong>'+score+'/'+total+'</strong></p><p>'+(score>=8?'Excellent! 🌟':score>=5?'Good job! 👍':'Keep practicing! 💪')+'</p><button class="btn btn-primary btn-sm" onclick="startMathGame()">Play Again</button></div>';
    }

    interval=setInterval(function(){timer--;if(timer<=0){clearInterval(interval);endMath();}else{var t=document.querySelector('.game-timer');if(t)t.innerHTML='Time: <strong>'+timer+'s</strong> | Score: <strong>'+score+'/'+total+'</strong>';}},1000);
    showQ();
}

// ═══ WORD SCRAMBLE ═══
function startWordGame(){
    gameTitle.textContent = '🔤 Word Scramble';
    gameArea.style.display = 'block';
    gameArea.scrollIntoView({behavior:'smooth'});

    var words=['COMPUTER','SCIENCE','MATHEMATICS','EDUCATION','LEARNING','KNOWLEDGE','STUDENT','TEACHER','GEOGRAPHY','HISTORY','PHYSICS','CHEMISTRY','BIOLOGY','ENGLISH','LIBRARY'];
    var score=0, round=0, maxR=8, current='';

    function scramble(w){var a=w.split('');for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t;}var s=a.join('');return s===w?scramble(w):s;}

    function showWord(){
        if(round>=maxR){gameBody.innerHTML='<div class="game-center"><h2>🎉 Game Over!</h2><p class="game-score">Score: <strong>'+score+'/'+maxR+'</strong></p><button class="btn btn-primary btn-sm" onclick="startWordGame()">Play Again</button></div>';return;}
        current=words[Math.floor(Math.random()*words.length)];
        var sc=scramble(current);
        gameBody.innerHTML='<div class="game-center"><p class="game-timer">Round '+(round+1)+'/'+maxR+' | Score: '+score+'</p><h2 class="game-question">'+sc+'</h2><input type="text" id="wordAns" class="game-input" autofocus placeholder="Unscramble this word"><button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="checkWord()">Submit</button></div>';
        document.getElementById('wordAns').focus();
        document.getElementById('wordAns').addEventListener('keydown',function(e){if(e.key==='Enter')checkWord();});
    }

    window.checkWord=function(){
        var ans=document.getElementById('wordAns').value.trim().toUpperCase();
        round++;
        if(ans===current) score++;
        showWord();
    };
    showWord();
}

// ═══ MEMORY MATCH ═══
function startMemoryGame(){
    gameTitle.textContent = '🧠 Memory Match';
    gameArea.style.display = 'block';
    gameArea.scrollIntoView({behavior:'smooth'});

    var emojis=['🔬','📐','🌍','📚','⚛️','🧬','🔭','✏️'];
    var cards=[...emojis,...emojis];
    cards.sort(()=>Math.random()-0.5);

    var flipped=[], matched=0, moves=0;
    var html='<div class="game-center"><p class="game-timer" id="memInfo">Moves: 0 | Matched: 0/8</p><div class="memory-grid">';
    cards.forEach(function(c,i){html+='<div class="mem-card" data-idx="'+i+'" data-val="'+c+'" onclick="flipCard(this)"><span class="mem-front">?</span><span class="mem-back">'+c+'</span></div>';});
    html+='</div></div>';
    gameBody.innerHTML=html;

    window.flipCard=function(el){
        if(flipped.length>=2||el.classList.contains('flipped')||el.classList.contains('matched'))return;
        el.classList.add('flipped');
        flipped.push(el);
        if(flipped.length===2){
            moves++;
            if(flipped[0].dataset.val===flipped[1].dataset.val){
                flipped[0].classList.add('matched');
                flipped[1].classList.add('matched');
                matched++;
                flipped=[];
                if(matched===8){document.getElementById('memInfo').innerHTML='🎉 You won in '+moves+' moves! <button class="btn btn-sm btn-primary" onclick="startMemoryGame()">Play Again</button>';}
            }else{
                setTimeout(function(){flipped[0].classList.remove('flipped');flipped[1].classList.remove('flipped');flipped=[];},800);
            }
            document.getElementById('memInfo').innerHTML='Moves: '+moves+' | Matched: '+matched+'/8';
        }
    };
}

// ═══ TYPING SPEED ═══
function startTypingGame(){
    gameTitle.textContent = '⌨️ Typing Speed Test';
    gameArea.style.display = 'block';
    gameArea.scrollIntoView({behavior:'smooth'});

    var sentences=['The quick brown fox jumps over the lazy dog.','Education is the most powerful weapon to change the world.','Knowledge is power and learning never stops.','Science is organized knowledge and wisdom is organized life.','A journey of a thousand miles begins with a single step.'];
    var target=sentences[Math.floor(Math.random()*sentences.length)];
    var startTime=null;

    gameBody.innerHTML='<div class="game-center"><p class="game-timer">Type the text below as fast as you can:</p><p class="typing-target" id="typTarget">'+target+'</p><textarea id="typInput" class="game-textarea" rows="3" placeholder="Start typing here..."></textarea><p id="typResult"></p></div>';

    var inp=document.getElementById('typInput');
    inp.focus();
    inp.addEventListener('input',function(){
        if(!startTime) startTime=Date.now();
        var typed=inp.value;
        if(typed===target){
            var secs=((Date.now()-startTime)/1000).toFixed(1);
            var wpm=Math.round((target.split(' ').length/secs)*60);
            document.getElementById('typResult').innerHTML='✅ Done in <strong>'+secs+'s</strong> | Speed: <strong>'+wpm+' WPM</strong> <button class="btn btn-sm btn-primary" onclick="startTypingGame()" style="margin-left:10px">Try Again</button>';
            inp.disabled=true;
        }
    });
}
</script>
</body>
</html>